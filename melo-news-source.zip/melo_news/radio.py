"""Autonomous, native-source bilingual speech with one atomic public pointer.

The public API never accepts text, voice names, URLs, or synthesis options.
Only the collector's configured publishers and bundled reviewed entertainment
reach speech. A failed build keeps the last complete pair (or dated baseline).
"""
from __future__ import annotations

import array
import asyncio
import copy
import datetime as dt
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
import threading
import time
import urllib.parse

from .collector import atomic_json, iso, parse_date, utcnow

BASE = Path(__file__).resolve().parent
LANGUAGES = ("en", "ar")
AUDIO_ROUTE = "/api/radio/audio/"
DIGEST = re.compile(r"[0-9a-f]{64}\Z")
ARABIC = re.compile(r"[\u0600-\u06ff]")
RENDERER_VERSION = "edge-7.3.1-av-mp3-192k-44100-stereo-v1"
MAX_AUDIO_BYTES = 32 * 1024 * 1024
MAX_CLIP_SECONDS = 300
LABELS = {
    "world": ("World news", "أخبار العالم"),
    "positive": ("Good news", "أخبار مفرحة"),
    "offbeat": ("Offbeat and surprising", "طرائف وغرائب"),
    "technology": ("Technology", "التكنولوجيا"),
    "ai": ("Artificial intelligence", "الذكاء الاصطناعي"),
    "economy": ("Economy and business", "الاقتصاد والأعمال"),
    "sports": ("Sport", "الرياضة"),
    "nature": ("Nature and environment", "الطبيعة والبيئة"),
    "travel": ("Travel and tourism", "السفر والسياحة"),
    "history": ("History and archaeology", "التاريخ والآثار"),
    "science": ("Science and space", "العلوم والفضاء"),
}


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def speech_parts(segment):
    text = segment.get("text")
    if not isinstance(text, str) or not 1 <= len(text) <= 4000 or "\x00" in text:
        raise ValueError("Speech text is absent or outside the reviewed size bound")
    parts = segment.get("speech_parts") or [{"text": text, "pause_after": 0}]
    if not isinstance(parts, list) or not 1 <= len(parts) <= 4:
        raise ValueError("Speech needs one to four bounded parts")
    for part in parts:
        if not isinstance(part, dict) or not isinstance(part.get("text"), str) or not part["text"].strip():
            raise ValueError("Speech part needs text")
        pause = part.get("pause_after", 0)
        if isinstance(pause, bool) or not isinstance(pause, (int, float)) or not math.isfinite(pause) or not 0 <= pause <= 1:
            raise ValueError("Speech pause is outside the reviewed bound")
    if len(parts) > 1 and text != "\n\n".join(x["text"] for x in parts):
        raise ValueError("Speech parts must reproduce the displayed text")
    if segment.get("type") == "jokes" and (
            len(parts) != 4 or [x.get("pause_after", 0) for x in parts] != [.35, .7, .35, 0]):
        raise ValueError("Reviewed jokes need the four established setup/punchline pauses")
    return parts


def verify_audio(path):
    """Decode every frame, streaming small buffers rather than entire clips."""
    import av
    path = Path(path)
    if not 0 < path.stat().st_size <= MAX_AUDIO_BYTES:
        raise ValueError("Speech asset exceeds its size bound")
    total, peak, frames = 0, 0, 0
    with av.open(str(path)) as source:
        if len(source.streams.audio) != 1 or len(source.streams.video):
            raise ValueError("Speech needs exactly one audio stream")
        stream = source.streams.audio[0]
        if stream.codec_context.sample_rate != 44100 or len(stream.codec_context.layout.channels) != 2:
            raise ValueError("Speech must be 44.1 kHz stereo")
        resampler = av.AudioResampler(format="s16p", layout="stereo", rate=44100)
        for frame in source.decode(audio=0):
            if frame.sample_rate != 44100 or len(frame.layout.channels) != 2:
                raise ValueError("Speech format changed during decoding")
            total += frame.samples
            frames += 1
            if total > 44100 * MAX_CLIP_SECONDS:
                raise ValueError("Speech asset exceeds its duration bound")
            for converted in resampler.resample(frame):
                for plane in converted.planes:
                    values = array.array("h", bytes(plane)[:converted.samples * 2])
                    if values:
                        peak = max(peak, abs(min(values)), abs(max(values)))
    if total < 4410 or not frames or peak < 4:
        raise ValueError("Speech asset is empty or silent")
    return {"duration": total / 44100, "frames": frames, "peak": peak / 32768,
            "sampleRate": 44100, "channels": 2, "bitRate": 192000}


def transcode_parts(paths, parts, output):
    """Encode MP3 plus precise pauses with streaming PyAV; no ffmpeg process."""
    import av
    cursor = 0
    with av.open(str(output), "w", format="mp3") as destination:
        encoder = destination.add_stream("libmp3lame", rate=44100)
        encoder.bit_rate = 192000
        encoder.layout = "stereo"
        encoder.codec_context.format = "fltp"

        def encode(frame):
            nonlocal cursor
            frame.pts = cursor
            frame.time_base = Fraction(1, 44100)
            frame.sample_rate = 44100
            cursor += frame.samples
            if cursor > 44100 * MAX_CLIP_SECONDS:
                raise ValueError("Speech exceeds its duration bound")
            for packet in encoder.encode(frame):
                destination.mux(packet)

        for path, part in zip(paths, parts):
            resampler = av.AudioResampler(format="fltp", layout="stereo", rate=44100)
            with av.open(str(path)) as source:
                if len(source.streams.audio) != 1:
                    raise ValueError("Neural response is not a single audio stream")
                for frame in source.decode(audio=0):
                    frame.pts = None
                    for converted in resampler.resample(frame):
                        encode(converted)
                for converted in resampler.resample(None):
                    encode(converted)
            silence = round(part.get("pause_after", 0) * 44100)
            while silence:
                samples = min(silence, 1152)
                frame = av.AudioFrame(format="fltp", layout="stereo", samples=samples)
                for plane in frame.planes:
                    plane.update(b"\x00" * plane.buffer_size)
                encode(frame)
                silence -= samples
        for packet in encoder.encode(None):
            destination.mux(packet)


def render_segment(segment, output, profile):
    """Free fixed-profile edge speech. Errors never contain publisher text/URLs."""
    import edge_tts
    if edge_tts.__version__ != "7.3.1":
        raise RuntimeError("The reviewed speech engine must be edge-tts 7.3.1")
    language = segment.get("language")
    if language not in LANGUAGES or not re.fullmatch(language + r"-[A-Z]{2}-[A-Za-z0-9]+Neural", profile["voice"]):
        raise ValueError("The native voice does not match the edition language")
    parts = speech_parts(segment)
    output = Path(output)
    with tempfile.TemporaryDirectory(prefix=".radio-render-", dir=output.parent) as temporary:
        scratch = Path(temporary)

        async def download():
            paths = []
            for number, part in enumerate(parts):
                path = scratch / (str(number) + ".mp3")
                for attempt in range(2):
                    try:
                        voice = edge_tts.Communicate(part["text"], profile["voice"], rate=profile["rate"],
                                                     connect_timeout=10, receive_timeout=20)
                        await asyncio.wait_for(voice.save(str(path)), timeout=40)
                        if not 0 < path.stat().st_size <= MAX_AUDIO_BYTES:
                            raise ValueError("Invalid neural response size")
                        break
                    except Exception as error:
                        if attempt:
                            raise RuntimeError("Neural speech failed after two bounded attempts (" + type(error).__name__ + ")") from None
                        await asyncio.sleep(1)
                paths.append(path)
            await asyncio.sleep(.3)
            return paths

        loop = asyncio.SelectorEventLoop() if os.name == "nt" else asyncio.new_event_loop()
        try:
            paths = loop.run_until_complete(download())
        finally:
            loop.run_until_complete(asyncio.sleep(.3))
            loop.close()
        transcode_parts(paths, parts, output)
    return verify_audio(output)


def select_headlines(catalog, config, language, now, minimum=1, maximum=13):
    """Use original native headlines from configured hosts with actual dates."""
    if not catalog or catalog.get("language") != language or catalog.get("status") == "failed":
        raise ValueError("A native publisher catalog is unavailable")
    run_checked = parse_date(catalog.get("runCheckedAt"))
    if run_checked is None or not 0 <= (now - run_checked).total_seconds() <= 3600:
        raise ValueError("The publisher catalog has not been checked recently")
    sources = {source["id"]: source for source in config["sources"]}
    candidates, urls, titles = [], set(), set()
    for raw in catalog.get("items", [])[:1000]:
        if raw.get("retained") or raw.get("language", language) != language:
            continue
        title = raw.get("title")
        if not isinstance(title, str) or not 1 <= len(title) <= 300 or len(title.split()) > 50:
            continue
        if "\x00" in title or title.rstrip().endswith(("?", "؟")):
            continue
        if language == "ar" and not ARABIC.search(title):
            continue
        if language == "en" and ARABIC.search(title):
            continue
        provenance = raw.get("provenance") or [raw]
        accepted = None
        for evidence in provenance[:30]:
            source_id = evidence.get("sourceId", raw.get("sourceId"))
            source = sources.get(source_id)
            if source is None or evidence.get("retained"):
                continue
            url = evidence.get("sourceUrl") or raw.get("url") or raw.get("sourceUrl")
            try:
                parsed = urllib.parse.urlsplit(url)
                port = parsed.port
            except (ValueError, TypeError):
                continue
            if parsed.scheme != "https" or parsed.username or parsed.password or port not in (None, 443):
                continue
            if parsed.hostname not in source["articleHosts"]:
                continue
            if any(part in parsed.path.lower() for part in ("/commentisfree/", "/live/", "/video/")):
                continue
            category = evidence.get("category", source["category"])
            if category not in LABELS or category not in config["categories"]:
                continue
            published = parse_date(evidence.get("publishedAt", raw.get("publishedAt")))
            checked = parse_date(evidence.get("checkedAt", raw.get("checkedAt")))
            window = min(config["categories"][category]["maxAgeHours"], 168 if category in ("history", "travel") else 24)
            if published is None or not 0 <= (now - published).total_seconds() <= window * 3600:
                continue
            if checked is None or not 0 <= (now - checked).total_seconds() <= 3600:
                continue
            accepted = {"title": title, "url": url, "outlet": source["publisher"],
                        "category": category, "publishedAt": iso(published), "checkedAt": iso(checked),
                        "sourceId": source_id, "sourceWindowHours": window}
            for key in ("publicationDateType", "publicationDateField", "publicationDateOriginal"):
                if key in raw:
                    accepted[key] = raw[key]
            if accepted.get("publicationDateType") == "updated" or accepted.get("publicationDateField") == "updated":
                accepted["publicationDateType"] = "updated"
            break
        if accepted is None or accepted["url"] in urls or title.casefold() in titles:
            continue
        urls.add(accepted["url"]); titles.add(title.casefold())
        candidates.append(accepted)
    candidates.sort(key=lambda item: item["publishedAt"], reverse=True)
    selected = []
    for category in LABELS:
        quota = 2 if category in ("positive", "offbeat") else 1
        selected.extend([x for x in candidates if x["category"] == category][:quota])
    selected = selected[:maximum]
    # Arabic feeds may carry broad native headlines under one editorial topic.
    # Preserve that category instead of inventing a topic or translating English.
    for item in candidates:
        if len(selected) >= maximum:
            break
        if item not in selected:
            selected.append(item)
    if len(selected) < minimum:
        raise ValueError("Not enough freshly checked native publisher headlines")
    return selected


class RadioStore:
    """One sequential background builder; read requests return dated state fast."""
    def __init__(self, directory, catalog_store, content_path=None, baseline_path=None,
                 refresh_seconds=1800, renderer=render_segment, verifier=verify_audio,
                 clock=utcnow, minimum_headlines=1, selector=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        (self.directory / "audio").mkdir(exist_ok=True)
        (self.directory / "segments").mkdir(exist_ok=True)
        (self.directory / "editions").mkdir(exist_ok=True)
        self.catalog_store = catalog_store
        self.content_path = Path(content_path or BASE / "radio-content.json")
        self.content = load(self.content_path)
        self.baseline_path = Path(baseline_path or BASE / "radio-baseline.json")
        self.baseline = load(self.baseline_path)
        self.refresh_seconds = max(300, refresh_seconds)
        self.renderer, self.verifier, self.clock = renderer, verifier, clock
        if not isinstance(minimum_headlines, int) or isinstance(minimum_headlines, bool) or not 1 <= minimum_headlines <= 13:
            raise ValueError("Native headline minimum must be between one and thirteen")
        self.minimum_headlines = minimum_headlines
        self.selector = selector
        self._mutex = threading.Lock()
        self._build_mutex = threading.Lock()
        self._event = None
        self._last_started = -1000000
        self._last_finished = -1000000
        self._error = None
        self._progress = None
        self._verified_bundle = set()
        self._validate_content()

    def _validate_content(self):
        if self.content.get("schemaVersion") != 1 or set(self.content["languages"]) != set(LANGUAGES):
            raise ValueError("Unsupported reviewed radio content")
        for language in LANGUAGES:
            content = self.content["languages"][language]
            if len(content["idents"]) != 2 or len(content["jokeSlots"]) != 6 or len(content["jokes"]) < 18 or len(content["stories"]) != 4:
                raise ValueError("The reviewed entertainment bank is incomplete")
            for row in content["idents"] + content["jokes"] + content["stories"]:
                if row.get("language") != language or row.get("type") not in ("ident", "jokes", "story") or row.get("sources") != []:
                    raise ValueError("Only reviewed original entertainment may be bundled")
                speech_parts(row)
                if row["type"] == "story" and not 100 <= len(row["text"].split()) <= 145:
                    raise ValueError("Reviewed fictional stories must contain 100–145 words")
            if self.baseline[language].get("language") != language:
                raise ValueError("The published baseline language is invalid")

    def _active(self):
        try:
            pointer = load(self.directory / "active.json")
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", pointer["version"]):
                return None
            pair = load(self.directory / "editions" / (pointer["version"] + ".json"))
            if pair.get("generationState") != "complete" or pair.get("version") != pointer["version"]:
                return None
            if any(pair["programs"][lang].get("version") != pointer["version"] for lang in LANGUAGES):
                return None
            for program in pair["programs"].values():
                if any(self.audio_file(x["file"][len(AUDIO_ROUTE):-4]) is None
                       for x in program["segments"] if x["file"].startswith(AUDIO_ROUTE)):
                    return None
            return pair
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def audio_file(self, digest):
        if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
            return None
        cached = self.directory / "audio" / (digest + ".mp3")
        if cached.is_file():
            return cached
        entry = self.content.get("bundledAudio", {}).get(digest)
        if not entry or entry.get("path") != "content-audio/" + digest + ".mp3":
            return None
        bundled = self.content_path.parent / entry["path"]
        if not bundled.is_file() or bundled.stat().st_size != entry["size"]:
            return None
        if digest not in self._verified_bundle:
            if file_hash(bundled) != digest:
                return None
            self._verified_bundle.add(digest)
        return bundled

    def response(self, language):
        if language not in LANGUAGES:
            return 400, {"error": "language must be en or ar"}
        self.start_refresh()
        active = self._active()
        if active:
            return 200, copy.deepcopy(active["programs"][language])
        fallback = copy.deepcopy(self.baseline[language])
        fallback.update(generationState="published-fallback", origin="published-fallback",
                        audioOrigin="published-fallback", baselineAudioBaseUrl="https://go.melo.here.now/",
                        autonomousSpeech=False,
                        generationNote="The dated published edition remains available while both native-source editions are prepared.")
        return 200, fallback

    def status(self):
        active = self._active()
        with self._mutex:
            running = self._event is not None and not self._event.is_set()
            progress, error = copy.deepcopy(self._progress), copy.deepcopy(self._error)
        return {"service": "melo-radio", "generationState": "building" if running else "complete" if active else "published-fallback",
                "version": active["version"] if active else None,
                "languages": {lang: {"newsUpdatedAt": active["programs"][lang]["newsUpdatedAt"],
                                     "segments": len(active["programs"][lang]["segments"])} for lang in LANGUAGES} if active else {},
                "progress": progress, "lastError": error, "refreshAfterSeconds": self.refresh_seconds,
                "classification": self._classification_status(),
                "sourceMode": "Independent native English and Arabic publisher headlines; no machine translation or invented news.",
                "hostingNote": "Free hosting may sleep. A request wakes it; cached complete audio or the dated published fallback remains available while work continues."}

    def _classification_status(self):
        """Expose bounded diagnostic counters, never model paths or raw errors."""
        result = {"state": "disabled", "advisoryOnly": True, "generatesText": False}
        if self.selector is None:
            return result
        result["state"] = "unavailable"
        try:
            status = self.selector.status() if callable(getattr(self.selector, "status", None)) else {}
            if not isinstance(status, dict):
                return result
            if status.get("state") in {"initializing", "unavailable", "ready", "retained-publisher-categories"}:
                result["state"] = status["state"]
            if status.get("model") == "EmbeddingGemma 2":
                result["model"] = "EmbeddingGemma 2"
            stamp = parse_date(status.get("lastInferenceAt"))
            if stamp:
                result["lastInferenceAt"] = iso(stamp)
            count = status.get("classified")
            if isinstance(count, int) and not isinstance(count, bool) and 0 <= count <= 64:
                result["classified"] = count
            seconds = status.get("lastInferenceSeconds")
            if isinstance(seconds, (int, float)) and not isinstance(seconds, bool) and math.isfinite(seconds) and 0 <= seconds <= 600:
                result["lastInferenceSeconds"] = seconds
            if isinstance(status.get("workerTerminated"), bool):
                result["workerTerminated"] = status["workerTerminated"]
            metrics = status.get("metrics", {})
            if isinstance(metrics, dict):
                safe = {}
                for key in ("peakChildRssBytes", "peakOsWorkingSetBytes", "peakWorkerAndChildRssBytes"):
                    value = metrics.get(key)
                    if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 2 * 1024 ** 3:
                        safe[key] = value
                if metrics.get("stoppedReason") in (None, "memory_limit", "deadline"):
                    safe["stoppedReason"] = metrics.get("stoppedReason")
                result["metrics"] = safe
            if status.get("errorType") in {"RuntimeError", "ValueError", "TimeoutError", "OSError", "FileNotFoundError", "PermissionError", "MemoryError", "JSONDecodeError"}:
                result["errorType"] = status["errorType"]
        except Exception:
            pass
        return result

    def start_refresh(self, force=False):
        # Do not consume a speech retry window while a cold-start collector has
        # not produced both native catalogs. Collection callbacks retry once ready.
        ready = True
        for language in LANGUAGES:
            if self.catalog_store.cached(language) is None:
                self.catalog_store.start_refresh(language)
                ready = False
        if not ready:
            return None
        with self._mutex:
            if self._event is not None and not self._event.is_set():
                return self._event
            current = time.monotonic()
            interval = 60 if self._error else self.refresh_seconds
            if current - self._last_started < 60 or (not force and current - self._last_finished < interval):
                return None
            event = threading.Event()
            self._event = event
            self._last_started = current
            threading.Thread(target=self._build_job, args=(event,), daemon=True,
                             name="melo-radio-bilingual-build").start()
            return event

    def _build_job(self, event):
        failed = False
        try:
            self.build_once()
            with self._mutex:
                self._error = None
        except Exception as error:
            failed = True
            with self._mutex:
                self._error = {"type": type(error).__name__, "attemptedAt": iso(self.clock()),
                               "retainedPublishedEdition": True}
        finally:
            with self._mutex:
                self._last_finished = time.monotonic()
                self._progress = None
            event.set()
            if failed:
                timer = threading.Timer(65, self.start_refresh)
                timer.daemon = True
                timer.start()

    def _profile(self, segment):
        settings = self.content["voices"][segment["language"]]
        role = segment["type"]
        if role == "jokes":
            index = int(hashlib.sha256(segment["id"].encode()).hexdigest()[:8], 16) % len(settings["jokes"])
            return settings["jokes"][index]
        return settings.get(role, settings["host"])

    def _fingerprint(self, segment, profile):
        return hashlib.sha256(canonical({"renderer": RENDERER_VERSION, "language": segment["language"],
            "text": segment["text"], "speech_parts": segment.get("speech_parts"), "profile": profile})).hexdigest()

    def _asset(self, segment):
        profile = self._profile(segment)
        fingerprint = self._fingerprint(segment, profile)
        bundled = self.content.get("bundledSegments", {}).get(fingerprint)
        if bundled and self.audio_file(bundled["sha256"]):
            return {**copy.deepcopy(segment), "file": AUDIO_ROUTE + bundled["sha256"] + ".mp3",
                    "duration": bundled["duration"], "voiceLabel": profile["label"],
                    "voiceAccent": profile["accent"], "ttsVoice": profile["voice"], "voiceEngine": "edge-neural"}
        cache_path = self.directory / "segments" / (fingerprint + ".json")
        try:
            cached = load(cache_path)
            asset = self.audio_file(cached["sha256"])
            if cached["fingerprint"] != fingerprint or asset is None or file_hash(asset) != cached["sha256"]:
                raise ValueError("Cached speech does not match its content binding")
            metrics = self.verifier(asset)
        except Exception:
            with tempfile.TemporaryDirectory(prefix=".radio-stage-", dir=self.directory) as temporary:
                output = Path(temporary) / "speech.mp3"
                self.renderer(segment, output, profile)
                metrics = self.verifier(output)
                digest = file_hash(output)
                destination = self.directory / "audio" / (digest + ".mp3")
                os.replace(output, destination)
                cached = {"fingerprint": fingerprint, "sha256": digest, "metrics": metrics}
                atomic_json(cache_path, cached)
        return {**copy.deepcopy(segment), "file": AUDIO_ROUTE + cached["sha256"] + ".mp3",
                "duration": metrics["duration"], "voiceLabel": profile["label"],
                "voiceAccent": profile["accent"], "ttsVoice": profile["voice"], "voiceEngine": "edge-neural"}

    def _entertainment(self, language, previous, now):
        content = self.content["languages"][language]
        rotation = previous.get("jokeBankRotation", 0) if previous else 0
        stamp = previous.get("entertainmentUpdatedAt") if previous else content["entertainmentUpdatedAt"]
        prior = parse_date(stamp)
        # Initial activation always uses the packaged clips; it never needs to
        # regenerate entertainment just because an ephemeral host restarted.
        if previous and prior and (now - prior).total_seconds() >= 21600:
            rotation = (rotation + 1) % ((len(content["jokes"]) + 5) // 6)
            stamp = iso(now)
        rows = copy.deepcopy(content["idents"])
        for number, identity in enumerate(content["jokeSlots"]):
            row = copy.deepcopy(content["jokes"][(rotation * 6 + number) % len(content["jokes"])])
            row["id"] = identity
            rows.append(row)
        rows.extend(copy.deepcopy(content["stories"]))
        return rows, rotation, stamp

    def _news_segments(self, selected, language):
        rows = []
        for item in selected:
            category = item["category"]
            label = LABELS[category][language == "ar"]
            publication = parse_date(item["publishedAt"]).strftime("%Y-%m-%d %H:%M")
            updated = item.get("publicationDateType") == "updated" or item.get("publicationDateField") == "updated"
            if language == "ar":
                verb = "حدّث المصدر هذا الخبر" if updated else "نشر المصدر هذا الخبر"
                text = f"هنا راديو ميلو. {label}. بحسب {item['outlet']}: {item['title'].rstrip('.?! ')}. {verb} في {publication} بالتوقيت العالمي."
            else:
                verb = "Updated" if updated else "Published"
                text = f"Melo Radio. {label}. {item['outlet']} reports: {item['title'].rstrip('.?! ')}. {verb} {publication} UTC."
            identity = "news-" + hashlib.sha256((language + item["url"]).encode()).hexdigest()[:20]
            source = {key: item[key] for key in ("title", "url", "outlet", "publishedAt", "checkedAt", "sourceId")}
            date_evidence = {key: item[key] for key in ("publicationDateType", "publicationDateField", "publicationDateOriginal") if key in item}
            if updated:
                date_evidence["publicationDateType"] = "updated"
            source.update(date_evidence)
            rows.append({"id": identity, "type": "news", "language": language, "title": label + ": " + item["title"],
                         "text": text, "category": category, "publishedAt": item["publishedAt"],
                         "fetchedAt": item["checkedAt"], "outlet": item["outlet"], "sources": [source],
                         "newsFormat": "native-attributed-headline", **date_evidence})
        return rows

    def _annotate_selection(self, items, language, now):
        """Optional synchronous ranking/dedup hook cannot modify source facts.

        An external model, if configured by the owner, must finish/exit inside
        this call before the sequential synthesis stage begins. Its only stored
        additions are bounded topic/confidence sidecars, never spoken text.
        """
        if self.selector is None:
            return items
        proposed = self.selector(copy.deepcopy(items), language, now)
        if not isinstance(proposed, list) or not self.minimum_headlines <= len(proposed) <= 13:
            raise ValueError("The selection hook must retain enough native source headlines")
        original = {item["url"]: item for item in items}
        result, seen = [], set()
        for item in proposed:
            if not isinstance(item, dict) or item.get("url") not in original or item["url"] in seen:
                raise ValueError("The selection hook may only rank existing source headlines")
            trusted = original[item["url"]]
            if any(item.get(key) != value for key, value in trusted.items()):
                raise ValueError("The selection hook changed a publisher fact")
            seen.add(item["url"])
            row = copy.deepcopy(trusted)
            topics = item.get("semanticCategories")
            if isinstance(topics, list) and len(topics) <= len(LABELS) and all(x in LABELS for x in topics):
                row["semanticCategories"] = list(dict.fromkeys(topics))
            confidence = item.get("dedupConfidence")
            if isinstance(confidence, (int, float)) and not isinstance(confidence, bool) and math.isfinite(confidence) and 0 <= confidence <= 1:
                row["dedupConfidence"] = confidence
            result.append(row)
        return result

    def build_once(self):
        """Worker entry point; tests may call it with injected offline services."""
        with self._build_mutex:
            return self._build_locked()

    def _build_locked(self):
        catalogs = {}
        for language in LANGUAGES:
            event = self.catalog_store.start_refresh(language)
            if event is not None:
                event.wait(20)  # Worker wait only; HTTP never waits for speech.
            catalogs[language] = self.catalog_store.cached(language)
        now = self.clock()
        selected = {language: select_headlines(catalogs[language], self.catalog_store.configs[language],
                    language, now, self.minimum_headlines) for language in LANGUAGES}
        selected = {language: self._annotate_selection(items, language, now) for language, items in selected.items()}
        previous = self._active()
        plans = {}
        for language in LANGUAGES:
            old = previous["programs"][language] if previous else None
            entertainment, rotation, stamp = self._entertainment(language, old, now)
            plans[language] = {"segments": entertainment + self._news_segments(selected[language], language),
                               "rotation": rotation, "entertainmentUpdatedAt": stamp}
        binding = {"renderer": RENDERER_VERSION, "sources": selected,
                   "entertainment": {lang: {k: v for k, v in plan.items() if k != "segments"} for lang, plan in plans.items()}}
        fingerprint = hashlib.sha256(canonical(binding)).hexdigest()
        if previous and previous.get("fingerprint") == fingerprint:
            return previous
        version = "radio-" + now.strftime("%Y%m%dT%H%M%S") + "-" + fingerprint[:12]
        programs = {}
        total = sum(len(plan["segments"]) for plan in plans.values())
        completed = 0
        for language in LANGUAGES:
            entries = []
            for segment in plans[language]["segments"]:
                with self._mutex:
                    self._progress = {"language": language, "completedSegments": completed, "totalSegments": total}
                entries.append(self._asset(segment))
                completed += 1
            catalog = catalogs[language]
            checked_at = max(item["checkedAt"] for item in selected[language])
            categories = sorted({item["category"] for item in selected[language]})
            gaps = [{"category": category, "reason": "no_current_native_headline",
                     "label": LABELS[category][language == "ar"]}
                    for category in LABELS if category not in categories]
            notices = [(gap["label"] + ": لا يتوفر عنوان حديث متحقق منه بلغته الأصلية."
                        if language == "ar" else gap["label"] + ": no current verified native-language headline available")
                       for gap in gaps]
            metadata = {"fetchedAt": checked_at, "collectionAttemptedAt": catalog["runCheckedAt"],
                        "latestPublication": max(item["publishedAt"] for item in selected[language]),
                        "headlineCount": len(selected[language]), "sourceLanguage": language,
                        "sourceMode": "independent-native-publisher-headlines",
                        "coverageGapNotices": copy.deepcopy(catalog.get("coverageGapNotices", [])) + gaps,
                        "oldFeedNotice": notices,
                        "categoryCoverage": copy.deepcopy(catalog.get("categories", {})),
                        "categories": categories}
            program = {"version": version, "language": language, "epoch": self.content["languages"][language]["epoch"],
                       "newsUpdatedAt": checked_at, "collectionAttemptedAt": catalog["runCheckedAt"],
                       "generatedAt": iso(self.clock()),
                       "entertainmentUpdatedAt": plans[language]["entertainmentUpdatedAt"],
                       "jokeBankRotation": plans[language]["rotation"],
                       "entertainmentMode": "Reviewed joke bank rotates; four reviewed fictional story texts remain fixed.",
                       "voiceEngine": "edge-neural", "voice": "Melo relaxed native neural ensemble",
                       "origin": "server", "audioOrigin": "server", "generationState": "complete",
                       "sourceMode": "independent-native-publisher-headlines", "newsMetadata": metadata,
                       "headlines": copy.deepcopy(selected[language]), "segments": entries,
                       "duration": sum(x["duration"] for x in entries)}
            programs[language] = program
        pair = {"schemaVersion": 1, "generationState": "complete", "version": version,
                "fingerprint": fingerprint, "activatedAt": iso(self.clock()), "programs": programs}
        # All files are immutable and independently complete before the single
        # pointer becomes visible. Neither language can become active alone.
        atomic_json(self.directory / "editions" / (version + ".json"), pair)
        atomic_json(self.directory / "active.json", {"version": version})
        try:
            self._prune(pair)
        except OSError:
            pass  # Retention cleanup must not turn an activated edition into failure.
        return pair

    def _prune(self, active):
        paths = sorted((self.directory / "editions").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        kept = {active["version"]}
        for path in paths:
            if len(kept) >= 3:
                break
            kept.add(path.stem)
        referenced = set()
        for path in paths:
            if path.stem in kept:
                try:
                    pair = load(path)
                    for program in pair["programs"].values():
                        referenced.update(x["file"][len(AUDIO_ROUTE):-4] for x in program["segments"] if x["file"].startswith(AUDIO_ROUTE))
                except (OSError, ValueError, KeyError):
                    return  # Preserve files when retention evidence is unreadable.
        # Failed-build assets remain useful for a retry. Bound unreferenced
        # cache by age, not immediately, so interrupted work resumes cheaply.
        cutoff = time.time() - 48 * 3600
        for path in (self.directory / "audio").glob("*.mp3"):
            if path.stem not in referenced and path.stat().st_mtime < cutoff:
                path.unlink()
        for path in paths:
            if path.stem not in kept:
                path.unlink()
