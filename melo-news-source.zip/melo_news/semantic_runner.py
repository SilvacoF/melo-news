"""One-shot CPU embedding advice; this module never generates or edits news.

stdin: {"items":[{"id":"1","title":"...","language":"en"}],
        "categories":["world","technology","ai","economy","sports",...]}
stdout: {"ok":true,"results":[{"id":"1","category":"ai",...}],...}

Run only as a child process between source collection and TTS; it starts and
terminates its own local llama.cpp embedding process. Positive/offbeat remain
publisher-only sections and are excluded from semantic classification.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import math
import os
from pathlib import Path
import socket
import signal
import subprocess
import sys
import threading
import time
import urllib.request

import psutil

LABELS = {
    "world": "World news, international diplomacy, governments, foreign ministers, ceasefire talks and global politics.",
    "technology": "Technology news about computers, smartphones, software, cybersecurity, internet and digital devices.",
    "ai": "Artificial intelligence news about machine learning, language models, neural networks and generative AI.",
    "economy": "Economic news about central banks, interest rates, business, markets, inflation, trade and finance.",
    "sports": "Sport news about football, athletes, competitions, matches, cup finals and championship results.",
    "nature": "Nature and environment news about wildlife, protected species, biodiversity, conservation and ecosystems.",
    "travel": "Travel and tourism news about holiday destinations, hotels, tourist visits, railway journeys and vacations.",
    "history": "History and archaeology news about ancient civilizations, Roman remains, excavations and historical artifacts.",
    "science": "Science news about astronomy, planets, space, physics, laboratories and scientific discoveries.",
}
PUBLISHER_ONLY = {"positive", "offbeat"}
MODEL_ID = "unsloth/embeddinggemma-2-GGUF:embeddinggemma-2-UD-Q4_K_XL.gguf"
MODEL_REVISION = "031f0d4b35536f69ab3509d4893c923264fcf253"


def _linux_parent_death_signal(expected_parent):
    # The wrapper may impose its own90-second timeout. If it kills this helper,
    # Linux also kills the model process immediately, rather than orphaning it.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL) != 0:  # PR_SET_PDEATHSIG
        os._exit(126)
    if os.getppid() != expected_parent:
        os._exit(126)


def similarity(a, b):
    norm_a = math.sqrt(sum(x*x for x in a))
    norm_b = math.sqrt(sum(x*x for x in b))
    if norm_a == 0 or norm_b == 0:
        raise ValueError("Invalid zero embedding")
    return sum(x*y for x,y in zip(a,b)) / (norm_a*norm_b)


def validate_payload(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise ValueError("Expected an items array")
    items = payload["items"]
    if not 1 <= len(items) <= 64:
        raise ValueError("Expected one to64 headlines")
    seen = set()
    for item in items:
        if (not isinstance(item, dict) or not isinstance(item.get("id"), str)
                or not 1 <= len(item["id"]) <= 200 or item["id"] in seen
                or not isinstance(item.get("title"), str) or not item["title"].strip()
                or len(item["title"]) > 350 or "\x00" in item["title"]
                or item.get("language", "en") not in {"en", "ar"}):
            raise ValueError("Invalid bounded headline record")
        seen.add(item["id"])
    categories = payload.get("categories", list(LABELS))
    if (not isinstance(categories, list) or not categories
            or any(not isinstance(x, str) or x not in set(LABELS) | PUBLISHER_ONLY for x in categories)):
        raise ValueError("Unknown category IDs")
    selected = {key: LABELS[key] for key in categories if key in LABELS}
    if len(selected) < 2:
        raise ValueError("At least two non-publisher-only categories are required")
    return items, selected


def resolve_runner(library_path):
    path = Path(library_path).resolve()
    if path.is_dir():
        names = ["llama-server.exe"] if os.name == "nt" else ["llama-server"]
        candidates = [path / name for name in names]
        candidates.extend(path / "llama-b11669" / name for name in names)
        path = next((p for p in candidates if p.is_file()), candidates[0])
    if not path.is_file():
        raise ValueError("Pinned llama-server binary is unavailable")
    return path


def classify(payload, *, model_path, library_path, timeout=90, context=128, memory_limit_mib=320):
    items, labels = validate_payload(payload)
    if not 128 <= context <= 256 or not 1 <= timeout <= 90 or not 256 <= memory_limit_mib <= 384:
        raise ValueError("Invalid bounded inference settings")
    model = Path(model_path).resolve()
    if not model.is_file():
        raise ValueError("Pinned embedding model is unavailable")
    runner = resolve_runner(library_path)
    inputs = ["task: classification | query: " + text for text in labels.values()]
    inputs.extend("task: classification | query: " + row["title"] for row in items)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    command = [str(runner), "-m", str(model), "--embeddings", "--pooling", "mean",
               "-c", str(context), "-b", str(context), "-ub", str(context), "--parallel", "1",
               "-t", "1", "-tb", "1", "--host", "127.0.0.1", "--port", str(port),
               "--no-warmup", "--offline", "--gpu-layers", "0", "--fit", "off",
               "--cache-ram", "0", "--no-mmproj"]
    environment = os.environ.copy()
    environment["OMP_NUM_THREADS"] = environment["OPENBLAS_NUM_THREADS"] = "1"
    # Read only local weights; never pass any model, deployment, or service token.
    for key in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN"):
        environment.pop(key, None)
    stop = threading.Event()
    metrics = {"peakChildRssBytes": 0, "peakOsWorkingSetBytes": 0,
               "peakWorkerAndChildRssBytes": 0, "stoppedReason": None}
    started = time.perf_counter()
    expected_parent = os.getpid()
    process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               stdin=subprocess.DEVNULL, env=environment,
                               start_new_session=(os.name != "nt"),
                               preexec_fn=(lambda: _linux_parent_death_signal(expected_parent)) if sys.platform == "linux" else None)
    child, worker = psutil.Process(process.pid), psutil.Process()
    if os.name == "nt":
        child.cpu_affinity([child.cpu_affinity()[0]])
    def monitor():
        while not stop.is_set() and process.poll() is None:
            try:
                memory = child.memory_info()
                metrics["peakChildRssBytes"] = max(metrics["peakChildRssBytes"], memory.rss)
                metrics["peakOsWorkingSetBytes"] = max(metrics["peakOsWorkingSetBytes"], getattr(memory, "peak_wset", memory.rss))
                metrics["peakWorkerAndChildRssBytes"] = max(metrics["peakWorkerAndChildRssBytes"], memory.rss + worker.memory_info().rss)
                if memory.rss > memory_limit_mib * 1024 * 1024:
                    metrics["stoppedReason"] = "memory_limit"
                elif time.perf_counter() - started > timeout:
                    metrics["stoppedReason"] = "deadline"
                if metrics["stoppedReason"]:
                    process.kill()
                    return
            except psutil.Error:
                return
            stop.wait(.01)
    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()
    base = "http://127.0.0.1:" + str(port)
    # Ignore proxy environment variables for the loopback-only worker API.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        while True:
            if process.poll() is not None:
                raise RuntimeError(metrics["stoppedReason"] or "embedding_start_failed")
            try:
                with opener.open(base + "/health", timeout=.5) as response:
                    if response.status == 200:
                        break
            except OSError:
                pass
            if time.perf_counter() - started > min(30, timeout):
                raise TimeoutError("embedding_start_deadline")
            time.sleep(.05)
        startup = time.perf_counter() - started
        request = urllib.request.Request(base + "/v1/embeddings", data=json.dumps({
            "model": "embeddinggemma2", "input": inputs, "encoding_format": "float"}).encode(),
            headers={"Content-Type": "application/json"})
        with opener.open(request, timeout=max(.1, timeout - (time.perf_counter() - started))) as response:
            raw = json.load(response)
        vectors = [row["embedding"] for row in sorted(raw["data"], key=lambda row:row["index"])]
        if len(vectors) != len(inputs) or not all(len(v) == 768 and all(math.isfinite(x) for x in v) for v in vectors):
            raise ValueError("invalid_embedding_vectors")
        rows = []
        for item, vector in zip(items, vectors[len(labels):]):
            scores = sorted(({"category": label, "score": similarity(vector, target)}
                             for label, target in zip(labels, vectors[:len(labels)])),
                            key=lambda row:row["score"], reverse=True)
            margin = scores[0]["score"] - scores[1]["score"]
            rows.append({"id": item["id"], "category": scores[0]["category"],
                         "score": scores[0]["score"], "margin": margin,
                         "scores": {row["category"]: row["score"] for row in scores},
                         "lowConfidence": scores[0]["score"] < .72 or margin < .02})
        result = {"ok": True, "results": rows, "model": MODEL_ID, "revision": MODEL_REVISION,
                  "advisoryOnly": True, "generatedText": False, "dimensions": 768,
                  "excludedPublisherOnlyCategories": sorted(PUBLISHER_ONLY),
                  "startupSeconds": round(startup, 4), "wallSeconds": round(time.perf_counter() - started, 4)}
    finally:
        stop.set()
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        monitor_thread.join(timeout=1)
    result["metrics"] = metrics
    result["childTerminated"] = process.poll() is not None
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", required=True, type=Path)
    parser.add_argument("--library-path", required=True, type=Path,
                        help="Pinned llama-server binary or its containing directory")
    parser.add_argument("--timeout", type=float, default=90)
    parser.add_argument("--context", type=int, default=128)
    parser.add_argument("--memory-limit-mib", type=int, default=320)
    args = parser.parse_args(argv)
    try:
        raw = sys.stdin.buffer.read(65537)
        if len(raw) > 65536:
            raise ValueError("input_too_large")
        result = classify(json.loads(raw), model_path=args.model_path, library_path=args.library_path,
                          timeout=args.timeout, context=args.context, memory_limit_mib=args.memory_limit_mib)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except Exception as error:
        print(json.dumps({"ok": False, "error": type(error).__name__, "results": []}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
