import json
import io
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from unittest.mock import Mock

from melo_news import semantic_runner as runner


class SafeFailureTests(unittest.TestCase):
    def test_native_failures_map_only_to_safe_enums(self):
        fixtures = [
            (b'error while loading shared libraries: /secret/library.so: cannot open shared object file',127,'missing_library'),
            (b'unknown argument: --private-path',1,'unsupported_argument'),
            (b'failed to load model /private/file.gguf',1,'model_load_failed'),
            (b'input is too large for context',1,'context_limit'),
            (b'bad_alloc with https://signed.example?token=DO_NOT_LOG',-6,'memory_limit'),
            (b'no suitable backend',1,'backend_unavailable'),
            (b'permission denied at /private/file',1,'runtime_permission_denied'),
            (b'arbitrary native text with DO_NOT_LOG',-4,'illegal_instruction'),
        ]
        for text,code,expected in fixtures:
            with self.subTest(expected=expected):
                actual=runner.safe_failure_code(text,code,'embedding_start_failed')
                self.assertEqual(actual,expected)
                self.assertIn(actual,runner.FAILURE_CODES)
                self.assertNotIn('DO_NOT_LOG',actual)

    def test_monitor_limit_takes_priority_over_generic_native_error(self):
        self.assertEqual(runner.safe_failure_code(b'failed to load model',-9,'embedding_start_failed','memory_limit'),'memory_limit')
        self.assertEqual(runner.safe_failure_code(b'',-9,'embedding_start_failed','deadline'),'deadline')

    def test_unknown_failure_does_not_leak_native_text(self):
        code=runner.safe_failure_code(b'https://signed.example?DO_NOT_LOG',1,'DO_NOT_LOG')
        self.assertEqual(code,'embedding_failed')
        value=runner.failure_result('DO_NOT_LOG',exit_code=1,metrics={'peakChildRssBytes':123},child_terminated=True)
        self.assertEqual(value['errorCode'],'embedding_failed')
        self.assertEqual(value['exitCode'],1)
        self.assertTrue(value['childTerminated'])
        self.assertNotIn('DO_NOT_LOG',json.dumps(value))

    def test_missing_model_returns_structured_failure_without_spawn(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(runner.subprocess,'Popen') as spawn:
            result=runner.classify({'items':[{'id':'x','title':'A headline'}]},model_path=Path(directory)/'absent.gguf',library_path=directory)
        self.assertFalse(result['ok'])
        self.assertEqual(result['errorCode'],'model_unavailable')
        self.assertIsNone(result['exitCode'])
        self.assertTrue(result['childTerminated'])
        spawn.assert_not_called()

    def test_bad_payload_returns_safe_failure_without_spawn(self):
        with patch.object(runner.subprocess,'Popen') as spawn:
            result=runner.classify({'items':[]},model_path='unused',library_path='unused')
        self.assertEqual(result['errorCode'],'invalid_input')
        spawn.assert_not_called()

    def test_early_native_exit_returns_safe_code_exit_and_cleanup(self):
        native=Mock()
        native.pid=429496729
        native.stderr=io.BytesIO(b'error while loading shared libraries: /private/path; https://signed.example?DO_NOT_LOG')
        native.returncode=127
        native.poll.return_value=127
        native.wait.return_value=127
        with tempfile.TemporaryDirectory() as directory:
            model=Path(directory)/'model.gguf';model.write_bytes(b'fixture')
            executable=Path(directory)/'llama-server';executable.write_bytes(b'fixture')
            with patch.object(runner.subprocess,'Popen',return_value=native):
                result=runner.classify({'items':[{'id':'x','title':'A headline'}]},model_path=model,library_path=executable)
        self.assertEqual(result['errorCode'],'missing_library')
        self.assertEqual(result['exitCode'],127)
        self.assertTrue(result['childTerminated'])
        self.assertIn('elapsedSeconds',result['metrics'])
        self.assertNotIn('DO_NOT_LOG',json.dumps(result))
        self.assertNotIn('/private/path',json.dumps(result))

    def test_native_capture_is_bounded_and_retains_last_failure(self):
        native=Mock()
        native.pid=429496729
        native.stderr=io.BytesIO(b'x'*(runner.MAX_INTERNAL_STDERR*3)+b'\nunknown argument: secret-option')
        native.returncode=1
        native.poll.return_value=1
        native.wait.return_value=1
        with tempfile.TemporaryDirectory() as directory:
            model=Path(directory)/'model.gguf';model.write_bytes(b'fixture')
            executable=Path(directory)/'llama-server';executable.write_bytes(b'fixture')
            with patch.object(runner.subprocess,'Popen',return_value=native):
                result=runner.classify({'items':[{'id':'x','title':'A headline'}]},model_path=model,library_path=executable)
        self.assertEqual(result['errorCode'],'unsupported_argument')
        self.assertLess(len(json.dumps(result)),2000)


if __name__=='__main__':unittest.main()
