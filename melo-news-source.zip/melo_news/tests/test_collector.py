import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

from melo_news.collector import (
    FeedClient, RunLock, canonical_url, collect_once, iso, merge_catalog,
    parse_date, parse_feed, validate_config,
)

NOW = dt.datetime(2026, 10, 16, 12, 0, tzinfo=dt.timezone.utc)
CHECK = "2026-10-16T12:00:00Z"
OLD_CHECK = "2026-10-16T11:00:00Z"
SOURCE = {"id": "bbc-world", "publisher": "BBC News", "category": "world",
          "url": "https://feeds.bbci.co.uk/news/world/rss.xml",
          "articleHosts": ["www.bbc.co.uk"]}


def settings():
    config = json.loads((Path(__file__).resolve().parents[1] / "sources.json").read_text())
    config["categories"] = {k: config["categories"][k] for k in ("world", "technology")}
    config["sources"] = [copy.deepcopy(SOURCE), {**SOURCE, "id": "bbc-tech", "category": "technology"}]
    config["itemsPerCategory"] = 2
    config["historyLimit"] = 2
    return config


def item(title="Headline", url="https://www.bbc.co.uk/news/a", category="world", check=CHECK):
    return {"id": url.rsplit("/", 1)[-1], "title": title, "url": url, "sourceUrl": url,
            "outlet": "BBC News", "feedUrl": SOURCE["url"], "sourceId": "bbc-world" if category == "world" else "bbc-tech",
            "category": category, "publishedAt": "2026-10-16T10:00:00Z",
            "checkedAt": check, "retained": False,
            "publicationDateOriginal": "Fri, 16 Oct 2026 10:00:00 GMT",
            "publicationDateField": "pubDate"}


def result(items, category="world", ok=True, check=CHECK):
    value = {"id": "bbc-world" if category == "world" else "bbc-tech",
             "category": category, "publisher": "BBC News", "url": SOURCE["url"],
             "items": items, "ok": ok, "attemptedAt": check, "rejected": {}}
    if ok:
        value["checkedAt"] = check
    else:
        value["error"] = "TimeoutError"
    return value


class CollectorTests(unittest.TestCase):
    def test_dates_reject_ambiguous_timezone_and_invalid(self):
        for value in (None, "not a date", "2026-10-16", "2026-10-16T10:00:00", "Fri, 16 Oct 2026 10:00:00"):
            self.assertIsNone(parse_date(value), value)
        self.assertEqual(parse_date("Fri, 16 Oct 2026 12:00:00 +0200"),
                         dt.datetime(2026, 10, 16, 10, tzinfo=dt.timezone.utc))
        self.assertEqual(parse_date("2026-10-16T10:00:00Z").utcoffset(), dt.timedelta())

    def test_rss_uses_original_publication_never_build_or_fetch_date(self):
        xml = b'''<rss><channel><lastBuildDate>Fri, 16 Oct 2026 12:00:00 GMT</lastBuildDate>
          <item><title>Headline &amp; qualification</title><link>https://www.bbc.co.uk/news/a?utm_source=x</link><pubDate>Fri, 16 Oct 2026 10:00:00 GMT</pubDate></item>
          <item><title>Undated</title><link>https://www.bbc.co.uk/news/b</link></item>
          <item><title>Future</title><link>https://www.bbc.co.uk/news/c</link><pubDate>Fri, 16 Oct 2026 12:01:00 GMT</pubDate></item>
          <item><title>Too old</title><link>https://www.bbc.co.uk/news/d</link><pubDate>Wed, 14 Oct 2026 10:00:00 GMT</pubDate></item>
        </channel></rss>'''
        items, rejected = parse_feed(xml, SOURCE, CHECK, NOW, 24)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["publishedAt"], "2026-10-16T10:00:00Z")
        self.assertEqual(items[0]["checkedAt"], CHECK)
        self.assertEqual(items[0]["title"], "Headline & qualification")
        self.assertEqual(items[0]["sourceUrl"], "https://www.bbc.co.uk/news/a")
        self.assertEqual(rejected, {"missing_or_ambiguous_publication_date": 1,
                                    "future_publication_date": 1,
                                    "outside_category_publication_window": 1})

    def test_atom_updated_is_not_invented_publication(self):
        xml = b'''<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Only modified date</title><link href="https://www.bbc.co.uk/news/a"/><updated>2026-10-16T10:00:00Z</updated></entry></feed>'''
        items, rejected = parse_feed(xml, SOURCE, CHECK, NOW, 24)
        self.assertEqual(items, [])
        self.assertEqual(rejected["missing_or_ambiguous_publication_date"], 1)

    def test_rejects_entities_and_untrusted_article_hosts(self):
        with self.assertRaises(ValueError):
            parse_feed(b'<!DOCTYPE rss [<!ENTITY x "bad">]><rss/>', SOURCE, CHECK, NOW, 24)
        self.assertIsNone(canonical_url("https://www.bbc.co.uk.evil.example/news/a", {"www.bbc.co.uk"}))
        self.assertIsNone(canonical_url("https://secret@www.bbc.co.uk/news/a", {"www.bbc.co.uk"}))

    def test_failed_source_keeps_original_checked_at_while_other_category_refreshes(self):
        old = merge_catalog(settings(), [result([item(check=OLD_CHECK)], check=OLD_CHECK), result([], "technology")], now=NOW)
        new = merge_catalog(settings(), [result([], ok=False), result([item("New technology", "https://www.bbc.co.uk/news/t", "technology")], "technology")], old, NOW)
        retained = next(x for x in new["items"] if x["category"] == "world")
        self.assertEqual(retained["checkedAt"], OLD_CHECK)
        self.assertTrue(retained["retained"])
        self.assertEqual(new["categories"]["world"]["freshItemIds"], [])
        self.assertEqual(new["categories"]["world"]["status"], "retained")
        self.assertEqual(new["categories"]["technology"]["status"], "current")
        self.assertEqual(new["status"], "degraded")
        self.assertNotIn("checkedAt", new["sources"][0])

    def test_successful_feed_without_current_items_preserves_cached_item_dates(self):
        old = merge_catalog(settings(), [result([item(check=OLD_CHECK)], check=OLD_CHECK)], now=NOW)
        new = merge_catalog(settings(), [result([])], old, NOW)
        self.assertEqual(new["items"][0]["checkedAt"], OLD_CHECK)
        self.assertTrue(new["items"][0]["retained"])
        self.assertEqual(new["categories"]["world"]["status"], "retained")

    def test_dedup_chain_and_category_evidence_fresh_copy_wins(self):
        one = item("Same title", "https://www.bbc.co.uk/news/a", check=OLD_CHECK)
        one["retained"] = True
        two = item("Same title!", "https://www.bbc.co.uk/news/b", "technology")
        three = item("Revised title", "https://www.bbc.co.uk/news/a", "technology")
        value = merge_catalog(settings(), [result([one]), result([two, three], "technology")], now=NOW)
        self.assertEqual(len(value["items"]), 1)
        self.assertFalse(value["items"][0]["retained"])
        self.assertEqual(set(value["items"][0]["categories"]), {"world", "technology"})
        self.assertEqual(value["categories"]["world"]["freshItemIds"], [])
        self.assertTrue(value["categories"]["technology"]["freshItemIds"])

    def test_category_selection_does_not_starve_quieter_topics(self):
        worlds = [item("World " + str(n), "https://www.bbc.co.uk/news/w" + str(n)) for n in range(20)]
        tech = item("Technology", "https://www.bbc.co.uk/news/t", "technology")
        value = merge_catalog(settings(), [result(worlds), result([tech], "technology")], now=NOW)
        self.assertEqual(len(value["categories"]["world"]["itemIds"]), 2)
        self.assertEqual(len(value["categories"]["technology"]["itemIds"]), 1)

    def test_old_cache_expires_without_being_newly_checked(self):
        value = item(check=OLD_CHECK)
        value["publishedAt"] = "2026-09-01T10:00:00Z"
        previous = {"sources": [result([value], check=OLD_CHECK)]}
        catalog = merge_catalog(settings(), [result([], ok=False)], previous, NOW)
        self.assertEqual(catalog["items"], [])
        self.assertEqual(catalog["status"], "failed")

    def test_explicit_feed_allowlist_and_bounded_retries(self):
        config = settings()
        validate_config(config)
        config["sources"][0]["url"] = "https://localhost/feed"
        with self.assertRaises(ValueError):
            validate_config(config)

    def test_long_publisher_retry_after_is_deferred_without_hammering(self):
        error = urllib.error.HTTPError(SOURCE["url"], 429, "rate limited",
                                       {"Retry-After": "120"}, None)
        addresses = [(2, 1, 6, "", ("8.8.8.8", 443))]
        with patch("melo_news.collector.socket.getaddrinfo", return_value=addresses), \
                patch("melo_news.collector.urllib.request.build_opener") as opener, \
                patch("melo_news.collector.time.sleep") as sleep:
            opener.return_value.open.side_effect = error
            value = FeedClient(retries=1).fetch(SOURCE, 24)
        self.assertFalse(value["ok"])
        self.assertEqual(value["attempts"], 1)
        self.assertEqual(value["httpStatus"], 429)
        self.assertTrue(value["retryDeferred"])
        self.assertNotIn("checkedAt", value)
        sleep.assert_not_called()

    def test_private_publisher_dns_is_rejected_without_http(self):
        addresses = [(2, 1, 6, "", ("127.0.0.1", 443))]
        with patch("melo_news.collector.socket.getaddrinfo", return_value=addresses), \
                patch("melo_news.collector.urllib.request.build_opener") as opener:
            value = FeedClient(retries=1).fetch(SOURCE, 24)
        self.assertFalse(value["ok"])
        self.assertEqual(value["attempts"], 1)
        opener.assert_not_called()
        config = settings()
        config["retries"] = 100
        with self.assertRaises(ValueError):
            validate_config(config)

    def test_atomic_output_history_limit_and_os_lock(self):
        class FakeClient:
            def fetch(self, source, age):
                return result([item(category=source["category"])], source["category"])
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "catalog.json"
            for _ in range(3):
                catalog, health = collect_once(settings(), output, FakeClient())
            self.assertEqual(json.loads(output.read_text())["version"], catalog["version"])
            self.assertEqual(len(list((Path(directory) / "catalog-history").glob("*.json"))), 2)
            self.assertTrue((Path(directory) / "health.json").is_file())
            with RunLock(Path(directory) / "lock"):
                with self.assertRaises(RuntimeError):
                    with RunLock(Path(directory) / "lock"):
                        pass
            with RunLock(Path(directory) / "lock"):
                pass


if __name__ == "__main__":
    unittest.main()
