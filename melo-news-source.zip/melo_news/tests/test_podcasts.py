import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest

from melo_news import radio
from melo_news.podcasts import PodcastStore, choose_reports
from melo_news.tests.test_radio import Catalogs


class PodcastTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.now = dt.datetime(2026, 10, 16, 12, 0, tzinfo=dt.timezone.utc)
        self.fail = None
        self.calls = []

        def render(segment, output, profile):
            if self.fail == segment['language']:
                raise RuntimeError('Injected native voice failure')
            self.calls.append((segment['language'], segment['text']))
            output.write_bytes(radio.canonical({'text': segment['text']}))

        def verify(path):
            value = json.loads(path.read_bytes())
            return {'duration': len(value['text'].split()) / 2 + 3}

        def compose(paths, parts, output):
            self.assertEqual([json.loads(path.read_bytes())['text'] for path in paths], [part['text'] for part in parts])
            output.write_bytes(radio.canonical({'text': '\n\n'.join(part['text'] for part in parts)}))

        self.radio = radio.RadioStore(Path(temporary.name), Catalogs(self.now),
            renderer=render, verifier=verify, clock=lambda: self.now, minimum_headlines=8)
        self.radio.build_once()
        self.store = PodcastStore(self.radio, clock=lambda: self.now, composer=compose)

    def test_bilingual_activation_exact_sources_three_airings_and_no_news_cue(self):
        pair = self.store.build_once()
        self.assertEqual(set(pair['episodes']), {'en', 'ar'})
        for lang, episode in pair['episodes'].items():
            self.assertEqual(len(episode['sources']), 4)
            self.assertEqual([airing['repeat'] for airing in episode['airings']], [0, 1, 2])
            created = radio.parse_date(episode['createdAt'])
            self.assertEqual([(radio.parse_date(row['at']) - created).total_seconds() for row in episode['airings']], [0, 3600, 9000])
            self.assertEqual((radio.parse_date(episode['expiresAt']) - created).total_seconds(), 10800)
            self.assertTrue(episode['ttsVoice'].startswith(lang + '-'))
            self.assertNotIn('newsCue', episode)
            self.assertNotIn('Live news!', episode['text'])
            for source in episode['sources']:
                self.assertIn(source.get('narratedSummary', source['title']), episode['text'])
                self.assertEqual(source['checkedAt'], '2026-10-16T12:00:00Z')
            self.assertEqual(radio.file_hash(self.radio.audio_file(episode['audioSha256'])), episode['audioSha256'])

    def test_ten_minute_cadence_cache_reuse_and_no_catchup_backlog(self):
        first = self.store.build_once()
        calls = len(self.calls)
        self.now += dt.timedelta(minutes=9)
        self.assertEqual(self.store.build_once(), first)
        self.assertEqual(len(self.calls), calls)
        self.now += dt.timedelta(minutes=1)
        second = self.store.build_once()
        self.assertNotEqual(first['id'], second['id'])
        self.assertEqual(len(self.store.retained()), 2)
        self.assertEqual(second['episodes']['ar']['newsUpdatedAt'], first['episodes']['ar']['newsUpdatedAt'])
        # Cached host lines and recurring exact source speech never regenerate.
        self.assertEqual(len([text for _, text in self.calls if text.startswith('Welcome to the Melo podcast')]), 1)
        self.now += dt.timedelta(hours=4)
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.assertEqual(len(self.store.retained()), 2)
        self.assertEqual(self.store.response('en')[1]['episodes'], [])

    def test_arabic_failure_retains_pair_and_resumes_english_fragments(self):
        first = self.store.build_once()
        pointer = self.store.path.read_bytes()
        self.now += dt.timedelta(minutes=10)
        self.fail = 'ar'
        with self.assertRaises(RuntimeError):
            self.store.build_once()
        self.assertEqual(self.store.path.read_bytes(), pointer)
        english = len([row for row in self.calls if row[0] == 'en'])
        self.fail = None
        self.store.build_once()
        self.assertEqual(len([row for row in self.calls if row[0] == 'en']), english)
        self.assertEqual(self.store.retained()[0], first)

    def test_selection_uses_advisory_topics_without_changing_facts(self):
        program = self.radio._active()['programs']['en']
        original = copy.deepcopy(program)
        selected = choose_reports(program, 13)
        self.assertEqual(len({row['sources'][0]['url'] for row in selected}), 4)
        self.assertEqual(program, original)
        self.assertEqual(choose_reports(program, 13), selected)
        self.assertNotEqual(choose_reports(program, 14), selected)


if __name__ == '__main__':
    unittest.main()
