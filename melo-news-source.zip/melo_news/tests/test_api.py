import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
import urllib.request
import urllib.error

from melo_news.api import BoundedHTTPServer, CatalogStore, handler_for
from melo_news.collector import atomic_json, iso, utcnow


def catalog(language="en", age=0):
    now = utcnow() - dt.timedelta(seconds=age)
    return {"schemaVersion": 1, "version": "test", "language": language,
            "status": "ok", "runCheckedAt": iso(now), "coverageGapNotices": [],
            "items": [{"id": "a", "publishedAt": iso(now), "checkedAt": iso(now),
                       "provenance": [{"category": "world", "retained": False,
                                       "publishedAt": iso(now)}]}],
            "categories": {"world": {"maxAgeHours": 24, "itemIds": ["a"], "freshItemIds": ["a"], "status": "current"}}}


class ApiTests(unittest.TestCase):
    def test_fresh_cache_does_not_fetch_or_change_checked_time(self):
        with tempfile.TemporaryDirectory() as directory:
            def forbidden(*args):
                self.fail("Fresh cache unexpectedly fetched")
            store = CatalogStore(directory, collect=forbidden)
            old = catalog()
            atomic_json(store.path("en"), old)
            status, value = store.response("en")
            self.assertEqual(status, 200)
            self.assertEqual(value["items"][0]["checkedAt"], old["items"][0]["checkedAt"])
            self.assertFalse(value["api"]["stale"])

    def test_concurrent_cold_requests_single_flight_and_bounded_wait(self):
        with tempfile.TemporaryDirectory() as directory:
            entered, release = threading.Event(), threading.Event()
            calls = []
            def slow(config, output, client):
                calls.append(output)
                entered.set()
                release.wait(3)
                atomic_json(output, catalog())
            store = CatalogStore(directory, request_wait_seconds=.02, collect=slow)
            start = time.monotonic()
            status, first = store.response("en")
            self.assertEqual(status, 202)
            self.assertLess(time.monotonic() - start, .5)
            self.assertTrue(first["api"]["refreshInProgress"])
            status, second = store.response("en")
            self.assertEqual(status, 202)
            self.assertEqual(len(calls), 1)
            release.set()
            store._jobs["en"].wait(2)
            self.assertEqual(store.response("en")[0], 200)

    def test_failure_keeps_dated_cache_and_health_remains_liveness(self):
        with tempfile.TemporaryDirectory() as directory:
            def broken(*args):
                raise TimeoutError("upstream failure")
            store = CatalogStore(directory, request_wait_seconds=.2, collect=broken)
            old = catalog(age=400)
            atomic_json(store.path("en"), old)
            status, value = store.response("en")
            self.assertEqual(status, 200)
            self.assertTrue(value["api"]["stale"])
            self.assertEqual(value["items"][0]["checkedAt"], old["items"][0]["checkedAt"])
            self.assertEqual(value["coverageGapNotices"][-1]["reason"], "collection_cache_stale")
            self.assertEqual(value["api"]["lastRefreshError"]["type"], "TimeoutError")
            self.assertEqual(store.health()["status"], "running")

    def test_expired_disk_cache_is_never_still_fresh_publication(self):
        with tempfile.TemporaryDirectory() as directory:
            def broken(*args):
                raise TimeoutError()
            store = CatalogStore(directory, request_wait_seconds=.2, collect=broken)
            atomic_json(store.path("en"), catalog(age=90000))
            status, value = store.response("en")
            self.assertEqual(value["categories"]["world"]["freshItemIds"], [])
            self.assertEqual(value["categories"]["world"]["status"], "retained")

    def test_native_arabic_kept_in_distinct_language_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CatalogStore(directory)
            native = catalog("ar")
            native["items"][0]["title"] = "عنوان عربي أصلي"
            atomic_json(store.path("ar"), native)
            self.assertEqual(store.response("ar")[1]["items"][0]["title"], "عنوان عربي أصلي")
            self.assertIsNone(store.cached("en"))

    def test_http_worker_capacity_returns_retryable_503(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CatalogStore(directory)
            server = BoundedHTTPServer(("127.0.0.1", 0), handler_for(store))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                for _ in range(16):
                    self.assertTrue(server._worker_slots.acquire(blocking=False))
                with self.assertRaises(urllib.error.HTTPError) as raised:
                    urllib.request.urlopen("http://127.0.0.1:" + str(server.server_port) + "/health", timeout=2)
                self.assertEqual(raised.exception.code, 503)
                self.assertEqual(raised.exception.headers.get("Retry-After"), "5")
                for _ in range(16):
                    server._worker_slots.release()
                with urllib.request.urlopen("http://127.0.0.1:" + str(server.server_port) + "/health", timeout=2) as response:
                    self.assertEqual(response.status, 200)
            finally:
                server.shutdown()
                server.server_close()


if __name__ == "__main__":
    unittest.main()
