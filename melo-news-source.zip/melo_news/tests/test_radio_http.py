"""Read-only radio routes and streaming never accept arbitrary file paths."""
import hashlib
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

from melo_news.api import BoundedHTTPServer, CatalogStore, handler_for


class RadioHttpTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        directory = Path(self.temporary.name)
        self.data = b'ID3' + bytes(range(256)) * 1024
        self.identity = hashlib.sha256(self.data).hexdigest()
        self.path = directory / (self.identity + '.mp3')
        self.path.write_bytes(self.data)
        fixture = self

        class Radio:
            def status(self):
                return {'state': 'ready', 'version': 'fixture'}

            def response(self, language):
                return 200, {'language': language, 'origin': 'server', 'version': 'fixture'}

            def audio_file(self, identity):
                return fixture.path if identity == fixture.identity else None

        store = CatalogStore(directory / 'news')
        self.server = BoundedHTTPServer(('127.0.0.1', 0), handler_for(store, Radio()))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.server.server_close)
        self.addCleanup(self.server.shutdown)
        self.base = 'http://127.0.0.1:' + str(self.server.server_port)

    def get(self, path=None, headers=None, method='GET'):
        path = path or '/radio/audio/' + self.identity + '.mp3'
        return urllib.request.urlopen(urllib.request.Request(self.base + path, headers=headers or {}, method=method), timeout=3)

    def test_audio_get_head_and_ranges_match_original_bytes(self):
        with self.get() as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.read(), self.data)
            self.assertEqual(response.headers['Accept-Ranges'], 'bytes')
        for value, expected in [('bytes=0-9', self.data[:10]), ('bytes=-17', self.data[-17:]),
                                ('bytes=100-', self.data[100:])]:
            with self.subTest(value=value), self.get(headers={'Range': value}) as response:
                self.assertEqual(response.status, 206)
                self.assertEqual(response.read(), expected)
                self.assertEqual(int(response.headers['Content-Length']), len(expected))
        with self.get(headers={'Range': 'bytes=0-9'}, method='HEAD') as response:
            self.assertEqual(response.status, 206)
            self.assertEqual(response.read(), b'')
            self.assertEqual(response.headers['Content-Length'], '10')

    def test_invalid_or_excessive_ranges_are_bounded(self):
        for value in ['bytes=10-2', 'bytes=-0', 'bytes=0-1,3-4', 'bytes=99999999-', 'bytes=' + '9' * 5000 + '-']:
            with self.subTest(value=value[:30]), self.assertRaises(urllib.error.HTTPError) as raised:
                self.get(headers={'Range': value})
            self.assertEqual(raised.exception.code, 416)
            self.assertEqual(raised.exception.headers['Content-Range'], 'bytes */' + str(len(self.data)))

    def test_only_known_hashes_and_native_languages_are_routed(self):
        for path in ['/radio/audio/' + 'f' * 64 + '.mp3', '/radio/audio/../../secret',
                     '/radio/audio/%2e%2e%2fsecret', '/radio/audio/' + self.identity.upper() + '.mp3']:
            with self.subTest(path=path), self.assertRaises(urllib.error.HTTPError) as raised:
                self.get(path)
            self.assertEqual(raised.exception.code, 404)
        for language in ('en', 'ar'):
            with self.get('/radio-program.json?language=' + language) as response:
                self.assertEqual(json.load(response)['language'], language)
        with self.assertRaises(urllib.error.HTTPError) as raised:
            self.get('/radio-program.json?language=unknown')
        self.assertEqual(raised.exception.code, 400)
        with self.get('/health') as response:
            self.assertEqual(json.load(response)['radio']['state'], 'ready')


if __name__ == '__main__':
    unittest.main()
