import array
from pathlib import Path
import tempfile
import unittest
import wave

from melo_news.news_cue import frame_news, write_sting
from melo_news.radio import speech_parts, transcode_parts, verify_audio


class NewsCueTests(unittest.TestCase):
    def test_native_announcements_preserve_body_sources_dates_and_valid_parts(self):
        for language, intro, outro in [('en', 'Live news!', 'Thanks!'), ('ar', 'حان وقت الأخبار!', 'شكرًا!')]:
            row = {'type': 'news', 'language': language, 'text': 'Exact publisher body.',
                   'sources': [{'title': 'Exact title', 'checkedAt': '2026-10-16T12:00:00Z'}]}
            framed = frame_news(row, live=True)
            self.assertEqual(framed['newsBodyText'], row['text'])
            self.assertEqual(framed['sources'], row['sources'])
            self.assertEqual([part['text'] for part in speech_parts(framed)], [intro, row['text'], outro])
            self.assertEqual(framed['newsCue']['duration'], 2)
            self.assertEqual(frame_news(framed, live=True), framed)
            self.assertNotIn('newsCue', row)
            fallback = frame_news(framed)
            self.assertEqual(fallback['newsCue']['intro'] == intro, language == 'ar')
            self.assertEqual(fallback['newsBodyText'], row['text'])

    def test_original_chime_is_exactly_two_seconds_and_bounded(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'sting.wav'
            write_sting(path)
            with wave.open(str(path)) as audio:
                self.assertEqual(audio.getnframes(), 88200)
                self.assertEqual(audio.getframerate(), 44100)
                values = array.array('h', audio.readframes(audio.getnframes()))
            self.assertGreater(max(values), 3000)
            self.assertLess(max(abs(value) for value in values), 16000)
            self.assertLess(abs(values[-1]), 5)

    def test_news_mp3_contains_full_two_second_cue_before_the_body(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            cue = directory / 'sting.wav'; write_sting(cue)
            source = directory / 'body.wav'
            with wave.open(str(source), 'wb') as output:
                output.setnchannels(1); output.setsampwidth(2); output.setframerate(44100)
                output.writeframes(array.array('h', [5000, -5000] * 22050).tobytes())
            encoded = directory / 'news.mp3'
            transcode_parts([source], [{'pause_after': 0}], encoded, cue_path=cue)
            metrics = verify_audio(encoded)
            self.assertAlmostEqual(metrics['duration'], 3.1, delta=.03)
            self.assertEqual((metrics['sampleRate'], metrics['channels']), (44100, 2))


if __name__ == '__main__':
    unittest.main()
