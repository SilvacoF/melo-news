"""Offline autonomous-radio invariants; synthesis is injected, never networked."""
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import sys
import types
import unittest
from unittest.mock import AsyncMock, patch
import wave
import array

from melo_news import radio


class Catalogs:
    def __init__(self, now):
        self.configs, self.catalogs = {}, {}
        self.replace(now)

    def replace(self, now):
        for lang in radio.LANGUAGES:
            self.configs[lang] = {'categories': {'world': {'maxAgeHours': 24}},
                'sources': [{'id': 'publisher-' + lang, 'category': 'world',
                             'publisher': 'ناشر عربي' if lang == 'ar' else 'English Publisher',
                             'articleHosts': ['publisher.example']}]}
            rows = []
            for number in range(8):
                rows.append({'title': ('خبر عربي موثوق رقم ' if lang == 'ar' else 'An exact native headline number ') + str(number),
                             'url': 'https://publisher.example/' + lang + '/' + str(number),
                             'sourceId': 'publisher-' + lang, 'language': lang,
                             'category': 'world', 'publishedAt': radio.iso(now - dt.timedelta(hours=1)),
                             'checkedAt': radio.iso(now), 'retained': False})
            self.catalogs[lang] = {'schemaVersion': 1, 'language': lang, 'status': 'ok',
                                  'runCheckedAt': radio.iso(now), 'items': rows,
                                  'categories': {'world': {'maxAgeHours': 24}}, 'coverageGapNotices': []}

    def cached(self, language):
        return copy.deepcopy(self.catalogs[language])

    def start_refresh(self, language):
        return None


class RadioTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='melo-radio-test-')
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
        self.catalogs = Catalogs(self.now)
        self.calls = []
        self.fail_language = None

        def renderer(segment, output, profile):
            self.calls.append((segment['language'], segment['type'], segment['id']))
            if segment['language'] == self.fail_language:
                raise RuntimeError('Injected speech failure')
            output.write_bytes(radio.canonical({'text': segment['text'], 'voice': profile['voice']}))

        def verifier(path):
            if not path.read_bytes():
                raise ValueError('Empty injected test asset')
            words = len(json.loads(path.read_bytes())['text'].split())
            return {'duration': words / 2 + 2, 'frames': 50, 'peak': .1, 'sampleRate': 44100, 'channels': 2}

        self.store = radio.RadioStore(self.directory, self.catalogs, renderer=renderer,
                                      verifier=verifier, clock=lambda: self.now, minimum_headlines=8)

    def test_successful_refresh_cadence_does_not_add_synthesis_duration(self):
        self.assertEqual(self.store.refresh_seconds, 600)
        self.store._last_started = 0
        self.store._last_finished = 600
        with patch.object(radio.time, 'monotonic', return_value=601), patch.object(radio.threading, 'Thread') as thread:
            self.assertIsNotNone(self.store.start_refresh())
            thread.return_value.start.assert_called_once()

    def test_cold_start_activates_a_complete_small_pair_before_expanding_both_languages(self):
        # Isolate news cache reuse from the independent six-hour joke rotation.
        for language in radio.LANGUAGES:
            self.store.content['languages'][language]['entertainmentUpdatedAt']=radio.iso(self.now)
        for lang in radio.LANGUAGES:
            for number in range(8, 12):
                row=copy.deepcopy(self.catalogs.catalogs[lang]['items'][0])
                row.update(title=row['title']+str(number),url=row['url']+str(number))
                self.catalogs.catalogs[lang]['items'].append(row)
        original=self.store.renderer
        observed=[]
        def renderer(segment, output, profile):
            if segment['language']=='en' and len([row for row in self.calls if row[0]=='en'])==8:
                active=self.store._active()
                self.assertIsNotNone(active)
                self.assertEqual(active['programs']['en']['version'],active['programs']['ar']['version'])
                self.assertEqual([len(active['programs'][lang]['headlines']) for lang in radio.LANGUAGES],[8,8])
                observed.append(active['version'])
            original(segment,output,profile)
        self.store.renderer=renderer
        expanded=self.store.build_once()
        self.assertEqual(len(observed),1)
        self.assertNotEqual(expanded['version'],observed[0])
        self.assertEqual([len(expanded['programs'][lang]['headlines']) for lang in radio.LANGUAGES],[12,12])
        self.assertEqual(len(self.calls),24,'Expansion reuses the complete starter recordings.')

    def test_failed_cold_start_expansion_retains_the_completed_small_pair(self):
        for lang in radio.LANGUAGES:
            for number in range(8,10):
                row=copy.deepcopy(self.catalogs.catalogs[lang]['items'][0])
                row.update(title=row['title']+str(number),url=row['url']+str(number))
                self.catalogs.catalogs[lang]['items'].append(row)
        original=self.store.renderer
        def renderer(segment,output,profile):
            if segment['language']=='ar' and len([row for row in self.calls if row[0]=='ar'])==8:
                raise RuntimeError('Expansion failed')
            original(segment,output,profile)
        self.store.renderer=renderer
        with self.assertRaisesRegex(RuntimeError,'Expansion failed'):
            self.store.build_once()
        active=self.store._active()
        self.assertEqual([len(active['programs'][lang]['headlines']) for lang in radio.LANGUAGES],[8,8])
        self.assertEqual(active['programs']['en']['newsUpdatedAt'],radio.iso(self.now))

    def test_opinion_labels_are_not_spoken_as_straight_native_news(self):
        for lang,title in [('en','Opinion: Why the markets might change'),
                           ('ar','الاقتصاد العالمي صامد لكن العواصف تلوح في الأفق - مقال في الغارديان')]:
            self.catalogs.catalogs[lang]['items'][0]['title'] = title
            selected = radio.select_headlines(self.catalogs.cached(lang),self.catalogs.configs[lang],lang,self.now,minimum=1)
            self.assertNotIn(title,[row['title'] for row in selected])

    def test_publisher_summary_field_provenance_survives_selection_and_sources(self):
        item=self.catalogs.catalogs['en']['items'][0]
        item.update(summary='The new protected area gives local wildlife a safer place to live.',summaryField='description',summaryTruncated=False)
        selected=radio.select_headlines(self.catalogs.cached('en'),self.catalogs.configs['en'],'en',self.now)
        chosen=next(row for row in selected if row['url']==item['url'])
        self.assertEqual(chosen['summaryField'],'description')
        segment=self.store._news_segments([chosen],'en')[0]
        self.assertEqual(segment['sources'][0]['summaryField'],'description')

    def test_failure_retry_waits_from_finish_and_remains_single_flight(self):
        self.store._error = {'type': 'InjectedError'}
        self.store._last_started = 1700
        self.store._last_finished = 1790
        with patch.object(radio.time, 'monotonic', return_value=1801), patch.object(radio.threading, 'Thread') as thread:
            self.assertIsNone(self.store.start_refresh())
            thread.return_value.start.assert_not_called()
        with patch.object(radio.time, 'monotonic', return_value=1851), patch.object(radio.threading, 'Thread') as thread:
            event = self.store.start_refresh()
            self.assertIsNotNone(event)
            self.assertIs(self.store.start_refresh(), event)
            thread.return_value.start.assert_called_once()

    def test_first_activation_reuses_all_packaged_entertainment_and_has_native_sources(self):
        pair = self.store.build_once()
        self.assertEqual(len(self.calls), 16)
        self.assertTrue(all(kind == 'news' for _, kind, _ in self.calls))
        self.assertEqual(pair['generationState'], 'complete')
        self.assertEqual(pair['programs']['en']['version'], pair['programs']['ar']['version'])
        en_urls, ar_urls = [], []
        for lang in radio.LANGUAGES:
            program = pair['programs'][lang]
            self.assertEqual(program['sourceMode'], 'independent-native-publisher-headlines')
            self.assertEqual(len(program['segments']), 20)
            news = [x for x in program['segments'] if x['type'] == 'news']
            self.assertEqual(len(news), 8)
            self.assertTrue(all(x['ttsVoice'].startswith(lang + '-') for x in program['segments']))
            self.assertTrue(all(x['file'].startswith('/api/radio/audio/') for x in program['segments']))
            for segment in program['segments']:
                digest = segment['file'].split('/')[-1][:-4]
                asset = self.store.audio_file(digest)
                self.assertIsNotNone(asset)
                self.assertEqual(radio.file_hash(asset), digest)
            urls = [x['sources'][0]['url'] for x in news]
            (en_urls if lang == 'en' else ar_urls).extend(urls)
        self.assertFalse(set(en_urls) & set(ar_urls))

    def test_arabic_failure_keeps_both_previous_programs_and_completed_english_cache(self):
        first = self.store.build_once()
        pointer = (self.directory / 'active.json').read_bytes()
        self.now += dt.timedelta(minutes=31)
        self.catalogs.replace(self.now)
        for lang in radio.LANGUAGES:
            self.catalogs.catalogs[lang]['items'][0]['title'] += ' تحديث' if lang == 'ar' else ' revised'
        self.fail_language = 'ar'
        with self.assertRaises(RuntimeError):
            self.store.build_once()
        self.assertEqual((self.directory / 'active.json').read_bytes(), pointer)
        self.assertEqual(self.store._active()['version'], first['version'])
        english_calls = len([x for x in self.calls if x[0] == 'en'])
        self.fail_language = None
        second = self.store.build_once()
        self.assertNotEqual(second['version'], first['version'])
        self.assertEqual(len([x for x in self.calls if x[0] == 'en']), english_calls)

    def test_fresh_checks_reuse_unchanged_speech_without_relabelling_source_dates(self):
        # This test isolates news cache reuse, not the independent six-hour
        # entertainment rotation that can otherwise depend on the wall clock.
        for language in radio.LANGUAGES:
            self.store.content['languages'][language]['entertainmentUpdatedAt'] = radio.iso(self.now)
        first = self.store.build_once()
        calls = len(self.calls)
        self.now += dt.timedelta(minutes=31)
        # Keep actual publication dates, change only the successful check times.
        for catalog in self.catalogs.catalogs.values():
            catalog['runCheckedAt'] = radio.iso(self.now)
            for item in catalog['items']:
                item['checkedAt'] = radio.iso(self.now)
        second = self.store.build_once()
        self.assertEqual(len(self.calls), calls)
        self.assertNotEqual(first['version'], second['version'])
        for lang in radio.LANGUAGES:
            old = first['programs'][lang]['headlines']
            new = second['programs'][lang]['headlines']
            self.assertEqual([x['publishedAt'] for x in old], [x['publishedAt'] for x in new])
            self.assertEqual(second['programs'][lang]['newsUpdatedAt'], radio.iso(self.now))

    def test_collection_attempt_is_never_used_as_a_successful_source_check(self):
        checked = radio.iso(self.now - dt.timedelta(minutes=5))
        for catalog in self.catalogs.catalogs.values():
            for item in catalog['items']:
                item['checkedAt'] = checked
        pair = self.store.build_once()
        for lang in radio.LANGUAGES:
            program = pair['programs'][lang]
            self.assertEqual(program['newsUpdatedAt'], checked)
            self.assertEqual(program['newsMetadata']['fetchedAt'], checked)
            self.assertEqual(program['collectionAttemptedAt'], radio.iso(self.now))
            self.assertEqual(program['newsMetadata']['collectionAttemptedAt'], radio.iso(self.now))

    def test_updated_date_markers_survive_headlines_segments_and_sources(self):
        for lang in radio.LANGUAGES:
            item = self.catalogs.catalogs[lang]['items'][0]
            # The raw publisher field is sufficient evidence even before a
            # collector has supplied the normalized display marker.
            item['publicationDateField'] = 'updated'
            item['publicationDateOriginal'] = 'Fri, 16 Oct 2026 09:00:00 GMT'
        pair = self.store.build_once()
        for lang in radio.LANGUAGES:
            program = pair['programs'][lang]
            url = 'https://publisher.example/' + lang + '/0'
            headline = next(x for x in program['headlines'] if x['url'] == url)
            segment = next(x for x in program['segments'] if x['type'] == 'news' and x['sources'][0]['url'] == url)
            for record in (headline, segment, segment['sources'][0]):
                self.assertEqual(record['publicationDateType'], 'updated')
                self.assertEqual(record['publicationDateField'], 'updated')
                self.assertEqual(record['publicationDateOriginal'], 'Fri, 16 Oct 2026 09:00:00 GMT')
                self.assertEqual(record['publishedAt'], self.catalogs.catalogs[lang]['items'][0]['publishedAt'])
            self.assertNotIn('حدّث المصدر' if lang == 'ar' else ' Updated ', segment['text'])
            self.assertNotIn(record['publishedAt'], segment['text'])

    def test_more_news_is_capped_at_twenty_with_broad_and_light_publisher_topics(self):
        language = 'en'
        config = copy.deepcopy(self.catalogs.configs[language])
        config['categories'] = {category: {'maxAgeHours': 24} for category in radio.LABELS}
        config['sources'] = []
        catalog = copy.deepcopy(self.catalogs.catalogs[language])
        catalog['items'] = []
        for category in radio.LABELS:
            source_id = 'publisher-' + category
            config['sources'].append({'id': source_id, 'category': category,
                                      'publisher': 'English Publisher', 'articleHosts': ['publisher.example']})
            for number in range(4):
                row = copy.deepcopy(self.catalogs.catalogs[language]['items'][0])
                row.update(sourceId=source_id, category=category,
                           title=category + ' exact publisher headline ' + str(number),
                           url='https://publisher.example/' + category + '/' + str(number))
                catalog['items'].append(row)
        selected = radio.select_headlines(catalog, config, language, self.now)
        self.assertEqual(len(selected), radio.MAX_NEWS)
        self.assertEqual(radio.MAX_NEWS, 20)
        self.assertEqual({x['category'] for x in selected}, set(radio.LABELS))
        self.assertEqual(sum(x['category'] == 'positive' for x in selected), 4)
        self.assertEqual(sum(x['category'] == 'offbeat' for x in selected), 4)
        with self.assertRaises(ValueError):
            radio.select_headlines(catalog, config, language, self.now, maximum=21)
        self.store.selector = lambda items, language, now: items
        self.assertEqual(self.store._annotate_selection(selected, 'en', self.now), selected)

    def test_news_uses_exact_summary_detail_without_spoken_metadata_outros(self):
        summaries = {
            'en': 'The park will welcome visitors from Saturday after volunteers restored its paths.',
            'ar': 'تفتح الحديقة أبوابها يوم السبت بعد أن أعاد متطوعون تأهيل الممرات.'}
        for lang in radio.LANGUAGES:
            item = self.catalogs.catalogs[lang]['items'][0]
            item['title'] = 'City park reopens' if lang == 'en' else 'افتتاح حديقة جديدة'
            item['summary'] = summaries[lang]
        pair = self.store.build_once()
        for lang in radio.LANGUAGES:
            program = pair['programs'][lang]
            url = 'https://publisher.example/' + lang + '/0'
            headline = next(x for x in program['headlines'] if x['url'] == url)
            segment = next(x for x in program['segments'] if x['type'] == 'news' and x['sources'][0]['url'] == url)
            self.assertEqual(headline['summary'], summaries[lang])
            self.assertEqual(segment['sources'][0]['summary'], summaries[lang])
            self.assertEqual(segment['narratedSummary'], summaries[lang])
            self.assertEqual(segment['sources'][0]['narratedSummary'], summaries[lang])
            self.assertEqual(segment['newsFormat'], 'native-attributed-headline-detail')
            self.assertIn(segment['sources'][0]['title'], segment['newsBodyText'])
            prefix = 'بحسب ناشر عربي: ' if lang == 'ar' else 'English Publisher reports: '
            self.assertEqual(segment['newsBodyText'], prefix + segment['sources'][0]['title'] + '.\n' + summaries[lang])
            for forbidden in ('Melo Radio', 'هنا راديو', 'Published', 'UTC', 'التوقيت العالمي', 'http', 'رابط المصدر', 'check time'):
                self.assertNotIn(forbidden, segment['text'])
            self.assertIn('publishedAt', segment['sources'][0])
            self.assertIn('checkedAt', segment['sources'][0])

    def test_summary_excerpt_preserves_complete_sentence_and_number(self):
        sentence = 'Volunteers restored the riverside paths and planted 1,100 native trees across the park.'
        item = {'title': 'City park reopens', 'summary': sentence + ' Families attended the opening with guides, musicians, community gardeners and school groups from several nearby districts.'}
        detail = radio.narrated_summary(item, 'en')
        self.assertEqual(detail, sentence)
        self.assertLessEqual(len(detail.split()), 25)
        self.assertIn('1,100', detail)
        self.assertIn(detail, item['summary'])

    def test_collector_truncated_summary_is_evidence_only_never_narrated(self):
        summaries = {
            'en': 'Volunteers restored the riverside paths and planted native trees across the park.',
            'ar': 'أعاد المتطوعون تأهيل الممرات وزرعوا أشجارًا محلية في أنحاء الحديقة.'}
        titles = {'en': 'City park reopens', 'ar': 'افتتاح حديقة جديدة'}
        for lang in radio.LANGUAGES:
            item = self.catalogs.catalogs[lang]['items'][0]
            item.update(title=titles[lang], summary=summaries[lang], summaryTruncated=True)
        pair = self.store.build_once()
        for lang in radio.LANGUAGES:
            program = pair['programs'][lang]
            url = 'https://publisher.example/' + lang + '/0'
            headline = next(x for x in program['headlines'] if x['url'] == url)
            segment = next(x for x in program['segments'] if x['type'] == 'news' and x['sources'][0]['url'] == url)
            self.assertEqual(headline['summary'], summaries[lang])
            self.assertIs(headline['summaryTruncated'], True)
            self.assertEqual(segment['sources'][0]['summary'], summaries[lang])
            self.assertIs(segment['sources'][0]['summaryTruncated'], True)
            self.assertNotIn('narratedSummary', segment)
            self.assertNotIn('narratedSummary', segment['sources'][0])
            self.assertEqual(segment['newsFormat'], 'native-attributed-headline')
            prefix = 'بحسب ناشر عربي: ' if lang == 'ar' else 'English Publisher reports: '
            self.assertEqual(segment['newsBodyText'], prefix + titles[lang] + '.')

    def test_unsafe_duplicate_or_cut_summary_falls_back_to_exact_headline(self):
        cases = [
            'City park reopens.',
            'A report says the city park reopens. Officials said the decision remains unconfirmed and warned that another inspection could delay public access for several weeks during the winter season.',
            'The restoration project was led by a researcher named Dr. Morgan and involved local volunteers, specialist gardeners, engineers, environmental groups and representatives of several nearby communities.',
            ' '.join(['The park is ready for visitors'] * 6),
            'The park is ready for visitors but officials have not yet confirmed...',
            'Read more about the reopening at https://publisher.example/details.',
            '<p>The park opens for visitors after extensive restoration work.</p>',
        ]
        for summary in cases:
            with self.subTest(summary=summary):
                item = copy.deepcopy(self.catalogs.catalogs['en']['items'][0])
                item.update(title='City park reopens', summary=summary, outlet='English Publisher')
                self.assertIsNone(radio.narrated_summary(item, 'en'))
                segment = self.store._news_segments([item], 'en')[0]
                self.assertEqual(segment['newsFormat'], 'native-attributed-headline')
                self.assertEqual(segment['newsBodyText'], 'English Publisher reports: City park reopens.')
                self.assertNotIn('narratedSummary', segment)

    def test_classification_status_exposes_bounded_metrics_without_paths_or_raw_errors(self):
        secret = '/private/model/token-do-not-expose'
        class Selector:
            def status(self):
                return {'state': 'ready', 'model': 'EmbeddingGemma 2',
                        'classified': 13, 'lastInferenceSeconds': 2.5,
                        'workerTerminated': True,
                        'modelPath': secret, 'rawError': secret, 'errorType': secret,
                        'metrics': {'peakChildRssBytes': 288366592,
                                    'peakWorkerAndChildRssBytes': 308801536,
                                    'stoppedReason': None, 'libraryPath': secret}}
        self.store.selector = Selector()
        # Inspect the actual public diagnostic response, not just its helper.
        status = self.store.status()['classification']
        self.assertEqual(status['state'], 'ready')
        self.assertTrue(status['advisoryOnly'])
        self.assertFalse(status['generatesText'])
        self.assertEqual(status['classified'], 13)
        self.assertEqual(status['metrics']['peakChildRssBytes'], 288366592)
        self.assertTrue(status['workerTerminated'])
        self.assertNotIn(secret, json.dumps(status))
        self.assertNotIn('modelPath', status)
        self.assertNotIn('rawError', status)
        self.assertNotIn('errorType', status)
        self.assertNotIn('libraryPath', status['metrics'])

    def test_cold_start_waits_for_both_catalogs_before_scheduling_speech(self):
        self.catalogs.catalogs['ar'] = None
        self.assertIsNone(self.store.start_refresh())
        self.assertIsNone(self.store._event)
        self.assertFalse(self.calls)

    def test_unverified_native_catalog_cannot_replace_pair(self):
        first = self.store.build_once()
        self.catalogs.catalogs['ar']['items'][0]['url'] = 'https://unapproved.example/fake'
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.assertEqual(self.store._active()['version'], first['version'])
        self.catalogs.catalogs['ar']['items'][0]['url'] = 'https://publisher.example/ar/0'
        self.catalogs.catalogs['ar']['items'][0]['checkedAt'] = radio.iso(self.now - dt.timedelta(days=1))
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.assertEqual(self.store._active()['version'], first['version'])

    def test_non_native_and_retained_items_never_become_new_arabic_speech(self):
        self.catalogs.catalogs['ar']['items'][0]['title'] = 'An untranslated English headline'
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.catalogs.replace(self.now)
        self.catalogs.catalogs['ar']['items'][0]['retained'] = True
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.assertFalse((self.directory / 'active.json').exists())

    def test_entertainment_rotates_only_after_six_hours_and_stories_are_fixed(self):
        first = self.store.build_once()
        # Anchor a truthful initial entertainment time for an independent test.
        for lang in radio.LANGUAGES:
            first['programs'][lang]['entertainmentUpdatedAt'] = radio.iso(self.now)
        radio.atomic_json(self.directory / 'editions' / (first['version'] + '.json'), first)
        self.now += dt.timedelta(hours=5, minutes=59)
        self.catalogs.replace(self.now)
        second = self.store.build_once()
        for lang in radio.LANGUAGES:
            self.assertEqual(second['programs'][lang]['jokeBankRotation'], 0)
        self.now += dt.timedelta(minutes=2)
        self.catalogs.replace(self.now)
        third = self.store.build_once()
        for lang in radio.LANGUAGES:
            old, new = first['programs'][lang], third['programs'][lang]
            self.assertEqual(new['jokeBankRotation'], 1)
            self.assertNotEqual([x['text'] for x in old['segments'] if x['type'] == 'jokes'],
                                [x['text'] for x in new['segments'] if x['type'] == 'jokes'])
            self.assertEqual([x['text'] for x in old['segments'] if x['type'] == 'story'],
                             [x['text'] for x in new['segments'] if x['type'] == 'story'])
            self.assertEqual([x['text'] for x in old['segments'] if x['type'] == 'ident'],
                             [x['text'] for x in new['segments'] if x['type'] == 'ident'])

    def test_audio_lookup_rejects_paths_and_unknown_content_hashes(self):
        for bad in ('../secret', 'A' * 64, '0' * 64, '/tmp/file.mp3', 'https://example.com/audio'):
            self.assertIsNone(self.store.audio_file(bad))

    def test_partial_native_coverage_can_publish_but_zero_native_sources_keeps_pair(self):
        self.store.minimum_headlines = 1
        self.catalogs.catalogs['ar']['items'] = self.catalogs.catalogs['ar']['items'][:2]
        pair = self.store.build_once()
        self.assertEqual(len(pair['programs']['ar']['headlines']), 2)
        self.assertTrue(pair['programs']['ar']['newsMetadata']['oldFeedNotice'])
        self.assertTrue(any(x['category'] == 'technology' for x in
                            pair['programs']['ar']['newsMetadata']['coverageGapNotices']))
        self.catalogs.catalogs['ar']['items'] = []
        with self.assertRaises(ValueError):
            self.store.build_once()
        self.assertEqual(self.store._active()['version'], pair['version'])

    def test_optional_selection_hook_cannot_change_publisher_facts(self):
        def unsafe(items, language, now):
            items[0]['title'] += ' invented addition'
            return items
        self.store.selector = unsafe
        with self.assertRaisesRegex(ValueError, 'publisher fact'):
            self.store.build_once()
        self.assertFalse((self.directory / 'active.json').exists())
        def safe(items, language, now):
            items[0]['semanticCategories'] = ['world', 'science']
            items[0]['dedupConfidence'] = .9
            return items
        self.store.selector = safe
        pair = self.store.build_once()
        self.assertEqual(pair['programs']['en']['headlines'][0]['semanticCategories'], ['world', 'science'])
        self.assertNotIn('semanticCategories', pair['programs']['en']['segments'][-1]['text'])

    def test_corrupt_active_audio_falls_back_without_claiming_a_complete_new_pair(self):
        pair = self.store.build_once()
        news = next(x for x in pair['programs']['en']['segments'] if x['type'] == 'news')
        digest = news['file'].split('/')[-1][:-4]
        self.store.audio_file(digest).unlink()
        self.assertIsNone(self.store._active())
        # Keep this test synchronous: HTTP itself schedules background work.
        self.store.start_refresh = lambda **_: None
        status, fallback = self.store.response('en')
        self.assertEqual(status, 200)
        self.assertEqual(fallback['generationState'], 'published-fallback')
        self.assertNotEqual(fallback['generationState'], 'complete')

    def test_short_cached_asset_is_regenerated_before_reuse(self):
        selected = radio.select_headlines(self.catalogs.cached('en'), self.catalogs.configs['en'], 'en', self.now)
        segment = self.store._news_segments(selected[:1], 'en')[0]
        first = self.store._asset(segment)
        original_verifier = self.store.verifier
        cached_name = Path(first['file']).name
        def verifier(path):
            metrics = original_verifier(path)
            return {**metrics, 'duration': .36} if path.name == cached_name else metrics
        self.store.verifier = verifier
        calls = len(self.calls)
        recovered = self.store._asset(segment)
        self.assertEqual(len(self.calls), calls + 1)
        self.assertGreaterEqual(recovered['duration'], radio.minimum_speech_duration(segment))

    def test_short_new_arabic_asset_never_replaces_the_previous_pair(self):
        first = self.store.build_once()
        pointer = (self.directory / 'active.json').read_bytes()
        self.now += dt.timedelta(minutes=31); self.catalogs.replace(self.now)
        self.catalogs.catalogs['ar']['items'][0]['title'] += ' تحديث'
        original_verifier = self.store.verifier
        def verifier(path):
            metrics = original_verifier(path)
            payload = json.loads(path.read_bytes())
            if path.name == 'speech.mp3' and payload['voice'].startswith('ar-') and 'تحديث' in payload['text']:
                return {**metrics, 'duration': .36}
            return metrics
        self.store.verifier = verifier
        with self.assertRaises(radio.SpeechDurationError):
            self.store.build_once()
        self.assertEqual((self.directory / 'active.json').read_bytes(), pointer)
        self.assertEqual(self.store._active()['version'], first['version'])

    def test_repeated_short_summary_can_use_only_its_exact_attributed_headline(self):
        item = self.catalogs.catalogs['en']['items'][0]
        item.update(summary='The new protected area gives local wildlife a safer place to live.', summaryField='description', summaryTruncated=False)
        original_renderer = self.store.renderer; formats = []
        def renderer(segment, output, profile):
            if segment['type'] == 'news': formats.append(segment['newsFormat'])
            if segment.get('newsFormat') == 'native-attributed-headline-detail':
                raise radio.SpeechDurationError('Injected short provider summary')
            original_renderer(segment, output, profile)
        self.store.renderer = renderer
        pair = self.store.build_once()
        segment = next(row for row in pair['programs']['en']['segments'] if row['type'] == 'news' and row['sources'][0]['url'] == item['url'])
        self.assertIn('native-attributed-headline-detail', formats)
        self.assertEqual(segment['newsFormat'], 'native-attributed-headline')
        self.assertEqual(segment['newsBodyText'], 'English Publisher reports: ' + item['title'] + '.')
        self.assertNotIn('narratedSummary', segment)
        self.assertNotIn('narratedSummary', segment['sources'][0])
        self.assertEqual(segment['sources'][0]['summary'], item['summary'])
        self.assertEqual(segment['sources'][0]['checkedAt'], item['checkedAt'])

    def test_implausible_active_pair_reads_prior_complete_pair_without_mutation(self):
        first = self.store.build_once()
        self.now += dt.timedelta(minutes=31); self.catalogs.replace(self.now)
        second = self.store.build_once()
        pointer = (self.directory / 'active.json').read_bytes()
        segment = next(row for row in second['programs']['ar']['segments'] if row['type'] == 'news')
        segment['duration'] = .36
        radio.atomic_json(self.directory / 'editions' / (second['version'] + '.json'), second)
        self.assertEqual(self.store._active()['version'], first['version'])
        self.assertEqual((self.directory / 'active.json').read_bytes(), pointer)


class SpeechDurationTests(unittest.TestCase):
    TEXT = 'بحسب بي بي سي عربي: يتبادل الطرفان إسقاط المسيرات غداة تبنّي حركة أنصار الله الحوثية هجوماً صاروخياً استهدف القصر الرئاسي في مدينة عدن.'

    def test_utterance_bound_allows_short_idents_but_rejects_the_cloud_regression(self):
        segment = {'text': self.TEXT}
        self.assertAlmostEqual(radio.minimum_speech_duration(segment), 23 / 6)
        with self.assertRaises(radio.SpeechDurationError):
            radio.verify_speech_duration(segment, {'duration': .36})
        self.assertEqual(radio.verify_speech_duration({'text': 'Melo'}, {'duration': .3})['duration'], .3)
        long_word = {'text': 'a' * 90}
        with self.assertRaises(radio.SpeechDurationError):
            radio.verify_speech_duration(long_word, {'duration': 1})
        parts = [{'text': str(index), 'pause_after': pause} for index, pause in enumerate([.35, .7, .35, 0])]
        joke = {'type': 'jokes', 'text': '\n\n'.join(part['text'] for part in parts), 'speech_parts': parts}
        self.assertAlmostEqual(radio.minimum_speech_duration(joke), 4 / 6 + 1.4)

    def test_raw_short_neural_response_retries_and_never_reaches_the_transcoder(self):
        class Voice:
            async def save(self, path): Path(path).write_bytes(b'fake-neural-mp3')
        fake_edge = types.SimpleNamespace(__version__='7.3.1', Communicate=lambda *args, **kwargs: Voice())
        profile = {'voice': 'ar-EG-SalmaNeural', 'rate': '-5%'}
        segment = {'language': 'ar', 'type': 'news', 'text': self.TEXT}
        for durations, succeeds in [([.36, 13.368], True), ([.36, .36], False)]:
            with self.subTest(durations=durations), tempfile.TemporaryDirectory() as temporary:
                with patch.dict(sys.modules, {'edge_tts': fake_edge}), patch.object(radio, 'verify_audio', side_effect=[{'duration': value} for value in durations]) as verify:
                    with patch.object(radio.asyncio, 'sleep', new=AsyncMock()), patch.object(radio, 'transcode_parts') as transcode:
                        if succeeds:
                            radio.render_segment(segment, Path(temporary) / 'out.mp3', profile)
                            transcode.assert_called_once()
                        else:
                            with self.assertRaises(radio.SpeechDurationError):
                                radio.render_segment(segment, Path(temporary) / 'out.mp3', profile)
                            transcode.assert_not_called()
                        self.assertEqual(verify.call_count, 2)
                        self.assertTrue(all(call.kwargs == {'expected_format': False} for call in verify.call_args_list))


@unittest.skipUnless(importlib.util.find_spec('av'), 'PyAV wheel is needed for the codec smoke test')
class CodecTests(unittest.TestCase):
    def test_a_decodable_non_silent_subsecond_clip_cannot_contain_long_arabic_speech(self):
        with tempfile.TemporaryDirectory(prefix='melo-radio-short-codec-') as temporary:
            directory = Path(temporary); source = directory / 'short.wav'
            samples = array.array('h', (round(5000 * math.sin(2 * math.pi * 440 * i / 22050)) for i in range(round(.36 * 22050))))
            with wave.open(str(source), 'wb') as output:
                output.setnchannels(1); output.setsampwidth(2); output.setframerate(22050); output.writeframes(samples.tobytes())
            encoded = directory / 'short.mp3'
            radio.transcode_parts([source], [{'pause_after': 0}], encoded)
            metrics = radio.verify_audio(encoded)
            self.assertAlmostEqual(metrics['duration'], .36, delta=.03)
            self.assertGreater(metrics['peak'], .05)
            with self.assertRaises(radio.SpeechDurationError):
                radio.verify_speech_duration({'text': SpeechDurationTests.TEXT}, metrics)
            radio.verify_speech_duration({'text': 'ميلو'}, metrics)

    def test_real_transcode_decodes_all_frames_and_preserves_short_pauses(self):
        with tempfile.TemporaryDirectory(prefix='melo-radio-codec-') as temporary:
            directory = Path(temporary)
            source = directory / 'source.wav'
            samples = array.array('h', (round(5000 * math.sin(2 * math.pi * 440 * i / 22050))
                                       for i in range(22050)))
            with wave.open(str(source), 'wb') as output:
                output.setnchannels(1); output.setsampwidth(2); output.setframerate(22050)
                output.writeframes(samples.tobytes())
            encoded = directory / 'speech.mp3'
            radio.transcode_parts([source, source], [{'pause_after': .35}, {'pause_after': 0}], encoded)
            metrics = radio.verify_audio(encoded)
            self.assertAlmostEqual(metrics['duration'], 2.35, delta=.03)
            self.assertGreater(metrics['peak'], .05)
            self.assertEqual((metrics['sampleRate'], metrics['channels']), (44100, 2))
            self.assertGreater(metrics['frames'], 50)


if __name__ == '__main__':
    unittest.main()
