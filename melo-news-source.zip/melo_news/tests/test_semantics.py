"""Advisory model output cannot rewrite publisher evidence or good-news labels."""
import copy
import datetime as dt
import hashlib
from pathlib import Path
import tempfile
import unittest

from melo_news.semantics import SemanticSelector


class SemanticTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.model = Path(self.tmp.name) / 'fixture.gguf'
        self.model.write_bytes(b'fixture')
        self.runtime = Path(self.tmp.name) / 'runner'
        self.runtime.write_bytes(b'fixture runner')
        self.now = dt.datetime(2026, 10, 16, tzinfo=dt.timezone.utc)
        self.items = [{'title': 'Publisher says the count increased from 12 to 30', 'url': 'https://example.com/source',
                       'category': 'world', 'publishedAt': '2026-10-15T23:00:00Z', 'checkedAt': '2026-10-16T00:00:00Z',
                       'source': 'Actual publisher', 'language': 'en'}]

    def selector(self, transform=None):
        calls = []
        def run(payload):
            calls.append(copy.deepcopy(payload))
            answer = {'ok': True, 'advisoryOnly': True, 'generatedText': False, 'childTerminated': True,
                      'revision': selector.manifest['embedding']['revision'],
                      'results': [{'id': row['id'], 'category': 'technology', 'score': .91,
                                   'margin': .12, 'lowConfidence': False} for row in payload['items']],
                      'metrics': {'peakRssBytes': 100}, 'wallSeconds': .1}
            if transform:
                transform(answer)
            return answer
        selector = SemanticSelector(self.model, self.runtime, run)
        selector.manifest['embedding'].update(bytes=7, sha256=hashlib.sha256(b'fixture').hexdigest())
        return selector, calls

    def test_advice_preserves_every_publisher_field_and_caches_without_rerun(self):
        selector, calls = self.selector()
        before = copy.deepcopy(self.items)
        result = selector(self.items, 'en', self.now)
        self.assertEqual(result[0].pop('semanticCategories'), ['technology'])
        self.assertEqual(result, before)
        self.assertEqual(self.items, before)
        selector(self.items, 'en', self.now)
        self.assertEqual(len(calls), 1)
        self.assertEqual(selector.status()['state'], 'ready')
        self.assertTrue(selector.status()['workerTerminated'])

    def test_low_confidence_and_publisher_good_news_are_not_overruled(self):
        selector, _ = self.selector(lambda value: value['results'][0].update(lowConfidence=True))
        self.assertEqual(selector(self.items, 'en', self.now), self.items)
        for category in ('positive', 'offbeat'):
            selector, _ = self.selector()
            items = [{**self.items[0], 'category': category}]
            self.assertEqual(selector(items, 'en', self.now), items)

    def test_invalid_results_fail_closed_without_partial_cache(self):
        for mutate in (lambda x: x.update(generatedText=True), lambda x: x.update(childTerminated=False),
                       lambda x: x.update(revision='different'), lambda x: x['results'][0].update(id='other'),
                       lambda x: x['results'][0].update(score=float('nan')),
                       lambda x: x['results'][0].update(category='positive')):
            selector, _ = self.selector(mutate)
            self.assertEqual(selector(self.items, 'en', self.now), self.items)
            self.assertEqual(selector._cache, {})
            self.assertEqual(selector.status()['state'], 'retained-publisher-categories')

    def test_missing_or_changed_model_retains_original_headlines(self):
        selector, calls = self.selector()
        self.model.write_bytes(b'wrong')
        self.assertEqual(selector(self.items, 'en', self.now), self.items)
        self.assertEqual(calls, [])
        self.model.unlink()
        self.assertEqual(selector(self.items, 'en', self.now), self.items)
        self.assertEqual(selector.status()['state'], 'unavailable')


if __name__ == '__main__':
    unittest.main()
