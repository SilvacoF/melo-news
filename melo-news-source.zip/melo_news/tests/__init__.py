"""Deterministic collector checks; live publishers are only used by --once."""
