import copy
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import Mock, patch
import urllib.error

from melo_news import bootstrap_models as bootstrap


class Response(io.BytesIO):
    status = 200

    def __init__(self, content, headers=None):
        super().__init__(content)
        self.headers = headers or {}


def make_archive(path, entries):
    with tarfile.open(path, "w:gz") as stream:
        for name, kind, content in entries:
            entry = tarfile.TarInfo(name)
            if kind == "file":
                entry.size, entry.mode = len(content), 0o755 if name.endswith("llama-server") else 0o644
                stream.addfile(entry, io.BytesIO(content))
            elif kind == "dir":
                entry.type = tarfile.DIRTYPE
                stream.addfile(entry)
            elif kind == "symbolic":
                entry.type, entry.linkname = tarfile.SYMTYPE, content
                stream.addfile(entry)
            elif kind == "hard":
                entry.type, entry.linkname = tarfile.LNKTYPE, content
                stream.addfile(entry)
            elif kind == "device":
                entry.type = tarfile.CHRTYPE
                stream.addfile(entry)
    return path


def runtime_for(path):
    return {"tag": "b11669", "linuxX64": {
        "file": path.name, "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "binaryRelativePath": "llama-b11669/llama-server",
    }}


class DownloadTests(unittest.TestCase):
    def test_verified_stream_is_atomic_anonymous_and_idempotent(self):
        data = b"verified model bytes"
        opener = Mock()
        opener.open.return_value = Response(data, {"Content-Length": str(len(data))})
        digest = hashlib.sha256(data).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "model.gguf"
            self.assertTrue(bootstrap.download_verified("https://huggingface.co/org/model/resolve/revision/model.gguf", output, len(data), digest, opener=opener))
            self.assertEqual(output.read_bytes(), data)
            self.assertFalse(list(Path(directory).glob("*.part")))
            request = opener.open.call_args.args[0]
            self.assertNotIn("Authorization", request.headers)
            self.assertFalse(bootstrap.download_verified("https://huggingface.co/org/model/resolve/revision/model.gguf", output, len(data), digest, opener=opener))
            self.assertEqual(opener.open.call_count, 1)

    def test_digest_failure_keeps_previous_file_and_removes_temporary(self):
        opener = Mock()
        opener.open.return_value = Response(b"bad")
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "model.gguf"
            output.write_bytes(b"old")
            with self.assertRaisesRegex(bootstrap.BootstrapError, "digest_mismatch"):
                bootstrap.download_verified("https://huggingface.co/a/b", output, 3, hashlib.sha256(b"new").hexdigest(), opener=opener)
            self.assertEqual(output.read_bytes(), b"old")
            self.assertEqual([p.name for p in Path(directory).iterdir()], ["model.gguf"])

    def test_oversized_and_truncated_downloads_are_rejected(self):
        for body, expected_error in [(b"toolong", "size_exceeded"), (b"x", "size_mismatch")]:
            with self.subTest(body=body), tempfile.TemporaryDirectory() as directory:
                opener = Mock()
                opener.open.return_value = Response(body)
                output = Path(directory) / "m.gguf"
                with self.assertRaisesRegex(bootstrap.BootstrapError, expected_error):
                    bootstrap.download_verified("https://huggingface.co/a/b", output, 3, hashlib.sha256(b"abc").hexdigest(), opener=opener)
                self.assertFalse(output.exists())

    def test_content_length_and_encoding_are_checked(self):
        for headers, code in [({"Content-Length": "999"}, "content_length"), ({"Content-Encoding": "gzip"}, "encoding")]:
            with self.subTest(headers=headers), tempfile.TemporaryDirectory() as directory:
                opener = Mock()
                opener.open.return_value = Response(b"abc", headers)
                with self.assertRaisesRegex(bootstrap.BootstrapError, code):
                    bootstrap.download_verified("https://huggingface.co/a/b", Path(directory)/"m", 3, hashlib.sha256(b"abc").hexdigest(), opener=opener)

    def test_transient_retry_is_bounded_and_can_recover(self):
        opener, sleep = Mock(), Mock()
        opener.open.side_effect = [urllib.error.URLError("private signed URL must not be logged"), Response(b"abc")]
        with tempfile.TemporaryDirectory() as directory:
            self.assertTrue(bootstrap.download_verified("https://huggingface.co/a/b", Path(directory)/"m", 3, hashlib.sha256(b"abc").hexdigest(), opener=opener, retries=1, sleep=sleep))
        self.assertEqual(opener.open.call_count, 2)
        sleep.assert_called_once_with(1)

    def test_http_errors_never_expose_signed_urls(self):
        opener = Mock()
        opener.open.side_effect = urllib.error.HTTPError("https://cdn.hf.co/model?secret=DO_NOT_LOG", 403, "DO_NOT_LOG", {}, None)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(bootstrap.BootstrapError) as raised:
                bootstrap.download_verified("https://huggingface.co/a/b", Path(directory)/"m", 3, hashlib.sha256(b"abc").hexdigest(), opener=opener)
        self.assertEqual(str(raised.exception), "download_http_403")
        self.assertNotIn("DO_NOT_LOG", str(raised.exception))
        self.assertEqual(opener.open.call_count, 1)

    def test_long_retry_after_defers_without_second_request(self):
        opener = Mock()
        opener.open.side_effect = urllib.error.HTTPError("https://huggingface.co/a", 429, "retry", {"Retry-After": "120"}, None)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(bootstrap.BootstrapError, "retry_deferred"):
                bootstrap.download_verified("https://huggingface.co/a/b", Path(directory)/"m", 3, hashlib.sha256(b"abc").hexdigest(), opener=opener)
        self.assertEqual(opener.open.call_count, 1)

    def test_untrusted_urls_and_redirects_rejected(self):
        for url in ("http://huggingface.co/model", "https://evil.example/model", "https://github.com.evil.example/a", "https://user:secret@huggingface.co/a"):
            self.assertFalse(bootstrap._trusted_url(url))
        self.assertTrue(bootstrap._trusted_url("https://cas-bridge.xethub.hf.co/a?signature=hidden"))
        with self.assertRaisesRegex(bootstrap.BootstrapError, "untrusted_download_redirect"):
            bootstrap.PublicArtifactRedirects().redirect_request(None, None, 302, "", {}, "http://127.0.0.1/file")


class ArchiveTests(unittest.TestCase):
    def reject(self, entries, message):
        with tempfile.TemporaryDirectory() as directory:
            archive = make_archive(Path(directory)/"runtime.tar.gz", entries)
            with self.assertRaisesRegex(bootstrap.BootstrapError, message):
                bootstrap.extract_runtime(archive, Path(directory)/"out", "llama-b11669")

    def test_path_traversal_absolute_and_wrong_root_rejected(self):
        for name in ("../outside", "/outside", "llama-b11669/../../outside", "llama-b11669\\evil", "C:/outside"):
            self.reject([(name,"file",b"x")], "unsafe_archive_path")
        self.reject([("other-root/file","file",b"x")], "archive_root_mismatch")

    def test_symlink_and_hardlink_escape_rejected(self):
        for kind in ("symbolic", "hard"):
            self.reject([("llama-b11669/alias",kind,"../../outside")], "escapes_root")
            self.reject([("llama-b11669/alias",kind,"/outside")], "unsafe_archive_link")

    def test_link_cycles_and_members_under_links_rejected(self):
        self.reject([("llama-b11669/a","symbolic","b"),("llama-b11669/b","symbolic","a")], "link_cycle")
        self.reject([("llama-b11669/dir","symbolic","real"),("llama-b11669/real","dir",b""),("llama-b11669/dir/file","file",b"x")], "under_link")

    def test_devices_duplicates_and_expansion_rejected(self):
        self.reject([("llama-b11669/device","device",b"")], "unsupported_archive_member")
        self.reject([("llama-b11669/a","file",b"x"),("llama-b11669/a","file",b"y")], "duplicate_archive_path")
        with patch.object(bootstrap,"MAX_EXPANDED_BYTES",1):
            self.reject([("llama-b11669/a","file",b"xx")], "expansion_limit")
        with patch.object(bootstrap,"MAX_ARCHIVE_MEMBERS",1):
            self.reject([("llama-b11669/a","file",b"x"),("llama-b11669/b","file",b"y")], "too_many_archive_members")

    def test_valid_regular_archive_and_internal_hardlink(self):
        with tempfile.TemporaryDirectory() as directory:
            archive = make_archive(Path(directory)/"runtime.tar.gz", [
                ("llama-b11669","dir",b""),
                ("llama-b11669/llama-server","file",b"runtime"),
                ("llama-b11669/alias","hard","llama-b11669/llama-server"),
            ])
            extracted, records = bootstrap.extract_runtime(archive,Path(directory)/"out","llama-b11669")
            self.assertEqual((extracted/"alias").read_bytes(),b"runtime")
            self.assertEqual(records['files']['llama-server']['bytes'],7)

    def test_valid_internal_symlink_chain(self):
        with tempfile.TemporaryDirectory() as directory:
            probe = Path(directory)/"probe"
            try:
                os.symlink("target",probe)
                probe.unlink()
            except OSError:
                self.skipTest("Local account lacks symlink creation privilege")
            archive = make_archive(Path(directory)/"runtime.tar.gz", [
                ("llama-b11669/library.so.1","file",b"library"),
                ("llama-b11669/library.so.0","symbolic","library.so.1"),
                ("llama-b11669/library.so","symbolic","library.so.0"),
            ])
            extracted, records = bootstrap.extract_runtime(archive,Path(directory)/"out","llama-b11669")
            self.assertEqual((extracted/"library.so").read_bytes(),b"library")
            self.assertEqual(len(records['links']),2)


class InstallTests(unittest.TestCase):
    def test_install_idempotence_and_corruption_repair(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive=make_archive(root/"runtime.tar.gz",[("llama-b11669/llama-server","file",b"runtime")])
            runtime=runtime_for(archive)
            check=Mock()
            self.assertTrue(bootstrap.install_runtime(archive,root/"bin",runtime,version_check=check))
            self.assertFalse(bootstrap.install_runtime(archive,root/"bin",runtime,version_check=check))
            binary=root/"bin/llama-b11669/llama-server"
            binary.write_bytes(b"corrupt")
            self.assertTrue(bootstrap.install_runtime(archive,root/"bin",runtime,version_check=check))
            self.assertEqual(binary.read_bytes(),b"runtime")
            self.assertEqual(check.call_count,3)

    def test_failed_new_version_probe_keeps_old_runtime(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            old=make_archive(root/"old.tar.gz",[("llama-b11669/llama-server","file",b"old")])
            bootstrap.install_runtime(old,root/"bin",runtime_for(old),version_check=Mock())
            new=make_archive(root/"new.tar.gz",[("llama-b11669/llama-server","file",b"new")])
            failed=Mock(side_effect=bootstrap.BootstrapError("runtime_version_probe_failed"))
            with self.assertRaisesRegex(bootstrap.BootstrapError,"version_probe_failed"):
                bootstrap.install_runtime(new,root/"bin",runtime_for(new),version_check=failed)
            self.assertEqual((root/"bin/llama-b11669/llama-server").read_bytes(),b"old")

    def test_unsigned_archive_and_unmanaged_target_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            archive=make_archive(root/"runtime.tar.gz",[("llama-b11669/llama-server","file",b"ok")])
            runtime=runtime_for(archive)
            wrong=copy.deepcopy(runtime);wrong['linuxX64']['sha256']='0'*64
            with self.assertRaisesRegex(bootstrap.BootstrapError,"archive_digest"):
                bootstrap.install_runtime(archive,root/"bin",wrong,version_check=Mock())
            (root/"bin/llama-b11669").mkdir(parents=True)
            with self.assertRaisesRegex(bootstrap.BootstrapError,"unmanaged"):
                bootstrap.install_runtime(archive,root/"bin",runtime,version_check=Mock())

    def test_version_probe_requires_pinned_build_and_sanitizes_failure(self):
        good=Mock(return_value=subprocess.CompletedProcess([],0,b'version: 0.7.0-dev (build 11669, commit 620d2225c)',b''))
        bootstrap.verify_runtime_version('/runtime/llama-server','b11669',run=good)
        bad=Mock(return_value=subprocess.CompletedProcess([],1,b'https://signed.example?DO_NOT_LOG',b''))
        with self.assertRaisesRegex(bootstrap.BootstrapError,'runtime_version_probe_failed'):
            bootstrap.verify_runtime_version('/runtime/llama-server','b11669',run=bad)

    def test_windows_runtime_is_skipped_and_pinned_manifest_validated(self):
        manifest=json.loads((Path(bootstrap.__file__).parent/'model-manifest.json').read_text())
        with tempfile.TemporaryDirectory() as directory,patch.object(bootstrap,'download_verified') as download:
            result=bootstrap.bootstrap(manifest,Path(directory)/'models',Path(directory)/'bin',mode='runtime',platform_name='Windows')
            self.assertEqual(result['runtime'],'skipped_non_linux')
            download.assert_not_called()
        bad=copy.deepcopy(manifest);bad['runtime']['linuxX64']['binaryRelativePath']='../llama-server'
        with self.assertRaisesRegex(bootstrap.BootstrapError,'binary_path'):
            bootstrap.validate_manifest(bad)


if __name__ == '__main__':
    unittest.main()
