"""Dated, publisher-attributed news collection for Melo Radio."""

__version__ = "1.0.0"
