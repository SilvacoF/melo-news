"""Install the exact public embedding model and pinned Linux CPU runtime.

Render build command (from the repository root):
    pip install -r melo_news/requirements.txt && python -m melo_news.bootstrap_models

Only manifest-pinned bytes are accepted. Downloads are anonymous, streamed,
bounded, and replaced atomically after SHA256 verification. No model execution
or remote-code loading occurs; Linux installation checks llama-server --version.
Windows/macOS may download the model, but the Linux runtime is explicitly skipped.
No credentials, redirected URLs, or signed storage URLs are logged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import posixpath
import re
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = Path(__file__).resolve().parent
MAX_ARCHIVE_MEMBERS = 4096
MAX_EXPANDED_BYTES = 256 * 1024 * 1024
USER_AGENT = "MeloNewsModelBootstrap/1.0 (anonymous public artifact download)"
REDIRECT_DOMAINS = (
    "huggingface.co", "hf.co", "xethub.hf.co", "github.com",
    "githubusercontent.com", "githubassets.com",
)


class BootstrapError(RuntimeError):
    """A fixed, non-sensitive build failure code."""


def _digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def verify_file(path, expected_bytes, expected_sha256):
    path = Path(path)
    return (path.is_file() and not path.is_symlink()
            and path.stat().st_size == expected_bytes
            and _digest(path) == expected_sha256)


def _trusted_url(url):
    try:
        parsed = urllib.parse.urlsplit(url)
        host = (parsed.hostname or "").lower()
        return (parsed.scheme == "https" and not parsed.username and not parsed.password
                and parsed.port in (None, 443)
                and any(host == domain or host.endswith("." + domain) for domain in REDIRECT_DOMAINS))
    except ValueError:
        return False


class PublicArtifactRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        if not _trusted_url(new_url):
            raise BootstrapError("untrusted_download_redirect")
        return super().redirect_request(request, fp, code, message, headers, new_url)


def download_verified(url, destination, expected_bytes, expected_sha256, *, retries=2,
                      timeout=30, deadline=300, opener=None, sleep=time.sleep):
    """Return True when downloaded, False for an already verified local file."""
    destination = Path(destination)
    if (not _trusted_url(url) or not isinstance(expected_bytes, int) or expected_bytes <= 0
            or not isinstance(expected_sha256, str) or not re.fullmatch(r"[a-f0-9]{64}", expected_sha256)
            or not 0 <= retries <= 2 or not 1 <= timeout <= 60 or not 1 <= deadline <= 900):
        raise BootstrapError("invalid_download_configuration")
    if verify_file(destination, expected_bytes, expected_sha256):
        return False
    if destination.is_symlink():
        raise BootstrapError("refused_symlink_artifact_target")
    destination.parent.mkdir(parents=True, exist_ok=True)
    opener = opener or urllib.request.build_opener(PublicArtifactRedirects())
    failure = "download_failed"
    for attempt in range(retries + 1):
        descriptor, temporary_name = tempfile.mkstemp(prefix="." + destination.name + ".", suffix=".part", dir=destination.parent)
        temporary = Path(temporary_name)
        transient, retry_delay = False, min(2, attempt + 1)
        started = time.monotonic()
        try:
            request = urllib.request.Request(url, headers={
                "User-Agent": USER_AGENT, "Accept-Encoding": "identity",
                "Accept": "application/octet-stream",
            })
            with os.fdopen(descriptor, "wb") as output:
                descriptor = None
                with opener.open(request, timeout=min(timeout, deadline)) as response:
                    status = getattr(response, "status", 200)
                    if status != 200:
                        raise BootstrapError("unexpected_download_status")
                    encoding = response.headers.get("Content-Encoding", "identity").lower()
                    if encoding not in {"", "identity"}:
                        raise BootstrapError("unexpected_download_encoding")
                    length = response.headers.get("Content-Length")
                    if length is not None and (not length.isdigit() or int(length) != expected_bytes):
                        raise BootstrapError("download_content_length_mismatch")
                    count, digest = 0, hashlib.sha256()
                    while True:
                        if time.monotonic() - started > deadline:
                            raise BootstrapError("download_deadline_exceeded")
                        chunk = response.read(min(1024 * 1024, expected_bytes - count + 1))
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > expected_bytes:
                            raise BootstrapError("download_size_exceeded")
                        digest.update(chunk)
                        output.write(chunk)
                    if count != expected_bytes:
                        raise BootstrapError("download_size_mismatch")
                    if digest.hexdigest() != expected_sha256:
                        raise BootstrapError("download_digest_mismatch")
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, destination)
            return True
        except BootstrapError as error:
            failure = str(error)  # All BootstrapError messages are fixed local codes.
        except urllib.error.HTTPError as error:
            failure = "download_http_" + str(int(error.code))
            transient = error.code in {408, 429, 500, 502, 503, 504}
            retry_after = error.headers.get("Retry-After", "") if error.headers else ""
            if retry_after.isdigit():
                requested = int(retry_after)
                if requested > 30:
                    transient = False
                    failure = "download_retry_deferred"
                else:
                    retry_delay = max(retry_delay, requested)
        except (OSError, TimeoutError, urllib.error.URLError):
            failure, transient = "download_transport_failed", True
        finally:
            if descriptor is not None:
                os.close(descriptor)
            temporary.unlink(missing_ok=True)
        if not transient or attempt >= retries:
            break
        sleep(retry_delay)
    raise BootstrapError(failure) from None


def _relative_archive_name(name, root_name):
    if (not name or "\\" in name or ":" in name or "\x00" in name
            or name.startswith("/") or ".." in PurePosixPath(name).parts):
        raise BootstrapError("unsafe_archive_path")
    normalized = posixpath.normpath(name)
    if normalized != root_name and not normalized.startswith(root_name + "/"):
        raise BootstrapError("archive_root_mismatch")
    return normalized


def _link_target(member, root_name):
    link = member.linkname
    if not link or "\\" in link or ":" in link or "\x00" in link or link.startswith("/"):
        raise BootstrapError("unsafe_archive_link")
    target = posixpath.normpath(posixpath.join(posixpath.dirname(member.name), link) if member.issym() else link)
    if target != root_name and not target.startswith(root_name + "/"):
        raise BootstrapError("archive_link_escapes_root")
    return target


def extract_runtime(archive, staging_directory, root_name):
    """Extract regular files first; only validated internal links come afterward."""
    staging_directory = Path(staging_directory).resolve()
    staging_directory.mkdir(parents=True, exist_ok=True)
    records = {"files": {}, "links": {}}
    try:
        with tarfile.open(archive, "r:gz") as stream:
            members = []
            by_name, links, expanded = {}, {}, 0
            for member in stream:
                if len(members) >= MAX_ARCHIVE_MEMBERS:
                    raise BootstrapError("too_many_archive_members")
                members.append(member)
                normalized = _relative_archive_name(member.name, root_name)
                if normalized in by_name:
                    raise BootstrapError("duplicate_archive_path")
                member.name = normalized
                if not (member.isdir() or member.isfile() or member.issym() or member.islnk()):
                    raise BootstrapError("unsupported_archive_member")
                if member.size < 0:
                    raise BootstrapError("invalid_archive_member_size")
                by_name[normalized] = member
                if member.isfile():
                    expanded += member.size
                    if expanded > MAX_EXPANDED_BYTES:
                        raise BootstrapError("archive_expansion_limit_exceeded")
                if member.issym() or member.islnk():
                    links[normalized] = _link_target(member, root_name)
            if expanded > MAX_EXPANDED_BYTES:
                raise BootstrapError("archive_expansion_limit_exceeded")
            for name in by_name:
                parent = posixpath.dirname(name)
                while parent and parent != ".":
                    if parent in links:
                        raise BootstrapError("archive_member_under_link")
                    parent = posixpath.dirname(parent)
            def resolve_link(name):
                visited = set()
                while name in links:
                    if name in visited:
                        raise BootstrapError("archive_link_cycle")
                    visited.add(name)
                    name = links[name]
                if name not in by_name:
                    raise BootstrapError("archive_link_target_missing")
                return name
            for name in links:
                final = resolve_link(name)
                if by_name[name].islnk() and not by_name[final].isfile():
                    raise BootstrapError("invalid_archive_hardlink")
            for member in members:
                output = staging_directory.joinpath(*PurePosixPath(member.name).parts)
                output.resolve().relative_to(staging_directory)
                if member.isdir():
                    output.mkdir(parents=True, exist_ok=True)
                    output.chmod(0o755)
                elif member.isfile():
                    output.parent.mkdir(parents=True, exist_ok=True)
                    digest, count = hashlib.sha256(), 0
                    source = stream.extractfile(member)
                    if source is None:
                        raise BootstrapError("archive_member_unreadable")
                    with source, output.open("xb") as target:
                        while True:
                            chunk = source.read(1024 * 1024)
                            if not chunk:
                                break
                            count += len(chunk)
                            if count > member.size:
                                raise BootstrapError("archive_member_size_exceeded")
                            digest.update(chunk)
                            target.write(chunk)
                    if count != member.size:
                        raise BootstrapError("archive_member_size_mismatch")
                    mode = 0o755 if member.mode & 0o111 else 0o644
                    output.chmod(mode)
                    relative = posixpath.relpath(member.name, root_name)
                    records["files"][relative] = {"bytes": count, "sha256": digest.hexdigest(), "mode": mode}
            for name in links:
                member = by_name[name]
                output = staging_directory.joinpath(*PurePosixPath(name).parts)
                output.parent.mkdir(parents=True, exist_ok=True)
                if member.issym():
                    os.symlink(member.linkname, output)
                    records["links"][posixpath.relpath(name, root_name)] = member.linkname
                else:
                    final = staging_directory.joinpath(*PurePosixPath(resolve_link(name)).parts)
                    os.link(final, output)
                    relative = posixpath.relpath(name, root_name)
                    records["files"][relative] = dict(records["files"][posixpath.relpath(resolve_link(name), root_name)])
        return staging_directory / root_name, records
    except BootstrapError:
        raise
    except (OSError, ValueError, tarfile.TarError):
        raise BootstrapError("runtime_archive_invalid") from None


def _runtime_matches(destination, archive_digest):
    destination = Path(destination)
    marker = destination / ".melo-bootstrap.json"
    try:
        record = json.loads(marker.read_text(encoding="utf-8"))
        if record.get("archiveSha256") != archive_digest or not record.get("files"):
            return False
        for relative, expected in record["files"].items():
            path = destination.joinpath(*PurePosixPath(relative).parts)
            path.resolve().relative_to(destination.resolve())
            if not verify_file(path, expected["bytes"], expected["sha256"]):
                return False
            if os.name != "nt" and path.stat().st_mode & 0o777 != expected["mode"]:
                return False
        for relative, target in record.get("links", {}).items():
            path = destination.joinpath(*PurePosixPath(relative).parts)
            if not path.is_symlink() or os.readlink(path) != target:
                return False
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def verify_runtime_version(binary, tag, *, run=subprocess.run):
    try:
        result = run([str(binary), "--version"], stdin=subprocess.DEVNULL,
                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20,
                     check=False, env={**os.environ, "LLAMA_ARG_OFFLINE": "1"})
        body = (result.stdout + result.stderr).decode("utf-8", errors="replace")
        build = re.escape(tag.removeprefix("b"))
        if result.returncode or not re.search(r"(?:build\s+|b)" + build + r"\b", body):
            raise BootstrapError("runtime_version_probe_failed")
    except BootstrapError:
        raise
    except (OSError, subprocess.SubprocessError):
        raise BootstrapError("runtime_version_probe_failed") from None


def install_runtime(archive, bin_directory, runtime, *, version_check=verify_runtime_version):
    bin_directory = Path(bin_directory).resolve()
    root_name = "llama-" + runtime["tag"]
    descriptor = runtime["linuxX64"]
    if not verify_file(archive, descriptor["bytes"], descriptor["sha256"]):
        raise BootstrapError("runtime_archive_digest_mismatch")
    destination = bin_directory / root_name
    if destination.is_symlink():
        raise BootstrapError("refused_symlink_runtime_target")
    destination.resolve().relative_to(bin_directory)
    binary = bin_directory.joinpath(*PurePosixPath(descriptor["binaryRelativePath"]).parts)
    if _runtime_matches(destination, descriptor["sha256"]):
        version_check(binary, runtime["tag"])
        return False
    bin_directory.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not (destination / ".melo-bootstrap.json").is_file():
        raise BootstrapError("refused_unmanaged_runtime_directory")
    with tempfile.TemporaryDirectory(prefix=".melo-runtime-", dir=bin_directory) as temporary_name:
        staging = Path(temporary_name).resolve()
        staging.relative_to(bin_directory)
        extracted, records = extract_runtime(archive, staging, root_name)
        relative_binary = PurePosixPath(descriptor["binaryRelativePath"]).relative_to(root_name)
        staged_binary = extracted.joinpath(*relative_binary.parts)
        if not staged_binary.is_file() or staged_binary.is_symlink():
            raise BootstrapError("runtime_binary_missing")
        staged_binary.chmod(0o755)
        records["files"][relative_binary.as_posix()]["mode"] = 0o755
        version_check(staged_binary, runtime["tag"])
        records.update(schemaVersion=1, archiveSha256=descriptor["sha256"], tag=runtime["tag"])
        (extracted / ".melo-bootstrap.json").write_text(json.dumps(records, sort_keys=True, indent=2)+"\n", encoding="utf-8")
        backup = staging / "previous-runtime"
        moved_previous = False
        try:
            if destination.exists():
                destination.resolve().relative_to(bin_directory)
                destination.rename(backup)
                moved_previous = True
            extracted.rename(destination)
        except OSError:
            if moved_previous and not destination.exists():
                backup.rename(destination)
            raise BootstrapError("runtime_atomic_install_failed") from None
        # TemporaryDirectory removes only this verified private staging tree.
        # Any previous managed runtime was moved inside that tree after validation.
    return True


def validate_manifest(manifest):
    try:
        model, runtime = manifest["embedding"], manifest["runtime"]
        descriptor = runtime["linuxX64"]
        if (manifest.get("schemaVersion") != 1
                or not re.fullmatch(r"[A-Za-z0-9._-]+/[A-Za-z0-9._-]+", model["repo"])
                or not re.fullmatch(r"[a-f0-9]{40}", model["revision"])
                or not re.fullmatch(r"[A-Za-z0-9._-]+\.gguf", model["file"])
                or not re.fullmatch(r"b[0-9]+", runtime["tag"])
                or not re.fullmatch(r"[A-Za-z0-9._-]+\.tar\.gz", descriptor["file"])):
            raise BootstrapError("invalid_model_manifest")
        for record in (model, descriptor):
            if (not isinstance(record["bytes"], int) or not 1 <= record["bytes"] <= 1024**3
                    or not re.fullmatch(r"[a-f0-9]{64}", record["sha256"])):
                raise BootstrapError("invalid_model_manifest")
        expected_url = "https://github.com/ggml-org/llama.cpp/releases/download/" + runtime["tag"] + "/" + descriptor["file"]
        if descriptor["url"] != expected_url:
            raise BootstrapError("invalid_runtime_source")
        expected_binary = "llama-" + runtime["tag"] + "/llama-server"
        if descriptor["binaryRelativePath"] != expected_binary:
            raise BootstrapError("invalid_runtime_binary_path")
        return manifest
    except BootstrapError:
        raise
    except (KeyError, TypeError, ValueError):
        raise BootstrapError("invalid_model_manifest") from None


def bootstrap(manifest, model_directory, bin_directory, *, mode="all", retries=2,
              timeout=30, deadline=300, platform_name=None, machine=None):
    manifest = validate_manifest(manifest)
    result = {"ok": True, "model": "skipped", "runtime": "skipped"}
    if mode not in {"all", "model", "runtime"}:
        raise BootstrapError("invalid_bootstrap_mode")
    if mode in {"all", "model"}:
        model = manifest["embedding"]
        url = "https://huggingface.co/" + model["repo"] + "/resolve/" + model["revision"] + "/" + model["file"]
        changed = download_verified(url, Path(model_directory) / model["file"], model["bytes"], model["sha256"], retries=retries, timeout=timeout, deadline=deadline)
        result["model"] = "downloaded_verified" if changed else "already_verified"
    if mode in {"all", "runtime"}:
        system, architecture = platform_name or platform.system(), (machine or platform.machine()).lower()
        if system != "Linux":
            result["runtime"] = "skipped_non_linux"
        elif architecture not in {"x86_64", "amd64"}:
            raise BootstrapError("unsupported_linux_architecture")
        else:
            runtime = manifest["runtime"]
            descriptor = runtime["linuxX64"]
            archive = Path(bin_directory) / ".bootstrap-downloads" / descriptor["file"]
            download_verified(descriptor["url"], archive, descriptor["bytes"], descriptor["sha256"], retries=retries, timeout=timeout, deadline=deadline)
            changed = install_runtime(archive, bin_directory, runtime)
            result["runtime"] = "installed_verified" if changed else "already_verified"
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--manifest", type=Path, default=BASE / "model-manifest.json")
    parser.add_argument("--model-dir", type=Path, default=BASE / "models")
    parser.add_argument("--bin-dir", type=Path, default=BASE / "bin")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--model-only", action="store_true")
    modes.add_argument("--runtime-only", action="store_true")
    parser.add_argument("--retries", type=int, choices=range(3), default=2)
    parser.add_argument("--timeout-seconds", type=float, default=30)
    parser.add_argument("--deadline-seconds", type=float, default=300)
    args = parser.parse_args(argv)
    try:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        mode = "model" if args.model_only else "runtime" if args.runtime_only else "all"
        value = bootstrap(manifest, args.model_dir, args.bin_dir, mode=mode,
                          retries=args.retries, timeout=args.timeout_seconds, deadline=args.deadline_seconds)
        print(json.dumps(value))
        return 0
    except BootstrapError as error:
        print(json.dumps({"ok": False, "error": str(error)}), file=sys.stderr)
        return 2
    except (OSError, ValueError, TypeError):
        print(json.dumps({"ok": False, "error": "bootstrap_failed"}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
