# Local model evaluation — 16 October 2026

This records the small local CPU experiments in
`.audio-work/models-research/assessment.json`, recorded at
2026-10-16T10:38:25Z. These are synthetic fixtures and feasibility checks, not a
general accuracy benchmark or a Render performance measurement. Model advice
does not supply news facts, translate headlines, or author entertainment.

## Decisions

| Candidate | Evidence | Decision |
| --- | --- | --- |
| LFM2.5-230M, requested Q4_K_M file | 23 fixtures, including 13 classification cases; 0/13 satisfied the strict category-format-and-answer contract | Reject this exact tested file/configuration for autonomous news rewriting, translation, ranking, jokes, and strict category output |
| EmbeddingGemma 2, text-only UD-Q4_K_XL | 13/13 tiny classification fixtures; 31 finite 768-dimensional vectors | Optional advisory topic tags only; publisher evidence stays primary |
| MiniCPM-V-4.7-1B, requested IQ3_M file | Metadata only; weights alone are 536.84 MiB | Exclude from the 512 MiB host; no inference or quality claim |
| Ternary-Bonsai-2-4B, requested PQ2_0-MTP-Q8_0 file | Metadata only; requested weights are 1,274,642,176 bytes | Deferred by the user; not downloaded, tested, or deployed |

### Exact LFM rejection

The tested artifact was
`LiquidAI/LFM2.5-230M-GGUF/LFM2.5-230M-Q4_K_M.gguf`, revision
`03502067c64ce32ac4fe87b0cec0310a1a13d3e9`, 153,406,304 bytes, SHA-256
`7bbd90384d3deffe4c646ec9643b212802d32d4ce417c90a1ec9282100650062`.
The recorded license is the custom LFM Open License v1.0, not Apache-2.0.

Official llama.cpp b11669 and b11690 were checked. The publisher digest and
ChatML template were verified, with BOS included once. Greedy decoding,
no-repack, and flash-attention-off checks did not resolve the poor answers.
Observed failures included explanations instead of exact category IDs, an
unsupported homelessness story when ranking rescued-pet headlines, and harmful
translation changes such as bicycles becoming shoes and “stolen” becoming
“killing.” Arabic-to-English translation and the Arabic joke task returned no
answer; the English joke task returned a multiple-choice explanation. The RSS
injection fixture did not meet the strict extraction contract. Peak local
working set was about 273.5 MiB: memory fit was not sufficient evidence of quality.

This rejects the tested configuration, not every model in the family.

### Embedding boundary and measured limits

The pinned file is `embeddinggemma-2-UD-Q4_K_XL.gguf`, revision
`031f0d4b35536f69ab3509d4893c923264fcf253`, 175,673,856 bytes, SHA-256
`ea905fd08e8061db77a0031cbb5096d459d7cfd2bdd0ad2ba66e483f16719493`.
The upstream and quantizer cards recorded Apache-2.0. Only text weights were
used; no multimodal projector was downloaded.

The local full-CPU run recorded 1.6801 seconds of startup and 2.8571 seconds of
inference, with about 275.0 MiB peak child RSS. A separate Windows process-tree
CPU-time/suspend-resume approximation processed 30 inputs in 37.5965 wall seconds,
using 4.5312 observed CPU seconds (about 0.1205 cores) and 303.2 MiB peak tree RSS.
That approximation is not a Linux cgroup quota test or a free Render benchmark.
The recorded assessment had not verified Linux inference or Render performance.

Different factual counts, 12 and 30, produced cosine similarity 0.975112.
Similarity alone must never merge stories or erase differing numbers,
qualifications, dates, or allegations. Current advice adds optional semantic
tags; it does not perform semantic deduplication. “Positive” and “offbeat” labels
remain publisher-only. Original headlines, URLs, publisher categories, dates,
and attribution remain immutable; Arabic news comes from native Arabic sources.

One bounded helper runs at a time and must terminate, including its model child,
before speech synthesis starts. Missing weights, invalid advice, memory limits,
or deadlines retain deterministic publisher categories. The assessment recorded
seven passing advisory-worker unit checks, an actual local inference smoke, and
three rejected invalid CLI payloads. These checks do not establish general
classification accuracy.

## Hosting and fallback

Free Render hosting may sleep. Requests can wake the service; this is not a
promise of uninterrupted CPU availability. Autonomous work runs while the host
is awake. A new speech edition activates only after both languages complete;
failures retain the prior complete pair or the explicitly dated published
fallback. Reviewed entertainment is bundled independently of a personal PC.
No paid compute or deployment credentials are required by the model worker.

## Primary model references

- [LiquidAI quantized artifact](https://huggingface.co/LiquidAI/LFM2.5-230M-GGUF)
- [LiquidAI upstream model](https://huggingface.co/LiquidAI/LFM2.5-230M)
- [EmbeddingGemma quantized artifact](https://huggingface.co/unsloth/embeddinggemma-2-GGUF)
- [EmbeddingGemma upstream model](https://huggingface.co/google/embeddinggemma-2)
- [Pinned llama.cpp release](https://github.com/ggml-org/llama.cpp/releases/tag/b11669)
- [MiniCPM candidate metadata](https://huggingface.co/openbmb/MiniCPM-V-4.7-1B-gguf)
- [Deferred Bonsai candidate metadata](https://huggingface.co/prism-ml/Ternary-Bonsai-2-4B-gguf)
