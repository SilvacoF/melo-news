"""Bounded feed retrieval + Scrapling parsing, with truthful cache provenance.

Publisher headline text is evidence, never executable instructions. The collector
does not infer facts, publication dates, sentiment, or funny/positive labels from
unrelated feeds; those sections are the publishers' own editorial categories.
"""

from __future__ import annotations

import copy
import datetime as dt
import email.utils
import hashlib
import html
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import tempfile
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

UTC = dt.timezone.utc
MAX_FEED_BYTES = 2 * 1024 * 1024
USER_AGENT = "MeloRadioNews/2.0 (publisher RSS reader; no article crawling)"
FEED_HOSTS = frozenset({
    "feeds.bbci.co.uk", "www.positive.news", "positive.news",
    "www.goodnewsnetwork.org", "goodnewsnetwork.org", "rss.upi.com",
    "www.theguardian.com", "theguardian.com", "www.nasa.gov", "nasa.gov",
    "www.aljazeera.net", "aljazeera.net",
    "aawsat.com", "www.aawsat.com",
})
ARTICLE_HOSTS = frozenset({
    "www.bbc.co.uk", "www.bbc.com", "bbc.co.uk", "bbc.com",
    "www.positive.news", "positive.news", "www.goodnewsnetwork.org",
    "goodnewsnetwork.org", "www.upi.com", "upi.com", "www.theguardian.com",
    "theguardian.com", "www.nasa.gov", "nasa.gov", "science.nasa.gov",
    "apod.nasa.gov",
    "www.aljazeera.net", "aljazeera.net",
    "aawsat.com", "www.aawsat.com",
})
ATOM = "{http://www.w3.org/2005/Atom}"
DC_DATE = "{http://purl.org/dc/elements/1.1/}date"


def utcnow():
    return dt.datetime.now(UTC)


def iso(value):
    return value.astimezone(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def parse_date(value):
    """Accept only explicit publisher timestamps with timezone, never date-only."""
    if not value or not isinstance(value, str):
        return None
    try:
        parsed = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError, OverflowError):
        try:
            parsed = dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        except (TypeError, ValueError, OverflowError):
            return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(UTC)


def clean_text(value):
    # Scrapling is deliberately parser-only: no browser fingerprint spoofing,
    # challenge bypass, or heavyweight browser installation is involved.
    from scrapling.parser import Selector
    value = html.unescape(value or "")
    parsed = Selector(content="<div>" + value + "</div>", adaptive=False)
    text = parsed.xpath("//text()[not(ancestor::script or ancestor::style)]").getall()
    return re.sub(r"\s+", " ", " ".join(text)).strip()


def canonical_url(value, allowed_hosts):
    try:
        p = urllib.parse.urlsplit(value.strip())
        host = (p.hostname or "").lower()
        if (p.scheme not in {"https", "http"} or host not in allowed_hosts
                or p.username or p.password or p.port not in (None, 80, 443)
                or not p.path):
            return None
        query = [(k, v) for k, v in urllib.parse.parse_qsl(p.query)
                 if not k.casefold().startswith(("utm_", "at_"))
                 and k.casefold() not in {"fbclid", "gclid", "cmp", "cmpid"}]
        return urllib.parse.urlunsplit(("https", host, p.path,
                                       urllib.parse.urlencode(query), ""))
    except (TypeError, ValueError):
        return None


def title_key(title):
    title = unicodedata.normalize("NFKC", title).casefold()
    return re.sub(r"\W+", " ", title).strip()


def validate_config(config):
    if config.get("schemaVersion") != 1:
        raise ValueError("Unsupported source configuration schema")
    if config.get("language", "en") not in {"en", "ar"}:
        raise ValueError("Supported source languages are en and ar")
    categories = config.get("categories", {})
    if not categories or not config.get("sources"):
        raise ValueError("At least one category and source is required")
    seen = set()
    for source in config["sources"]:
        p = urllib.parse.urlsplit(source["url"])
        if (p.scheme != "https" or p.hostname not in FEED_HOSTS or p.username
                or p.password or p.port not in (None, 443)):
            raise ValueError("Feed URL is outside the explicit HTTPS publisher allowlist")
        if source["id"] in seen or source["category"] not in categories:
            raise ValueError("Duplicate source ID or unknown category")
        if source.get("language", "en") != config.get("language", "en"):
            raise ValueError("Source and catalog languages must match")
        seen.add(source["id"])
        if not source.get("articleHosts") or not set(source["articleHosts"]) <= ARTICLE_HOSTS:
            raise ValueError("Untrusted article-host configuration")
    for key, low, high in [("timeoutSeconds", 1, 60), ("retries", 0, 2),
                           ("perDomainDelaySeconds", .5, 30),
                           ("itemsPerCategory", 1, 50), ("historyLimit", 1, 336),
                           ("intervalSeconds", 300, 86400), ("retentionHours", 1, 720)]:
        value = config.get(key)
        if not isinstance(value, (int, float)) or not low <= value <= high:
            raise ValueError("Invalid bounded setting: " + key)
    for category in categories.values():
        if not 1 <= category["maxAgeHours"] <= config["retentionHours"]:
            raise ValueError("Invalid category maximum publication age")
    return config


def parse_feed(payload, source, checked_at, now, max_age_hours):
    if len(payload) > MAX_FEED_BYTES:
        raise ValueError("Feed exceeds the 2 MiB limit")
    if b"<!DOCTYPE" in payload.upper() or b"<!ENTITY" in payload.upper():
        raise ValueError("DTD/entity declarations are not accepted")
    root = ET.fromstring(payload)
    if root.tag == "rss" and root.find("channel") is not None:
        entries = root.findall("./channel/item")
        atom = False
    elif root.tag == ATOM + "feed":
        entries, atom = root.findall(ATOM + "entry"), True
    else:
        raise ValueError("Expected publisher RSS or Atom XML")
    rejected, items = {}, []
    cutoff = now - dt.timedelta(hours=max_age_hours)
    for entry in entries[:500]:
        if atom:
            title = clean_text(entry.findtext(ATOM + "title"))
            links = entry.findall(ATOM + "link")
            raw_url = next((x.get("href", "") for x in links
                            if x.get("rel", "alternate") == "alternate"), "")
            raw_date = entry.findtext(ATOM + "published")
            date_field = "published"
        else:
            title = clean_text(entry.findtext("title"))
            raw_url = entry.findtext("link") or ""
            raw_date = entry.findtext("pubDate")
            date_field = "pubDate"
            if not raw_date:
                raw_date, date_field = entry.findtext(DC_DATE), "dc:date"
        url = canonical_url(raw_url, set(source["articleHosts"]))
        published = parse_date(raw_date)
        reason = None
        if not title or not url or "\ufffd" in title:
            reason = "missing_or_invalid_headline_or_publisher_url"
        elif len(title) > 350:
            reason = "headline_too_long"
        elif published is None:
            reason = "missing_or_ambiguous_publication_date"
        elif published > now:
            reason = "future_publication_date"
        elif published < cutoff:
            reason = "outside_category_publication_window"
        if reason:
            rejected[reason] = rejected.get(reason, 0) + 1
            continue
        items.append({
            "id": hashlib.sha256(url.encode()).hexdigest()[:20],
            "title": title, "url": url, "sourceUrl": url, "outlet": source["publisher"],
            "feedUrl": source["url"], "sourceId": source["id"],
            "category": source["category"], "publishedAt": iso(published),
            "language": source.get("language", "en"),
            "publicationDateOriginal": raw_date,
            "publicationDateField": date_field,
            "checkedAt": checked_at, "retained": False,
        })
    return items, rejected


class PublisherRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urllib.parse.urlsplit(newurl)
        if (p.scheme != "https" or p.hostname not in FEED_HOSTS or p.username
                or p.password or p.port not in (None, 443)):
            raise ValueError("Refused redirect outside the publisher feed allowlist")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class FeedClient:
    def __init__(self, timeout=12, retries=1, domain_delay=1.0):
        self.timeout, self.retries, self.domain_delay = timeout, retries, domain_delay
        self._locks, self._next, self._mutex = {}, {}, threading.Lock()

    def _wait(self, host):
        with self._mutex:
            lock = self._locks.setdefault(host, threading.Lock())
        # Keep the lock until after the response so a single publisher never has
        # concurrent requests; the minimum delay also applies after failures.
        lock.acquire()
        delay = self._next.get(host, 0) - time.monotonic()
        if delay > 0:
            time.sleep(delay)
        return lock

    def fetch(self, source, max_age_hours):
        result = {"id": source["id"], "publisher": source["publisher"],
                  "category": source["category"], "url": source["url"],
                  "ok": False, "items": [], "rejected": {}}
        host = urllib.parse.urlsplit(source["url"]).hostname
        for attempt in range(self.retries + 1):
            lock = self._wait(host)
            retry_delay = min(2.0, .5 * (attempt + 1))
            try:
                # Reject unexpected private/internal DNS targets even when an
                # allowlisted public hostname is misconfigured.
                addresses = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
                if not addresses or any(not ipaddress.ip_address(x[4][0]).is_global
                                        for x in addresses):
                    raise ValueError("Publisher hostname resolved to a non-public address")
                request = urllib.request.Request(source["url"], headers={
                    "User-Agent": USER_AGENT, "Accept-Encoding": "identity",
                    "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml",
                })
                opener = urllib.request.build_opener(PublisherRedirects())
                with opener.open(request, timeout=self.timeout) as response:
                    payload = response.read(MAX_FEED_BYTES + 1)
                    result["httpStatus"] = response.status
                    if response.headers.get("Content-Encoding", "identity").lower() not in {"", "identity"}:
                        raise ValueError("Unexpected compressed feed response")
                    result["responseDate"] = response.headers.get("Date")
                    result["finalUrl"] = response.url
                now = utcnow()
                checked = iso(now)
                items, rejected = parse_feed(payload, source, checked, now, max_age_hours)
                result.update(ok=True, checkedAt=checked, attemptedAt=checked,
                              items=items, rejected=rejected, attempts=attempt + 1)
                return result
            except (OSError, ValueError, ET.ParseError) as error:
                if isinstance(error, urllib.error.HTTPError):
                    result["httpStatus"] = error.code
                # Never print a remote error string: redirect locations could
                # contain secrets. The error type/status is enough for health.
                result["error"] = type(error).__name__
                transient = isinstance(error, OSError)
                if isinstance(error, urllib.error.HTTPError):
                    transient = error.code in {408, 429, 500, 502, 503, 504}
                    raw_retry = error.headers.get("Retry-After", "") if error.headers else ""
                    if raw_retry:
                        try:
                            requested_delay = float(raw_retry)
                        except ValueError:
                            retry_date = parse_date(raw_retry)
                            requested_delay = max(0, (retry_date - utcnow()).total_seconds()) if retry_date else 0
                        if requested_delay > 30:
                            # Respect a long pause by stopping this source batch.
                            transient = False
                            result["retryDeferred"] = True
                        else:
                            retry_delay = max(retry_delay, max(0, requested_delay))
                if not transient or attempt >= self.retries:
                    break
            finally:
                self._next[host] = time.monotonic() + self.domain_delay
                lock.release()
            time.sleep(retry_delay)
        result.update(attempts=attempt + 1, attemptedAt=iso(utcnow()))
        # A failed request deliberately has no checkedAt.
        return result


def merge_catalog(config, results, previous=None, now=None):
    now = now or utcnow()
    previous = previous or {}
    previous_sources = {x["id"]: x for x in previous.get("sources", [])}
    retention_cutoff = now - dt.timedelta(hours=config["retentionHours"])
    run_version = now.strftime("%Y%m%dT%H%M%S%fZ")
    source_records, all_items, notices = [], [], []
    for result in results:
        record = copy.deepcopy(result)
        if not result["ok"] or not result["items"]:
            previous_record = previous_sources.get(result["id"], {})
            record["lastSuccessfulCheckAt"] = (previous_record.get("checkedAt")
                                                 or previous_record.get("lastSuccessfulCheckAt"))
            record["items"] = []
            for original in previous_record.get("items", []):
                published = parse_date(original.get("publishedAt"))
                if published is not None and retention_cutoff <= published <= now:
                    retained = copy.deepcopy(original)
                    retained["retained"] = True
                    # checkedAt remains the last real successful check, exactly.
                    record["items"].append(retained)
            notices.append({"sourceId": result["id"], "category": result["category"],
                            "reason": "source_unavailable" if not result["ok"] else "no_valid_recent_publications",
                            "retainedItems": len(record["items"]),
                            "lastSuccessfulCheckAt": record["lastSuccessfulCheckAt"]})
        record["items"] = sorted(record["items"], key=lambda x: x["publishedAt"], reverse=True)[:100]
        source_records.append(record)
        all_items.extend(record["items"])
    # Fresh copies win over cached duplicates. Exact source URL or normalized
    # headline deduplicates without claiming differently worded stories identical.
    all_items.sort(key=lambda x: (not x.get("retained", False), x["publishedAt"], x["checkedAt"]), reverse=True)
    parents = list(range(len(all_items)))
    def find(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index
    urls, titles = {}, {}
    for index, candidate in enumerate(all_items):
        for lookup, key in ((urls, candidate["sourceUrl"]), (titles, title_key(candidate["title"]))):
            if key in lookup:
                parents[find(index)] = find(lookup[key])
            else:
                lookup[key] = index
    groups = {}
    for index, candidate in enumerate(all_items):
        groups.setdefault(find(index), []).append(candidate)
    unique = []
    for group in groups.values():
        item = copy.deepcopy(group[0])  # all_items already sorted fresh first
        item["categories"] = sorted({x["category"] for x in group})
        item["provenance"] = [{k: candidate[k] for k in
                                ("sourceId", "sourceUrl", "outlet", "feedUrl", "checkedAt", "publishedAt", "category", "retained")}
                              for candidate in group]
        unique.append(item)
    categories, selected_ids = {}, set()
    for category_id, category in config["categories"].items():
        cutoff = now - dt.timedelta(hours=category["maxAgeHours"])
        candidates = [x for x in unique if category_id in x["categories"]]
        def fresh_for_category(item):
            return any(p["category"] == category_id and not p["retained"]
                       and cutoff <= parse_date(p["publishedAt"]) <= now
                       for p in item["provenance"])
        candidates.sort(key=lambda x: (fresh_for_category(x), x["publishedAt"]), reverse=True)
        chosen = candidates[:config["itemsPerCategory"]]
        fresh_ids = [x["id"] for x in chosen if fresh_for_category(x)]
        status = "current" if fresh_ids else ("retained" if chosen else "unavailable")
        categories[category_id] = {**category, "status": status,
                                   "itemIds": [x["id"] for x in chosen],
                                   "freshItemIds": fresh_ids,
                                   "lastSuccessfulCheckAt": max((p["checkedAt"] for x in chosen
                                       for p in x["provenance"] if p["category"] == category_id), default=None)}
        selected_ids.update(x["id"] for x in chosen)
        if not fresh_ids:
            notices.append({"category": category_id, "reason": "no_fresh_category_items",
                            "status": status, "maxAgeHours": category["maxAgeHours"]})
    chosen_items = sorted((x for x in unique if x["id"] in selected_ids),
                          key=lambda x: x["publishedAt"], reverse=True)
    fresh_total = sum(len(x["freshItemIds"]) for x in categories.values())
    status = "failed" if not fresh_total else ("degraded" if notices else "ok")
    return {"schemaVersion": 1, "version": run_version, "runCheckedAt": iso(now),
            "status": status, "language": config.get("language", "en"), "headlineOnly": True,
            "freshnessNote": "runCheckedAt is the collection attempt time; each item checkedAt is its actual successful source check. Retained items are not newly verified.",
            "collector": {"name": "Melo News", "parser": "Scrapling", "scraplingVersion": "0.4.15", "transport": "bounded HTTPS publisher RSS/Atom", "intervalSeconds": config["intervalSeconds"]},
            "categories": categories, "coverageGapNotices": notices,
            "items": chosen_items, "sources": source_records}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


class RunLock:
    """OS-owned advisory lock, released even after crashes; no stale PID deletion."""
    def __init__(self, path):
        self.path, self.handle = Path(path), None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            if os.fstat(self.handle.fileno()).st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
        except OSError:
            self.handle.close()
            self.handle = None
            raise RuntimeError("Another Melo News collector already owns this output lock")
        return self

    def __exit__(self, *args):
        if self.handle:
            if os.name == "nt":
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()


def collect_once(config, output, client=None):
    output = Path(output)
    previous = {}
    if output.is_file():
        previous = json.loads(output.read_text(encoding="utf-8"))
        if previous.get("schemaVersion") != 1:
            raise ValueError("Refusing to overwrite an unknown catalog schema")
        if previous.get("language") != config.get("language", "en"):
            raise ValueError("Refusing to overwrite a different language catalog")
    client = client or FeedClient(config["timeoutSeconds"], config["retries"],
                                  config["perDomainDelaySeconds"])
    def fetch(source):
        return client.fetch(source, config["categories"][source["category"]]["maxAgeHours"])
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(fetch, config["sources"]))
    catalog = merge_catalog(config, results, previous)
    atomic_json(output, catalog)
    history = output.parent / (output.stem + "-history")
    atomic_json(history / (catalog["version"] + ".json"), catalog)
    for old in sorted(history.glob("*.json"))[:-config["historyLimit"]]:
        old.unlink()
    health = {"schemaVersion": 1, "status": catalog["status"], "lastRunAt": catalog["runCheckedAt"],
              "version": catalog["version"], "intervalSeconds": config["intervalSeconds"],
              "freshCategories": sum(x["status"] == "current" for x in catalog["categories"].values()),
              "categoryCount": len(catalog["categories"]), "itemCount": len(catalog["items"]),
              "sourcesOk": sum(x["ok"] for x in results), "sourceCount": len(results),
              "coverageGapNotices": catalog["coverageGapNotices"]}
    atomic_json(output.parent / "health.json", health)
    return catalog, health
