"""Install only hash-pinned local voice archives from the public repository."""
import hashlib
import json
from pathlib import Path
import re
import zipfile


def install(package=None, repository=None):
    package = Path(package or Path(__file__).parent)
    repository = Path(repository or package.parent)
    descriptor = json.loads((package / 'discussion-archives.json').read_text(encoding='utf-8'))
    assets = json.loads((package / 'discussion-audio.json').read_text(encoding='utf-8'))['bundledAudio']
    if descriptor.get('schemaVersion') != 1 or not 1 <= len(descriptor['archives']) <= 8:
        raise ValueError('Invalid reviewed voice archive manifest')
    installed = set()
    for record in descriptor['archives']:
        name = record['file']
        if not re.fullmatch(r'melo-discussion-audio-[1-8]\.zip', name):
            raise ValueError('Unsafe voice archive name')
        source = repository / name
        if source.stat().st_size != record['bytes'] or source.stat().st_size > 14000000:
            raise ValueError('Voice archive size differs')
        if hashlib.sha256(source.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError('Voice archive hash differs')
        with zipfile.ZipFile(source) as archive:
            for member in archive.infolist():
                digest = member.filename.removesuffix('.mp3')
                if not re.fullmatch(r'[a-f0-9]{64}', digest) or digest not in assets or digest in installed:
                    raise ValueError('Unexpected reviewed voice archive member')
                expected = assets[digest]
                if member.filename != digest + '.mp3' or member.file_size != expected['size'] or member.file_size > 2000000:
                    raise ValueError('Voice member size differs')
                body = archive.read(member)
                if hashlib.sha256(body).hexdigest() != digest:
                    raise ValueError('Voice member hash differs')
                target = package / 'content-audio' / (digest + '.mp3')
                target.parent.mkdir(exist_ok=True)
                target.write_bytes(body)
                installed.add(digest)
    if installed != set(assets):
        raise ValueError('Reviewed voice archives are incomplete')
    return {'reviewedTurns': len(installed), 'archives': len(descriptor['archives']), 'hashesVerified': True}
