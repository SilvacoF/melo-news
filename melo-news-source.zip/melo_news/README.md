# Melo News collector

An independent, continuously runnable news collector for Melo Radio. It fetches
only the publisher RSS/Atom URLs in `sources.json` and uses **Scrapling 0.4.15**
to parse publisher headline markup. Transport is bounded HTTPS with an honest
RSS-reader User-Agent, four workers, one active request per publisher host,
at least one second between that host's requests, and one retry. It does not
crawl article pages, solve challenges, use proxies, or call paid services.

The default output is `melo_news/data/catalog.json`; it does not replace existing
radio drafts, audio, frontend files, or live deployments.

## Runtime and setup

Python **3.10 or newer** is required by the pinned Scrapling release. Python 3.11
is installed on the current Windows host; its default `python` is 3.9 and cannot
run this dependency. The core parser needs no browser installation.

```powershell
py -3.11 -m venv melo_news/.venv
melo_news/.venv/Scripts/python.exe -m pip install -r melo_news/requirements.txt
melo_news/.venv/Scripts/python.exe -m unittest discover -s melo_news/tests -v
melo_news/.venv/Scripts/python.exe -m melo_news --once
melo_news/.venv/Scripts/python.exe -m melo_news --health
# Omit --once to keep collecting every 30 minutes until terminated.
melo_news/.venv/Scripts/python.exe -m melo_news --interval-seconds 1800
```

Run commands from the repository root. `--output PATH` selects a new output;
`--config PATH` selects a reviewed source configuration. Source hosts remain
restricted by the code allowlist even with a custom configuration. A shared OS
file lock prevents multiple schedulers writing the same catalog. Ctrl+C/SIGTERM
stops after an active bounded batch; systemd/Docker can restart after crashes.

Exit codes: `0` has verified current coverage (some gaps may still be present),
`2` no current items or unhealthy/stale health, `3` configuration/startup/lock
failure. A healthy HTTP request with zero in-window publications is an explicit
coverage gap, not a source transport failure. A bad optional feed does not block
other publishers.

## Consumer contract

Category IDs are `world`, `positive`, `offbeat`, `technology`, `ai`, `economy`,
`sports`, `nature`, `travel`, `history`, and `science`. These reflect publisher
sections, not inferred sentiment. Positive News and Good News Network supply
the good-news section; UPI's Odd News supplies surprising/offbeat stories. A
light story can still discuss difficulty: no claim that every item is cheerful.

`catalog.json` schema version 1 contains:

- `runCheckedAt`: real collection attempt time, **never an item's freshness**.
- `items`: deduplicated headline evidence with stable `id`, exact plain `title`,
  `url`/`sourceUrl`, `outlet`, `sourceId`, `feedUrl`, `category`, `categories`,
  `publishedAt`, original publication string/field, real successful `checkedAt`,
  `retained`, and per-category `provenance`.
- `categories[ID].itemIds` and `freshItemIds`: use **freshItemIds** for new spoken
  news. `current`, `retained`, and `unavailable` statuses explain coverage. One
  story may have evidence in multiple sections; `provenance` preserves that.
- `coverageGapNotices`: source outages, no dated recent publications, or missing
  current category coverage. They must remain visible if radio selects that gap.
- `sources`: exact configured feeds, successful `checkedAt` or failure
  `attemptedAt`, HTTP status, rejection counts, bounded source evidence/cache.

Publication timestamps require an explicit timezone. Atom `updated`, RSS
`lastBuildDate`, HTTP `Date`, and fetch time are never substituted for missing
publication time. Future, too old, undated, malformed, and off-publisher items
are rejected. The publication windows are explicit per section: 24 hours for
world, good news, offbeat, technology, AI, economy, sport, nature, and science;
seven days is explicitly allowed only for history/travel features.

An unavailable feed or a successful feed without current dated items keeps the
last available source items for up to seven days. Their **original checkedAt
never changes**; `retained=true` and category/source notices prevent presenting
them as newly checked. Other successfully fetched sources keep updating. A run
with no fresh items is `failed`; a run with some current coverage and notices is
`degraded`. Unknown schemas/corrupt previous JSON are never overwritten by a
new empty catalog. Unexpected collector failure retains the prior catalog.

Catalog and `health.json` writes are atomic; up to 48 catalog snapshots are kept
beside the output under `catalog-history/`. Source evidence is bounded at 100
items per feed; selected output defaults to eight per category. The `--health`
check reads local health only and becomes stale after two intervals plus three
minutes. It does not contact publishers or mark old news as fresh.

Integrating with existing radio should select current category IDs, translate
the exact source headline with reviewed attribution and qualifications, and
generate both language editions before the existing guarded publish step.
Article text is not copied or automatically summarized. Do not use the catalog
attempt timestamp to label cached news current.

## Linux server deployment examples

These files prepare a server installation; running the local collector does
not make a static hosting platform execute Python. A separate running machine
is needed. Credentials and site deployment remain the radio service's concern.

For systemd, place this package at `/opt/melo/melo_news`, create an unprivileged
`melo` user, install requirements into `/opt/melo/.venv`, then install
`deploy/melo-news.service` under `/etc/systemd/system/` and enable/start that
service. Persistent output is `/var/lib/melo-news/catalog.json`. Review with
`journalctl -u melo-news`; inspect the local health record with the same Python
environment and `--output /var/lib/melo-news/catalog.json --health`.

For Docker, run `docker compose -f melo_news/deploy/compose.yaml up -d --build`
from the repository root. It runs non-root with a persistent named volume and
health check. The Dockerfile copies only this package; do not add credentials to
the image. To integrate collection with another service, import `collect_once`
and acquire `RunLock(output.with_suffix(output.suffix + '.lock'))` around writes,
or invoke the `--once` CLI. Do not also run two separate schedulers for one path.

## Read-only API and native Arabic news

`sources-ar.json` collects exact native Arabic headlines from BBC Arabic and
Al Jazeera with their own publication timestamps. These are independent Arabic
world-news items, not translations of the English 11-category catalog. No
unreviewed machine translation is used. This keeps publisher language and facts
intact while an editor may separately review broader translated radio coverage.

```powershell
melo_news/.venv/Scripts/python.exe -m melo_news --config melo_news/sources-ar.json --output melo_news/data/ar/catalog.json --once
melo_news/.venv/Scripts/python.exe -m melo_news.api --port 8080
```

The API serves `/news.json?language=en` and `/news.json?language=ar`, plus `/health`
(process liveness). It refreshes a cache older than five minutes on demand,
shares one refresh among simultaneous requests for a language, and waits at
most 15 seconds per request. A cold request with no completed cache returns
HTTP 202 + `Retry-After: 5`; background work continues. Old dated cache is
explicitly marked `api.stale` and gets a `collection_cache_stale` notice. An
unexpected refresh failure retains prior data and its original check times.
Source failures retry no more often than once per minute. While awake, a
background loop also checks every 30 minutes.

Use a free Render Python web service with build command
`pip install -r melo_news/requirements.txt`, start command
`python -m melo_news.api --port $PORT`, and health path `/health`. One process
owns each cache; do not add multiple worker processes. The public API is
read-only and needs no site/account keys. A here.now same-origin proxy can
expose these endpoints without changing the station URL or requiring CORS.

Free hosts can sleep and discard local cache on restart. This is **not a
promise of continuous CPU execution**; cold starts fetch current data on demand
and return dated cache or HTTP 202 within the wait limit. Render disk cache is
ephemeral unless an appropriate persistent volume is separately available;
the news API rebuilds from publisher feeds after a cold start. `/health` means
the process is alive; its per-edition fields report collection state separately.

## Source and dependency references

- [Scrapling project](https://github.com/D4Vinci/Scrapling)
- [Scrapling core parser usage](https://scrapling.readthedocs.io/en/latest/parsing/selection.html)
- [PyPI package metadata](https://pypi.org/pypi/scrapling/json): latest checked
  2026-10-16, version 0.4.15, `Requires-Python: >=3.10`.
- Publisher feed URLs and exact publication strings are recorded in the source
  configuration and each collection artifact; they are the direct evidence.
