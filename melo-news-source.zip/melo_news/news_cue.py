"""Reviewed bilingual news framing and an original two-second synthesized cue."""
import array
import copy
import math
import wave

CUE_VERSION = "melo-news-chime-2s-v1"
CUE_SECONDS = 2
SAMPLE_RATE = 44100


def frame_news(segment, live=False):
    if segment.get("type") != "news" or segment.get("language") not in ("en", "ar"):
        raise ValueError("News framing needs an English or Arabic bulletin")
    result = copy.deepcopy(segment)
    body = result.get("newsBodyText", result["text"])
    arabic = result["language"] == "ar"
    intro = "حان وقت الأخبار!" if arabic else ("Live news!" if live else "News update!")
    outro = "شكرًا!" if arabic else "Thanks!"
    result["newsBodyText"] = body
    result["speech_parts"] = [{"text": intro, "pause_after": .15},
                              {"text": body, "pause_after": .2},
                              {"text": outro, "pause_after": 0}]
    result["text"] = "\n\n".join(part["text"] for part in result["speech_parts"])
    result["newsCue"] = {"version": CUE_VERSION, "duration": CUE_SECONDS,
                         "intro": intro, "outro": outro, "mode": "server" if live else "dated-fallback"}
    return result


def write_sting(path):
    """Two seconds exactly; gentle original ascending chimes, no sampled audio."""
    notes = [(0, 392), (.28, 523.25), (.56, 659.25), (.84, 783.99), (1.12, 1046.5)]
    pcm = array.array("h")
    for index in range(SAMPLE_RATE * CUE_SECONDS):
        t = index / SAMPLE_RATE
        sample = 0.0
        for start, frequency in notes:
            age = t - start
            if age >= 0:
                envelope = min(1, age / .012) * math.exp(-3.8 * age)
                sample += .13 * envelope * (math.sin(2 * math.pi * frequency * age)
                                            + .2 * math.sin(2 * math.pi * 2 * frequency * age))
        sample *= min(1, (CUE_SECONDS - t) / .08)
        pcm.append(round(max(-.8, min(.8, sample)) * 32767))
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(pcm.tobytes())
