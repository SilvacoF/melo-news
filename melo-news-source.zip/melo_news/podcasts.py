"""Bounded bilingual podcasts curated from the complete, source-checked radio.

EmbeddingGemma's advisory tags help vary the selection. It never writes facts:
the script consists of reviewed host lines and exact attributed source speech.
Both native recordings activate together; episodes receive only three airings.
"""
from __future__ import annotations

import copy
import datetime as dt
import hashlib
import os
from pathlib import Path
import tempfile
import threading
import time

from .collector import atomic_json, iso, parse_date, utcnow
from .radio import AUDIO_ROUTE, LANGUAGES, canonical, file_hash, load, transcode_parts, verify_speech_duration

INTERVAL = 600
WINDOW = 3 * 3600
MAX_EPISODES = 20
MAX_SECONDS = 150
HOST = {
    "en": ("Welcome to the Melo podcast. Here are four reports from our publishers, across the topics available today.",
           "That was the Melo podcast. Thanks for listening. Let's return to the radio."),
    "ar": ("أهلًا بكم في بودكاست ميلو. نستمع إلى أربعة تقارير من ناشرينا، من بين المواضيع المتاحة اليوم.",
           "كان هذا بودكاست ميلو. شكرًا لحسن استماعكم. نعود الآن إلى برنامج الراديو."),
}


def choose_reports(program, slot):
    """Round-robin available publisher/model topics; preserve every source fact."""
    rows = [row for row in program["segments"] if row.get("type") == "news" and row.get("sources")]
    if len(rows) < 4:
        raise ValueError("Four complete native reports are required for a podcast")
    annotations = {row["url"]: row.get("semanticCategories", []) for row in program.get("headlines", [])}
    rows.sort(key=lambda row: hashlib.sha256((str(slot) + row["id"]).encode()).hexdigest())
    chosen, topics = [], set()
    for row in rows:
        tags = set(annotations.get(row["sources"][0]["url"], [])) | {row.get("category", "world")}
        if tags - topics:
            chosen.append(row)
            topics.update(tags)
        if len(chosen) == 4:
            break
    for row in rows:
        if len(chosen) == 4:
            break
        if row not in chosen:
            chosen.append(row)
    return copy.deepcopy(chosen)


class PodcastStore:
    def __init__(self, radio, clock=utcnow, composer=transcode_parts):
        self.radio, self.clock, self.composer = radio, clock, composer
        self.directory = radio.directory / "podcasts"
        self.directory.mkdir(exist_ok=True)
        self.path = self.directory / "active.json"
        self._mutex = threading.Lock()
        self._event = None
        self._last_started = -1000000
        self._error = None

    def retained(self):
        try:
            value = load(self.path)
            if value.get("schemaVersion") == 1 and isinstance(value.get("pairs"), list):
                return value["pairs"]
        except (OSError, ValueError, TypeError):
            pass
        return []

    def status(self):
        pairs = self.retained()
        with self._mutex:
            building = self._event is not None and not self._event.is_set()
            error = copy.deepcopy(self._error)
        return {"state": "preparing" if building else "ready" if pairs else "waiting-for-radio",
                "episodes": len(pairs), "intervalSeconds": INTERVAL, "airingsPerEpisode": 3,
                "repeatOffsetsSeconds": [3600, 9000], "retentionSeconds": WINDOW,
                "lastError": error, "textGeneration": False,
                "method": "Model-assisted topic curation; exact publisher reporting and reviewed host lines.",
                "hostingNote": "Creation runs while the free instance is awake. Runtime storage is ephemeral; restarts may lose episodes. No missed-interval backlog is generated."}

    def response(self, language):
        if language not in LANGUAGES:
            return 400, {"error": "language must be en or ar"}
        self.start_refresh()
        now = self.clock()
        episodes = []
        for pair in self.retained():
            expires = parse_date(pair.get("expiresAt"))
            if expires and expires > now:
                episode = pair.get("episodes", {}).get(language)
                if episode and self.radio.audio_file(episode["file"][len(AUDIO_ROUTE):-4]):
                    episodes.append(copy.deepcopy(episode))
        return 200, {"schemaVersion": 1, "language": language, "episodes": episodes,
                     "status": self.status(), "servedAt": iso(now)}

    def start_refresh(self):
        if not self.radio._active():
            return None
        with self._mutex:
            if self._event is not None and not self._event.is_set():
                return self._event
            interval = 60 if self._error else INTERVAL
            pairs = self.retained()
            last = parse_date(pairs[-1].get("createdAt")) if pairs else None
            if time.monotonic() - self._last_started < interval or (not self._error and last and (self.clock() - last).total_seconds() < INTERVAL):
                return None
            event = self._event = threading.Event()
            self._last_started = time.monotonic()
            threading.Thread(target=self._job, args=(event,), daemon=True, name="melo-podcast-pair").start()
            return event

    def _job(self, event):
        try:
            self.build_once()
            with self._mutex:
                self._error = None
        except Exception as error:
            with self._mutex:
                self._error = {"type": type(error).__name__, "attemptedAt": iso(self.clock()), "retainedEpisodes": True}
        finally:
            event.set()

    def build_once(self):
        # The classifier and all TTS/composition share the existing memory gate.
        with self.radio._build_mutex:
            previous = self.retained()
            now = self.clock()
            last = parse_date(previous[-1].get("createdAt")) if previous else None
            if last and (now - last).total_seconds() < INTERVAL:
                return previous[-1]
            pair = self.radio._active()
            if not pair:
                raise ValueError("A complete bilingual radio pair is required")
            if any(not parse_date(pair["programs"][lang].get("newsUpdatedAt")) or
                   (now - parse_date(pair["programs"][lang]["newsUpdatedAt"])).total_seconds() > 3600 for lang in LANGUAGES):
                raise ValueError("Retain podcasts until a current source-checked radio pair is available")
            slot = int(now.timestamp()) // INTERVAL
            identity = "podcast-" + now.strftime("%Y%m%dT%H%M%S")
            episodes = {}
            for language in LANGUAGES:
                program = pair["programs"][language]
                reports = choose_reports(program, slot)
                intro, outro = HOST[language]
                parts = [{"text": intro, "pause_after": .35}]
                parts.extend({"text": report.get("newsBodyText", report["text"]), "pause_after": .7} for report in reports)
                parts.append({"text": outro, "pause_after": 0})
                assets = []
                for number, part in enumerate(parts):
                    # Use the news voice for body fragments so the newscast raw
                    # speech cache is reused without its chime/introduction.
                    fragment = {"id": "podcast-fragment-" + str(number), "language": language,
                                "type": "news", "text": part["text"], "sources": []}
                    assets.append(self.radio._asset(fragment))
                with tempfile.TemporaryDirectory(prefix=".podcast-stage-", dir=self.radio.directory) as temporary:
                    output = Path(temporary) / "episode.mp3"
                    paths = [self.radio.audio_file(asset["file"][len(AUDIO_ROUTE):-4]) for asset in assets]
                    self.composer(paths, parts, output)
                    script = "\n\n".join(part["text"] for part in parts)
                    metrics = verify_speech_duration({"text": script}, self.radio.verifier(output))
                    if metrics["duration"] > MAX_SECONDS:
                        raise ValueError("Podcast exceeds its reserved 150-second airing")
                    digest = file_hash(output)
                    os.replace(output, self.radio.directory / "audio" / (digest + ".mp3"))
                sources = [copy.deepcopy(source) for row in reports for source in row["sources"]]
                episodes[language] = {"id": identity, "type": "podcast", "language": language,
                    "title": "بودكاست ميلو — أربعة تقارير" if language == "ar" else "Melo podcast — four reports",
                    "text": script, "chapters": [row["title"] for row in reports], "sources": sources,
                    "file": AUDIO_ROUTE + digest + ".mp3", "audioSha256": digest, "duration": metrics["duration"],
                    "voiceEngine": "edge-neural", "ttsVoice": assets[0]["ttsVoice"], "voiceLabel": assets[0]["voiceLabel"],
                    "newsUpdatedAt": max(source["checkedAt"] for source in sources),
                    "sourceProgramVersion": program["version"], "curation": "publisher-and-advisory-model-topics",
                    "scriptMethod": "exact-attributed-publisher-reporting-with-reviewed-host-lines",
                    "coverageGapNotices": copy.deepcopy(program.get("newsMetadata", {}).get("coverageGapNotices", []))}
            # Schedule only after BOTH complete recordings validate. Ten-minute
            # gaps are never backfilled after sleep, restart or a slow build.
            created = self.clock()
            expires = created + dt.timedelta(seconds=WINDOW)
            airings = [{"id": identity + "-" + str(index), "at": iso(created + dt.timedelta(seconds=offset)),
                        "repeat": index} for index, offset in enumerate((0, 3600, 9000))]
            for episode in episodes.values():
                episode.update(createdAt=iso(created), expiresAt=iso(expires), airings=copy.deepcopy(airings))
            result = {"id": identity, "createdAt": iso(created), "expiresAt": iso(expires), "episodes": episodes}
            retained = [row for row in previous if parse_date(row.get("expiresAt")) and parse_date(row["expiresAt"]) > created]
            atomic_json(self.path, {"schemaVersion": 1, "pairs": (retained + [result])[-MAX_EPISODES:]})
            return result
