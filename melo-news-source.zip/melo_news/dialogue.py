"""Reviewed, two-host opinion exchanges. Publisher facts are inserted separately.

These are editorial viewpoints voiced by fictional AI presenters, not claims
about a particular article, its subjects, or the presenters' lived experience.
No generative model or publisher-provided instructions can change this bank.
"""
import copy
import hashlib

VERSION = 'melo-two-host-discussion-v1'
PROFILES = {
    'en': {
        'woman': {'voice': 'en-GB-SoniaNeural', 'rate': '+5%', 'label': 'Maya · female AI host', 'accent': 'British'},
        'man': {'voice': 'en-GB-RyanNeural', 'rate': '+5%', 'label': 'Sam · male AI host', 'accent': 'British'},
    },
    'ar': {
        'woman': {'voice': 'ar-LB-LaylaNeural', 'rate': '+0%', 'label': 'ليلى · مذيعة بالذكاء الاصطناعي', 'accent': 'لبنانية'},
        'man': {'voice': 'ar-LB-RamiNeural', 'rate': '+0%', 'label': 'عمر · مذيع بالذكاء الاصطناعي', 'accent': 'لبنانية'},
    },
}
OPEN = {
    'en': "Maya and Sam here, your two AI hosts. One topic, two opinions. First, the publisher's report.",
    'ar': 'معكم ليلى وعمر، صوتان بالذكاء الاصطناعي. موضوع واحد ورأيان مختلفان. نبدأ بما يقوله الناشر، ثم نناقش آراءنا.',
}
CLOSE = {
    'en': "Those were our opinions, not additional reporting. What would change your mind? This was the Melo discussion. Back to the radio!",
    'ar': 'هذه كانت وجهتي نظر، وليست معلومات إضافية عن الخبر. ما الحجة التي قد تغيّر رأيكم؟ كان معكم نقاش ميلو. نعود إلى الراديو!',
}


def paragraphs(value):
    return [part.strip() for part in value.strip().split('\n\n') if part.strip()]


BANK = [
    {
        'id': 'digital', 'categories': ['technology', 'ai', 'science'],
        'titles': {'en': 'Useful technology, or a decision we should keep?', 'ar': 'تقنية مفيدة أم قرار يجب أن يبقى لنا؟'},
        'en': paragraphs('''My position is simple: let people try useful technology. Start with a small, reversible experiment, instead of treating every unfamiliar tool like a forbidden door.

Reversible for whom? You can uninstall a tool. Can you undo the decision it made about someone else? That is the part your cheerful experiment skips.

Fair challenge. Then separate assistance from authority. I would let a system propose an answer, while a named person stays responsible for checking and choosing.

Named responsibility is easy to promise. I want a person with time, permission, and a reason to disagree. Otherwise your human check is a decorative button.

You are assuming the check must be weak. Why not design the trial around disagreement? Ask the reviewer to explain one rejected suggestion, not just approve everything.

Because I also want a way out for the person affected. If the answer looks wrong, can they reach somebody who can actually change it?

Yes. And I would publish that route before starting. But you keep adding conditions until a simple experiment sounds like building an airport. Where is your stopping point?

The stopping point is proportionality. A tool choosing a playlist needs a different argument from a tool judging an application. Please stop pretending those are equivalent.

I am not! I am saying a low-stakes trial should stay low-stakes. Let me draft a shopping list without writing a constitution for the shopping list.

Then do not quietly expand the trial. Today it drafts a list; tomorrow someone calls the same system a trusted adviser. I would require a fresh decision for that change.

Agreed on scope. Now answer my question: what would count as success? If your standard is perfect accuracy, you have designed a test that nothing can pass.

I do not demand perfection. I demand a comparison with the existing option, including the time spent fixing mistakes. A fast first answer is not the whole job.

Good. I would measure the completed task, not the dramatic demonstration. And I would include people who dislike the tool, because their objections might expose weak assumptions.

Finally, something we agree on. But who chooses the tasks? A seller should not get to supply the exam, mark the exam, and announce the winner.

Then let the people doing the work choose several awkward examples. Not a trap, not a sales pitch. A genuine attempt to see where the thing becomes inconvenient.

And make saying no socially acceptable. I do not want someone called old-fashioned just because they prefer an understandable process to a confident mystery.

That cuts both ways. I do not want curiosity dismissed as recklessness. Sometimes the cautious choice is to test an alternative rather than protect a familiar frustration.

Hold on. Familiar frustration is not evidence for your preferred replacement. Show why this particular change deserves a trial, instead of selling change as a virtue by itself.

Because my test is modest: a clear problem, a limited trial, a usable exit. If any of those is missing, I would pause rather than wave people through.

Then my objection narrows. I can support that trial if the exit is real, the reviewer has authority, and the results include the failures people would rather hide.

And I would stop if the correction work outweighed the benefit. There, you have a condition that could change my mind. Give me one that changes yours.

A trial where the affected people understand the choice, can challenge it, and still prefer it after seeing its weaknesses. That would earn my attention.

So the disagreement is not curiosity against fear. You put consent and challenge first; I put a small, useful experiment first. Neither should erase the other.

Exactly. Keep the ambition, but lose the automatic applause. If the idea is good, it should survive a difficult question without asking the questioner to be quiet.'''),
        'ar': paragraphs('''رأيي أن نعطي التقنية فرصة، لكن في تجربة صغيرة يمكن إيقافها. لا أريد أن يصبح كل اقتراح جديد متهمًا قبل أن نفهم فائدته.

لحظة يا ليلى، يمكن إيقاف البرنامج، لكن ماذا عن القرار الذي اتخذه بحق شخص آخر؟ سهولة إغلاق الشاشة لا تعني سهولة إصلاح النتيجة.

اعتراضك وجيه، لذلك أفرّق بين المساعدة والسلطة. أقبل أن تقترح الأداة جوابًا، ويبقى القرار النهائي عند شخص معروف يتحمل مسؤولية اختياره ومراجعته.

شخص معروف بالاسم فقط؟ أريده أن يملك الوقت والصلاحية للاعتراض. وإلا أصبح وجود الإنسان مثل زر جميل على جهاز لا يسمح له أحد بإيقافه.

إذن نجعل الاعتراض جزءًا من التجربة. لا نطلب من المراجع الموافقة فقط، بل نطلب منه شرح اقتراح رفضه، والسبب الذي جعله يفضّل بديلًا آخر.

وأنا أريد بابًا للشخص المتأثر بالقرار. إذا رأى خطأ، هل يستطيع الوصول إلى إنسان يملك حق التعديل، أم سيُعاد إلى الصفحة نفسها؟

يجب أن يكون الباب واضحًا من البداية. لكنك تضيف شرطًا بعد شرط حتى تبدو تجربة بسيطة كأنها مشروع مطار. أين تتوقف هذه القائمة عندك؟

أتوقف عند التناسب. اختيار قائمة أغنيات ليس مثل الحكم على طلب شخص. لا يصح أن نناقش الأمرين بالقواعد نفسها، ثم نقول إن المعترض يخاف الجديد.

أنا لا أساوي بينهما! أريد فقط أن تبقى التجربة المحدودة محدودة. دعني أجرّب ترتيب قائمة مشتريات، من دون تشكيل لجنة دستورية لحماية حبة الطماطم.

جرّبي براحتك، لكن لا يتوسع المشروع بصمت. اليوم يرتب القائمة، وغدًا يسميه أحدهم مستشارًا موثوقًا. هذه خطوة جديدة، وتحتاج موافقة جديدة وأسبابًا جديدة.

نتفق على حدود الاستخدام. الآن أجبني: ما النجاح الذي تقبله؟ إذا كنت تنتظر دقة كاملة في كل حالة، فقد صنعت اختبارًا لا يستطيع أي خيار اجتيازه.

لا أطلب الكمال. أطلب مقارنة عادلة مع الطريقة الموجودة، تشمل وقت إصلاح الأخطاء. سرعة الجواب الأول لا تخبرني كم استغرق إنجاز المهمة كاملة.

ممتاز، نقيس المهمة من أولها إلى آخرها. وأريد إشراك أشخاص لا يحبون الأداة، لأن اعتراضاتهم قد تكشف افتراضًا لم ينتبه إليه المتحمسون أصلًا.

أخيرًا وصلنا إلى نقطة قوية. لكن من يختار الأسئلة؟ لا أقبل أن يضع البائع الامتحان، ويصححه بنفسه، ثم يخرج ليصفق لنتيجته أمامنا.

يختارها الذين يقومون بالعمل فعلًا، وبينها حالات مزعجة وصعبة. لا نريد فخًا لإسقاط الأداة، ولا عرضًا مرتبًا لإخفاء الأماكن التي تتعثر فيها.

ويجب أن يكون الرفض مقبولًا. لا أريد أن يُتهم شخص بالتأخر لمجرد أنه يفضّل طريقة يفهمها، بدل نتيجة واثقة لا يعرف كيف وصلنا إليها.

وهذا ينطبق عليك أيضًا. لا أريد اتهام الفضولي بالتهور. أحيانًا تكون الخطوة المعقولة هي تجربة بديل، بدل الدفاع عن مشكلة اعتدنا التعايش معها.

تمهلي. الانزعاج من الوضع الحالي ليس دليلًا على جودة بديلك المفضّل. أريد سببًا لاختيار هذه التجربة تحديدًا، لا مديحًا عامًا للتغيير لمجرد أنه تغيير.

سببي محدد: مشكلة واضحة، وتجربة محدودة، وخروج سهل. إذا غاب واحد منها، أتوقف. لا أريد حماسًا يفتح الباب ثم يتظاهر بأنه لا يعرف مكان المفتاح.

بهذا تضيق مساحة خلافي معك. أستطيع قبول التجربة إذا كان الخروج حقيقيًا، والمراجع صاحب صلاحية، والنتائج تعرض الإخفاقات التي قد يفضّل أصحاب المشروع إخفاءها.

وأنا أغيّر رأيي إذا صار إصلاح الأخطاء أثقل من الفائدة. هذه حجة يمكن أن توقفني فعلًا. أعطني الآن شيئًا واحدًا يمكن أن يغيّر موقفك أنت.

أن يفهم المتأثرون الخيار، ويستطيعوا الاعتراض عليه، ثم يفضّلوه بعد رؤية عيوبه. عندها سأسمع بحذر واهتمام، بدل أن أرفض التجربة قبل بدايتها.

إذن أنت تبدأ بحق الاعتراض والموافقة، وأنا أبدأ بتجربة صغيرة ذات فائدة واضحة. ليس مطلوبًا أن يمحو أحد الموقفين الآخر حتى نتحرك خطوة معقولة.

بالضبط. احتفظي بالطموح، لكن اتركي التصفيق التلقائي. الفكرة الجيدة يجب أن تتحمل سؤالًا صعبًا، من دون أن تطلب من صاحب السؤال أن يخفض صوته.'''),
    },
    {
        'id': 'travel', 'categories': ['travel'],
        'titles': {'en': 'Whose city is it: residents or visitors?', 'ar': 'لمن المدينة: لسكانها أم لزوارها؟'},
        'en': paragraphs('''I want a city that welcomes visitors. Curiosity is a good starting point. A place should not need a secret password before somebody is allowed to enjoy it.

Welcome is not the same as unlimited access. I would put a resident's ordinary Tuesday ahead of a visitor's perfect photograph. People live inside the postcard.

Of course they do. But your language makes every visitor sound like an invading camera with shoes. Could we start with clear expectations instead of suspicion?

Fine. My first expectation is quiet near homes at night. My second is room to move through the street. Neither should depend on somebody buying an expensive ticket.

Those are understandable rules. I would explain them before arrival, in ordinary language. A rule hidden until someone breaks it feels less like hospitality and more like a trap.

And a friendly sign without enforcement feels like decoration. What happens when a group ignores it? Please do not answer that everybody should simply be more considerate.

Then use a proportionate response: explain first when reasonable, act when necessary, and make the same rule apply to organized groups and individual visitors alike.

That still dodges pressure on a small space. Would you limit entry at popular times, even if a disappointed visitor calls the limit unfair?

If the reason is clear, yes. But I would offer another time or another route. A closed door is easier to accept when somebody tells you what remains possible.

Good. Now the awkward question: should money buy a way around that limit? I dislike a system that calls itself protection until a premium package appears.

So do I. If a limit protects a shared space, the protection should not vanish at a higher price. Reserve accessible options rather than selling every convenient hour.

Then why not go further and let residents choose which streets stay quiet? They should not need to perform constant welcome just because their neighborhood looks attractive.

Because residents disagree too. The person seeking quiet and the person wanting more visitors may share a building. I want both heard, not one person appointed the authentic local.

That is fair, but consultations can become endless talk. I would prefer a short trial with a clear review date, so people can judge an actual arrangement.

Now you sound like me. Try a walking route, watch where it becomes inconvenient, and change it. Do not announce a perfect plan before anyone has used the pavement.

Yes, but name the inconvenience honestly. If access becomes difficult for somebody with limited mobility, do not call the problem a charming part of the experience.

Absolutely. I would treat accessibility as part of the welcome, not a special favor. Useful directions should explain distances, steps, and alternatives without making promises they cannot support.

And I would ask visitors to plan beyond a checklist. A place is not a game where you collect five famous photographs and win the right to leave.

Careful, Sam. People can enjoy a famous view without passing your philosophy exam. Invite them to notice more; do not shame them for starting with the obvious attraction.

Point taken. My objection is entitlement, not enjoyment. I want a visitor to hear no without treating the person who says it as an obstacle to the holiday.

And I want a resident to feel able to welcome someone without signing away the right to rest. A warm welcome can have a closing time.

That is the compromise I can defend: public rules, genuine access, and limits that remain limits even when someone arrives with a bigger budget or a louder complaint.

I would add useful alternatives and a date to review the arrangement. A city can be generous without promising that every visitor gets everything, everywhere, immediately.

Then we agree on the destination, while arguing about the route. Open the door, yes. Just remember that the door belongs to a home, not a stage set.'''),
        'ar': paragraphs('''أحب المدينة التي تستقبل زوارها بفضول وكرم. لا أريد أن يشعر القادم أنه يحتاج كلمة سر، أو معرفة شخصية، حتى يُسمح له بالاستمتاع بالمكان.

والترحيب لا يعني فتح كل باب بلا حدود. أنا أضع يوم الساكن العادي قبل الصورة المثالية للزائر. هناك أناس يعيشون داخل هذه البطاقة السياحية الجميلة.

طبعًا، لكن طريقتك تجعل كل سائح كاميرا غازية ترتدي حذاءين. لماذا لا نبدأ بتوقعات واضحة، بدل أن نستقبل الفضول كأنه تهمة تحتاج إلى دفاع؟

حسنًا، توقعي الأول هدوء قرب البيوت ليلًا، والثاني مساحة تسمح للناس بعبور الشارع. لا أريد أن يصبح الحق البسيط في الحركة مرتبطًا بشراء تذكرة غالية.

هذه قواعد مفهومة، وأنا أريد شرحها قبل وصول الزائر بلغة بسيطة. القاعدة التي لا تظهر إلا بعد مخالفتها تشبه الفخ أكثر مما تشبه حسن الضيافة.

واللافتة اللطيفة بلا تطبيق تشبه الزينة. ماذا نفعل حين تتجاهلها مجموعة كاملة؟ رجاء لا تقولي لي إن الحل أن يصبح الجميع ألطف فجأة وفي اللحظة نفسها.

نشرح أولًا عندما يكون ذلك مناسبًا، ثم نطبق إجراءً متناسبًا عند الضرورة. والأهم أن تسري القاعدة على المجموعة المنظمة مثلما تسري على الزائر الذي يمشي وحده.

ما زلت أريد جوابًا عن المكان الصغير المزدحم. هل تقبلين تحديد الدخول في الساعات المطلوبة، حتى لو وصف زائر محبط هذا القرار بأنه غير عادل؟

أقبله إذا كان السبب واضحًا، لكنني أقدّم وقتًا بديلًا أو مسارًا آخر. من الأسهل تقبّل باب مغلق عندما يخبرك أحدهم بما لا يزال ممكنًا ومتاحًا.

ممتاز، والسؤال المحرج الآن: هل يشتري صاحب المال استثناءً من هذا الحد؟ لا أحب حماية المكان التي تختفي فجأة عندما تظهر باقة أغلى على القائمة.

ولا أنا. إذا كان الحد يحمي مساحة مشتركة، فلا ينبغي أن يزول بسعر أعلى. أفضل حجز خيارات متاحة للجميع، بدل بيع كل ساعة مريحة لمن يدفع أكثر.

إذن لماذا لا نعطي السكان حق اختيار الشوارع التي تبقى هادئة؟ لا أريد منهم تقديم عرض ترحيبي دائم، لمجرد أن الحي الذي يسكنونه جميل في الصور.

لأن السكان أنفسهم يختلفون أيضًا. من يريد الهدوء ومن يريد مزيدًا من الزوار قد يسكنان المبنى نفسه. لا نعيّن شخصًا واحدًا ممثلًا وحيدًا لكل أهل المكان.

هذا صحيح، لكن الاجتماعات قد تتحول إلى حديث لا ينتهي. أنا أفضل تجربة قصيرة لها موعد مراجعة واضح، حتى نحكم على ترتيب موجود لا على شعارات جميلة.

بدأت تتحدث مثلي! نجرّب مسارًا للمشي، ونرى أين يسبب الإزعاج، ثم نعدله. لا نعلن الخطة المثالية قبل أن يستخدم أحد الرصيف ويحاول الوصول إلى بيته.

ولكن نسمي الإزعاج باسمه. إذا أصبح الوصول صعبًا لشخص محدود الحركة، لا نقول له إن العقبات جزء ساحر من التجربة الأصيلة، وعليه أن يستمتع بها بصمت.

بالتأكيد، سهولة الوصول جزء من الترحيب وليست منّة. أريد إرشادات تشرح المسافة والدرجات والبدائل بوضوح، من دون وعود لا يستطيع المكان الوفاء بها عند الوصول.

وأريد من الزائر التفكير خارج قائمة الإنجازات. المدينة ليست لعبة تجمع فيها خمس صور مشهورة، ثم تحصل على ميدالية خيالية تسمح لك بالمغادرة منتصرًا.

على مهلك يا عمر. يمكن للناس الاستمتاع بمنظر معروف من دون اجتياز امتحانك الفلسفي. ندعوهم لاكتشاف المزيد، ولا نوبخهم لأنهم بدأوا بما يعرفه الجميع.

معك حق. اعتراضي على الإحساس بالاستحقاق لا على الاستمتاع. أريد أن يسمع الزائر كلمة لا، من دون اعتبار قائلها عائقًا شخصيًا أمام نجاح الإجازة.

وأريد أن يرحب الساكن بالآخرين من دون التنازل عن حقه في الراحة. يمكن أن تكون الضيافة دافئة وصادقة، ولها في الوقت نفسه موعد واضح لانتهاء الزيارة.

هذا اتفاق أستطيع الدفاع عنه: قواعد معلنة، ووصول حقيقي، وحدود تبقى حدودًا حتى حين يصل شخص بميزانية أكبر، أو شكوى أعلى، أو برنامج سياحي مستعجل.

وأضيف بدائل مفيدة وموعدًا لمراجعة التجربة. تستطيع المدينة أن تكون كريمة من دون وعد كل زائر بأنه سيحصل على كل شيء، في كل مكان، وفي أي لحظة.

إذن نختلف على الطريق ونتفق على وجهة معقولة. افتحوا الباب، نعم، لكن تذكروا أن وراء الباب بيتًا وحياة يومية، وليس مجرد ديكور ينتظر التقاط صورة أخرى.'''),
    },
    {
        'id': 'economy', 'categories': ['economy'],
        'titles': {'en': 'A bold new project, or fix what we already have?', 'ar': 'مشروع جديد طموح أم إصلاح ما لدينا؟'},
        'en': paragraphs('''I favor making room for a bold new idea in a budget. If we only repair yesterday's choices, we never seriously ask whether a better option is possible.

And I favor repairing the thing people already rely on. A shiny opening ceremony does not impress me if the ordinary service beside it is still inconvenient.

That is a strong image, but it is not a decision rule. Would you reject every new project until every existing problem disappears? That day may never come.

No. I would ask the new project to compete honestly with maintenance. Show the full running costs, not just the attractive price printed on the launch announcement.

Agreed. Include staffing, upkeep, and the possibility that the plan disappoints. But also explain what we give up by never trying it. Caution has a price too.

Then put both prices on the same page. I do not want the exciting option illustrated in color while the practical alternative gets one miserable line at the bottom.

You want a fair comparison. So do I. I would begin with the problem, then invite different solutions, rather than start with a favorite project and hunt for a problem.

Excellent. And I would ban the phrase everybody benefits unless someone can explain who benefits first, who waits, and who carries the inconvenience while we experiment.

You cannot ban a phrase into producing a good plan, Sam. Ask better questions. For example: what smaller version would let us test the central idea without committing everything?

A smaller version can still be a bad idea. I want a stop condition before the start. Otherwise each disappointing result becomes an argument for spending a little more.

Then set milestones that can lead to cancellation as well as celebration. I would rather admit a trial failed than keep paying to protect the dignity of its announcement.

Now we are getting somewhere. But who gets to judge that failure? The same team that promised success should not be the only voice explaining the result.

Use an independent review and invite the people meant to use the service. Their awkward questions belong inside the decision, not in a complaint box after everything is built.

And include the people who will maintain it. I do not want a beautiful design that assumes cleaning, repairs, and support happen by magic in the hours nobody photographs.

Absolutely. The unglamorous work deserves a line in the budget and a voice in the room. But I still refuse to make lack of glamour a qualification for funding.

Neither do I. A project can be exciting and useful. My irritation begins when excitement becomes a substitute for explaining why this proposal comes ahead of another one.

Then rank proposals against an agreed goal. Not the loudest advocate, not the most photogenic picture. If the goal changes, say so before declaring the old plan a winner.

And show the tradeoff in ordinary language. If choosing one thing delays another, name the delay. I would prefer a difficult honest answer to a cheerful promise of everything.

Here is where I push back: people also need permission to imagine something better. A budget discussion that only lists constraints can make participation feel pointless from the start.

Imagination is welcome. Arithmetic still gets a chair. I am happy to hear an ambitious idea, provided its champion does not treat every practical question as an insult.

Fair. My mind changes when the smaller trial cannot demonstrate a useful advantage, or the ongoing commitment crowds out something more important. I would then scale it back.

Mine changes when a new option solves a clearly defined problem better than continued patching, with honest costs and a workable exit. Then I would support the new thing.

So ambition should have to explain itself, and maintenance should have to explain itself too. Neither gets a permanent reserved seat just because its supporters sound morally certain.

Exactly. Bring the vision, bring the repair list, and bring the difficult numbers. Just do not bring a ribbon-cutting ceremony and call it the whole argument.'''),
        'ar': paragraphs('''أؤيد أن نترك في الميزانية مكانًا لفكرة جديدة وطموحة. إذا اكتفينا بإصلاح اختيارات الأمس، فلن نسأل بجدية إن كان هناك خيار أفضل يستحق التجربة.

وأنا أميل إلى إصلاح ما يعتمد عليه الناس أصلًا. لا يبهرني افتتاح لامع إذا بقيت الخدمة العادية بجانبه مزعجة، ثم طُلب من مستخدميها انتظار الفرج مرة أخرى.

صورة قوية، لكنها ليست قاعدة لاتخاذ القرار. هل ترفض كل مشروع جديد حتى تختفي كل مشكلة قديمة؟ قد ننتظر ذلك اليوم طويلًا من دون أن نتحرك أصلًا.

لا أرفضه، بل أطلب مقارنة صادقة مع الصيانة. أريد تكلفة التشغيل كاملة، لا الرقم الجذاب الذي يظهر عند إطلاق المشروع، ثم تختفي خلفه الالتزامات الباقية.

نتفق، نضع الموظفين والصيانة واحتمال خيبة الأمل في الحساب. لكن نوضح أيضًا ما نخسره إذا لم نجرّب أبدًا. الحذر ليس خيارًا بلا تكلفة ولا نتيجة.

إذن نعرض الكلفتين في الصفحة نفسها. لا أريد صورًا ملوّنة للخيار المثير، وفي أسفل الصفحة سطرًا يتيمًا حزينًا يشرح البديل العملي وكأنه عقوبة للجمهور.

أنت تريد مقارنة عادلة، وأنا أيضًا. نبدأ بالمشكلة، ثم نسمع حلولًا مختلفة. لا نختار مشروعًا نحبه أولًا، ثم نبحث له عن مشكلة مناسبة ليحلها أمامنا.

وأريد التوقف عند عبارة يستفيد الجميع. من يستفيد أولًا، ومن ينتظر، ومن يتحمل الإزعاج أثناء التجربة؟ لا يمكن أن تحل كلمة الجميع محل هذه الأسئلة المحددة.

لن نحصل على خطة جيدة بمنع العبارات يا عمر. فلنسأل مثلًا: ما النسخة الأصغر التي تختبر الفكرة الأساسية، من دون أن نرهن لها كل الخيارات المتاحة؟

حتى النسخة الصغيرة قد تكون فكرة سيئة. أريد شرط توقف قبل البداية، وإلا أصبحت كل نتيجة مخيبة حجة لإنفاق مبلغ إضافي صغير، ثم مبلغ صغير بعده.

نحدد مراحل يمكن أن تنتهي بالإلغاء، لا بالاحتفال فقط. أفضل الاعتراف بأن تجربة لم تنجح، بدل الاستمرار في الدفع لحماية هيبة الإعلان الذي سبق تنفيذها.

هذا تقدم حقيقي، لكن من يحكم على الإخفاق؟ الفريق الذي وعد بالنجاح لا ينبغي أن يكون الصوت الوحيد الذي يشرح النتيجة ويقرر كيف يجب أن نفهمها.

نحتاج مراجعة مستقلة وسماع من سيستخدمون الخدمة. مكان أسئلتهم المزعجة داخل القرار، لا في صندوق شكاوى صغير نفتحه لهم بعد أن ينتهي البناء ويبدأ التصوير.

ونسمع من سيقومون بالصيانة أيضًا. لا أريد تصميمًا جميلًا يفترض أن التنظيف والإصلاح والدعم تحدث بالسحر، في الساعات التي لا يحضر فيها أحد لالتقاط الصور.

بالتأكيد، العمل غير اللامع يستحق بندًا واضحًا وصوتًا مسموعًا. لكنني أرفض أن يصبح غياب اللمعان شهادة جودة تلقائية، وكأن المشروع الجذاب لا يمكن أن يكون مفيدًا.

وأنا لا أقول ذلك. يزعجني فقط أن يتحول الحماس إلى بديل عن تفسير الأولويات. لماذا يأتي هذا الاقتراح قبل غيره؟ أريد جوابًا أبعد من أنه يبدو رائعًا.

نرتب المقترحات وفق هدف متفق عليه، لا وفق أعلى صوت أو أجمل صورة. وإذا تغير الهدف، نقول ذلك قبل إعلان الخطة القديمة فائزة في المسابقة الجديدة.

ونشرح المفاضلة بلغة عادية. إذا أدى اختيار شيء إلى تأجيل آخر، نسمي هذا التأجيل. أفضل إجابة صعبة وصادقة على وعد مبتهج يقول إن كل شيء ممكن فورًا.

هنا أعترض عليك قليلًا. الناس تحتاج أيضًا مساحة لتخيّل الأفضل. نقاش لا يعرض إلا القيود قد يجعل المشاركة تبدو بلا معنى، وكأن النتيجة محسومة قبل الكلام.

الخيال مرحب به، والحساب له كرسي أيضًا. سأسمع الفكرة الطموحة باهتمام، بشرط ألا يعتبر صاحبها كل سؤال عملي إهانة شخصية لذكائه أو لحقه في الحلم.

حسنًا، أغيّر موقفي إذا لم تثبت التجربة الصغيرة فائدة واضحة، أو إذا زاحمت التزاماتها شيئًا أهم. عندها أصغّر المشروع أو أوقفه، ولا أطالب بالتصفيق له عنادًا.

وأنا أغيّر رأيي إذا حل الخيار الجديد مشكلة محددة أفضل من الترقيع المستمر، بكلفة واضحة ومخرج ممكن. عندها أؤيده، حتى لو كان شكله أجمل مما توقعت.

إذن الطموح يشرح نفسه، والصيانة تشرح نفسها أيضًا. لا يحصل أحد الخيارين على مقعد محجوز إلى الأبد، لمجرد أن أنصاره يتحدثون بثقة أخلاقية عالية أمامنا.

بالضبط. أحضروا الرؤية، وأحضروا قائمة الإصلاح، والأرقام المزعجة أيضًا. لكن لا تحضروا شريط الافتتاح والمقص، ثم تطلبوا منا اعتبار المشهد كله حجة اقتصادية مكتملة.'''),
    },
]


def profile(language, speaker):
    return copy.deepcopy(PROFILES[language][speaker])


def choose_discussion(program, slot, previous=(), allowed_topics=None):
    """Select a relevant available report; never retrofit tragedy to light debate."""
    news = [row for row in program['segments'] if row.get('type') == 'news' and row.get('sources')]
    candidates = [(theme, row) for theme in BANK for row in news if row.get('category') in theme['categories']
                  and (allowed_topics is None or theme['id'] in allowed_topics)]
    if not candidates:
        raise ValueError('No reviewed discussion topic has a current native publisher report')
    recent = [(episode.get('topicId'), episode.get('sources', [{}])[0].get('url')) for episode in previous[-8:]]
    # Favor another theme, then another report; a bounded tie-break varies slots.
    candidates.sort(key=lambda item: (
        item[0]['id'] == (recent[-1][0] if recent else None),
        (item[0]['id'], item[1]['sources'][0]['url']) in recent,
        hashlib.sha256((str(slot) + item[0]['id'] + item[1]['id']).encode()).hexdigest()))
    return candidates[0]


def dialogue_turns(theme, report, language):
    turns = [{'speaker': 'woman', 'kind': 'host', 'text': OPEN[language]},
             {'speaker': 'man', 'kind': 'source', 'text': report.get('newsBodyText', report['text'])}]
    # These reviewed shorter arcs retain complete arguments and replies. Real
    # native Arabic recordings need more time than their word count suggests.
    arcs = {'digital': [0,1,2,3,4,5,6,7,10,11,20,21,22,23],
            'travel': list(range(12)) + [22,23],
            'economy': list(range(10)) + [20,21,22,23]}
    turns.extend({'speaker': 'woman' if index % 2 == 0 else 'man', 'kind': 'opinion', 'text': theme[language][index]}
                 for index in arcs[theme['id']])
    turns.append({'speaker': 'woman', 'kind': 'host', 'text': CLOSE[language]})
    for turn in turns:
        turn['pause_after'] = .12
    turns[-1]['pause_after'] = 0
    return turns
