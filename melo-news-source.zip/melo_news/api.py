"""Read-only news and autonomous speech API; cold starts refresh on demand.

No authentication, deployment credentials, translation service, or paid API is
required. News speech uses exact publisher headlines or brief RSS descriptions
and retains original provenance; it never generates missing facts.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import signal
import socket
import threading
import time
import urllib.parse

from .collector import FeedClient, RunLock, collect_once, iso, parse_date, utcnow, validate_config


class CatalogStore:
    def __init__(self, directory, refresh_seconds=300, request_wait_seconds=15,
                 configs=None, collect=collect_once, on_refresh=None):
        base = Path(__file__).resolve().parent
        self.directory = Path(directory)
        self.refresh_seconds = refresh_seconds
        self.request_wait_seconds = request_wait_seconds
        self.configs = configs or {
            "en": validate_config(json.loads((base / "sources.json").read_text(encoding="utf-8"))),
            "ar": validate_config(json.loads((base / "sources-ar.json").read_text(encoding="utf-8"))),
        }
        self.collect = collect
        self.on_refresh = on_refresh
        self.client = FeedClient(timeout=12, retries=1, domain_delay=1)
        self._mutex = threading.Lock()
        self._jobs = {}
        self._last_started = {}
        self._errors = {}

    def path(self, language):
        return self.directory / language / "catalog.json"

    def cached(self, language):
        try:
            value = json.loads(self.path(language).read_text(encoding="utf-8"))
            if value.get("schemaVersion") == 1 and value.get("language") == language:
                return value
        except (OSError, ValueError):
            pass
        return None

    def age(self, catalog):
        checked = parse_date((catalog or {}).get("runCheckedAt"))
        return max(0, (utcnow() - checked).total_seconds()) if checked else None

    def start_refresh(self, language, force=False):
        """One refresh per language; all callers share the same completion event."""
        with self._mutex:
            existing = self._jobs.get(language)
            if existing is not None and not existing.is_set():
                return existing
            cached = self.cached(language)
            age = self.age(cached)
            if not force and age is not None and age < self.refresh_seconds:
                return None
            # A failed upstream does not turn repeated requests into a feed hammer.
            if time.monotonic() - self._last_started.get(language, -1000000) < 60:
                return existing
            event = threading.Event()
            self._jobs[language] = event
            self._last_started[language] = time.monotonic()
            threading.Thread(target=self._refresh, args=(language, event),
                             name="melo-news-refresh-" + language, daemon=True).start()
            return event

    def _refresh(self, language, event):
        succeeded = False
        try:
            output = self.path(language)
            with RunLock(output.with_suffix(output.suffix + ".lock")):
                self.collect(self.configs[language], output, self.client)
            with self._mutex:
                self._errors.pop(language, None)
            succeeded = True
        except Exception as error:
            with self._mutex:
                self._errors[language] = {"type": type(error).__name__, "attemptedAt": iso(utcnow())}
        finally:
            event.set()
        if succeeded and self.on_refresh:
            # A speech/model failure must never undo a successful source check.
            try:
                self.on_refresh(language)
            except Exception:
                pass

    def response(self, language):
        event = self.start_refresh(language)
        if event is not None:
            event.wait(self.request_wait_seconds)
        value = self.cached(language)
        active = event is not None and not event.is_set()
        if value is None:
            return 202, {"schemaVersion": 1, "language": language,
                         "status": "refreshing" if active else "unavailable",
                         "items": [], "coverageGapNotices": [{"reason": "initial_collection_pending" if active else "initial_collection_failed"}],
                         "api": {"refreshInProgress": active, "retryAfterSeconds": 5}}
        value = copy.deepcopy(value)
        age = self.age(value)
        stale = age is None or age >= self.refresh_seconds
        # Re-evaluate publication ages even when returning a retained disk cache.
        now = utcnow()
        by_id = {x["id"]: x for x in value["items"]}
        for category_id, category in value["categories"].items():
            cutoff = now - dt.timedelta(hours=category["maxAgeHours"])
            category["freshItemIds"] = [identity for identity in category["freshItemIds"]
                if identity in by_id and any(p["category"] == category_id and not p["retained"]
                    and parse_date(p["publishedAt"]) is not None
                    and cutoff <= parse_date(p["publishedAt"]) <= now
                    for p in by_id[identity]["provenance"])]
            if not category["freshItemIds"]:
                category["status"] = "retained" if category["itemIds"] else "unavailable"
        value["api"] = {"refreshInProgress": active, "cacheAgeSeconds": None if age is None else round(age, 1),
                        "stale": stale, "refreshAfterSeconds": self.refresh_seconds,
                        "requestWaitLimitSeconds": self.request_wait_seconds}
        if stale:
            value["coverageGapNotices"].append({"reason": "collection_cache_stale",
                "lastCollectionAt": value.get("runCheckedAt"), "refreshInProgress": active})
        with self._mutex:
            if language in self._errors:
                value["api"]["lastRefreshError"] = self._errors[language]
        return 200, value

    def health(self):
        editions = {}
        for language in self.configs:
            value = self.cached(language)
            age = self.age(value)
            with self._mutex:
                event = self._jobs.get(language)
                active = event is not None and not event.is_set()
            editions[language] = {"status": value.get("status") if value else "initializing",
                                  "lastCollectionAt": value.get("runCheckedAt") if value else None,
                                  "cacheAgeSeconds": round(age, 1) if age is not None else None,
                                  "refreshInProgress": active}
        # Liveness remains HTTP 200 during a cold start/upstream failure, so a
        # free host does not endlessly restart an otherwise healthy process.
        return {"service": "melo-news", "status": "running", "editions": editions,
                "hostingNote": "Free hosting may sleep. Requests refresh stale cache within a bounded wait, or return dated cache / HTTP 202 while work continues."}


def stream_audio(handler, path, head_only=False):
    """Stream one verified content-addressed MP3 with bounded-memory ranges."""
    try:
        stream = path.open("rb")
    except OSError:
        handler.send_error(404, "Audio is unavailable")
        return
    with stream:
        size = os.fstat(stream.fileno()).st_size
        start, end, status = 0, size - 1, 200
        requested = handler.headers.get("Range")
        if requested:
            match = re.fullmatch(r"bytes=(\d*)-(\d*)", requested.strip()) if len(requested) <= 100 else None
            valid = bool(match and any(match.groups()))
            if valid:
                left, right = match.groups()
                if left:
                    start = int(left)
                    end = min(int(right), size - 1) if right else size - 1
                else:
                    suffix = int(right)
                    valid = suffix > 0
                    start = max(0, size - suffix)
                valid = valid and 0 <= start <= end < size
            if not valid:
                handler.send_response(416)
                handler.send_header("Content-Range", "bytes */" + str(size))
                handler.send_header("Content-Length", "0")
                handler.end_headers()
                return
            status = 206
        handler.send_response(status)
        handler.send_header("Content-Type", "audio/mpeg")
        handler.send_header("Content-Length", str(end - start + 1))
        handler.send_header("Accept-Ranges", "bytes")
        handler.send_header("Cache-Control", "public, max-age=31536000, immutable")
        handler.send_header("ETag", '"' + path.stem + '"')
        handler.send_header("X-Content-Type-Options", "nosniff")
        if status == 206:
            handler.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        handler.end_headers()
        if head_only:
            return
        stream.seek(start)
        remaining = end - start + 1
        try:
            while remaining:
                chunk = stream.read(min(65536, remaining))
                if not chunk:
                    break
                handler.wfile.write(chunk)
                remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass


def handler_for(store, radio_store=None):
    class Handler(BaseHTTPRequestHandler):
        server_version = "MeloNews/1.0"

        def do_GET(self):
            self.respond(False)

        def do_HEAD(self):
            self.respond(True)

        def respond(self, head_only):
            p = urllib.parse.urlsplit(self.path)
            if p.path in {"/health", "/healthz"}:
                status, value = 200, store.health()
                if radio_store:
                    value["radio"] = radio_store.status()
            elif radio_store and p.path == "/radio/status":
                status, value = 200, radio_store.status()
            elif radio_store and p.path == "/radio-program.json":
                language = urllib.parse.parse_qs(p.query).get("language", ["en"])[0]
                if language not in {"en", "ar"}:
                    status, value = 400, {"error": "language must be en or ar"}
                else:
                    status, value = radio_store.response(language)
            elif radio_store and re.fullmatch(r"/radio/audio/[0-9a-f]{64}\.mp3", p.path):
                path = radio_store.audio_file(p.path.rsplit("/", 1)[-1][:-4])
                if path is not None:
                    stream_audio(self, path, head_only)
                    return
                status, value = 404, {"error": "Recorded clip is no longer cached; reload the radio edition"}
            elif p.path in {"/news.json", "/catalog.json"}:
                language = urllib.parse.parse_qs(p.query).get("language", ["en"])[0]
                if language not in {"en", "ar"}:
                    status, value = 400, {"error": "language must be en or ar"}
                else:
                    status, value = store.response(language)
            else:
                status, value = 404, {"error": "Use /news.json?language=en|ar, /radio-program.json?language=en|ar or /health"}
            data = (json.dumps(value, ensure_ascii=False) + "\n").encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if status == 202:
                self.send_header("Retry-After", "5")
            self.end_headers()
            try:
                if not head_only:
                    self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, format, *args):
            # Avoid query/remote URL log leakage and noisy publisher headlines.
            return
    return Handler


class BoundedHTTPServer(ThreadingHTTPServer):
    """Limit HTTP workers and header read time on a small/free public host."""
    daemon_threads = True
    request_queue_size = 32

    def __init__(self, *args, **kwargs):
        self._worker_slots = threading.BoundedSemaphore(16)
        super().__init__(*args, **kwargs)

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(25)
        return connection, address

    def process_request(self, request, client_address):
        if not self._worker_slots.acquire(blocking=False):
            try:
                # Drain the ordinary request line/headers before closing; on
                # Windows, closing a socket with unread bytes can reset away
                # an otherwise valid overload response. Never wait on a slow
                # client here for more than 50 milliseconds.
                request.settimeout(.05)
                try:
                    request.recv(16384)
                except OSError:
                    pass
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nRetry-After: 5\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
                request.shutdown(socket.SHUT_WR)
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent / "data" / "api")
    parser.add_argument("--refresh-seconds", type=int, default=300)
    parser.add_argument("--request-wait-seconds", type=float, default=15)
    parser.add_argument("--no-radio", action="store_true", help="Run only the publisher headline API")
    args = parser.parse_args(argv)
    if not 300 <= args.refresh_seconds <= 86400 or not 0 <= args.request_wait_seconds <= 20:
        parser.error("Refresh must be >=300s; request wait must be between 0 and 20s")
    store = CatalogStore(args.data_dir, args.refresh_seconds, args.request_wait_seconds)
    radio_store = None
    if not args.no_radio:
        from .radio import RadioStore
        from .semantics import SemanticSelector
        radio_store = RadioStore(args.data_dir.parent / "radio", store, selector=SemanticSelector())
        def news_ready(_language):
            if all(store.cached(language) for language in store.configs):
                radio_store.start_refresh()
        store.on_refresh = news_ready
    stop = threading.Event()
    def periodic():
        while not stop.is_set():
            for language in store.configs:
                store.start_refresh(language)
            if radio_store and all(store.cached(language) for language in store.configs):
                radio_store.start_refresh()
            stop.wait(1800)
    threading.Thread(target=periodic, name="melo-news-periodic", daemon=True).start()
    server = BoundedHTTPServer((args.host, args.port), handler_for(store, radio_store))
    def shutdown(*_):
        stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, shutdown)
    print(json.dumps({"service": "melo-news", "listeningPort": args.port,
                      "refreshAfterSeconds": args.refresh_seconds}), flush=True)
    try:
        server.serve_forever(poll_interval=.5)
    finally:
        stop.set()
        server.server_close()


if __name__ == "__main__":
    main()
