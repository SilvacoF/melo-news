"""Run `python -m melo_news --once`, or omit --once for the scheduler."""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import signal
import sys
import threading
import time

from .collector import RunLock, atomic_json, collect_once, iso, parse_date, utcnow, validate_config


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    base = Path(__file__).resolve().parent
    parser.add_argument("--config", type=Path, default=base / "sources.json")
    parser.add_argument("--output", type=Path, default=base / "data" / "catalog.json")
    parser.add_argument("--once", action="store_true", help="Collect one bounded batch and exit")
    parser.add_argument("--interval-seconds", type=int, help="Scheduler interval, at least 300 seconds")
    parser.add_argument("--health", action="store_true", help="Read health without contacting publishers")
    args = parser.parse_args(argv)
    if sys.version_info < (3, 10):
        parser.error("Scrapling 0.4.15 requires Python >=3.10; use py -3.11 on this Windows host")
    if args.health:
        try:
            health = json.loads((args.output.parent / "health.json").read_text(encoding="utf-8"))
            last = parse_date(health.get("lastRunAt"))
            stale_after = max(300, health.get("intervalSeconds", 1800) * 2 + 180)
            if last is None or (utcnow() - last).total_seconds() > stale_after:
                health["status"] = "stale"
            print(json.dumps(health, ensure_ascii=False))
            return 0 if health["status"] in {"ok", "degraded"} else 2
        except (OSError, ValueError):
            print(json.dumps({"status": "unavailable", "reason": "No readable health record"}))
            return 2
    try:
        config = validate_config(json.loads(args.config.read_text(encoding="utf-8")))
        if args.interval_seconds is not None:
            config["intervalSeconds"] = args.interval_seconds
            validate_config(config)
        stop = threading.Event()
        for signum in (signal.SIGINT, signal.SIGTERM):
            signal.signal(signum, lambda *_: stop.set())
        with RunLock(args.output.with_suffix(args.output.suffix + ".lock")):
            while not stop.is_set():
                started = time.monotonic()
                try:
                    catalog, health = collect_once(config, args.output)
                    print(json.dumps({k: health[k] for k in ("status", "lastRunAt", "version", "freshCategories", "categoryCount", "itemCount", "sourcesOk", "sourceCount")}), flush=True)
                    code = 0 if catalog["status"] != "failed" else 2
                except Exception as error:
                    # Do not replace catalog on an unexpected failure.
                    atomic_json(args.output.parent / "health.json", {
                        "schemaVersion": 1, "status": "failed", "lastRunAt": iso(utcnow()),
                        "intervalSeconds": config["intervalSeconds"], "error": type(error).__name__,
                        "reason": "Collector failed; prior catalog retained",
                    })
                    print(json.dumps({"status": "failed", "error": type(error).__name__, "catalogRetained": True}), flush=True)
                    code = 2
                if args.once:
                    return code
                stop.wait(max(1, config["intervalSeconds"] - (time.monotonic() - started)))
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        print(json.dumps({"status": "failed", "error": type(error).__name__, "reason": str(error)}), file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
