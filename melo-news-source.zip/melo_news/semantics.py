"""Bounded optional topic advice; publisher evidence is never modified."""
from __future__ import annotations

import copy
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import threading

BASE = Path(__file__).resolve().parent
TOPICS = frozenset({'world', 'technology', 'ai', 'economy', 'sports', 'nature', 'travel', 'history', 'science'})
from .semantic_runner import FAILURE_CODES


class InferenceFailure(RuntimeError):
    def __init__(self, reply, returncode):
        super().__init__('The optional classifier did not complete')
        self.diagnostics = {'errorCode': reply.get('errorCode') if reply.get('errorCode') in FAILURE_CODES else 'embedding_failed',
                            'exitCode': reply.get('exitCode', returncode), 'metrics': reply.get('metrics', {}),
                            'workerTerminated': reply.get('childTerminated') is True}


def kill_worker(process):
    """Stop only this owned helper and its owned model descendants."""
    import psutil
    try:
        worker = psutil.Process(process.pid)
        children = worker.children(recursive=True)
        for child in reversed(children):
            try:
                child.kill()
            except psutil.Error:
                pass
        worker.kill()
        psutil.wait_procs(children + [worker], timeout=5)
    except psutil.Error:
        pass


class SemanticSelector:
    def __init__(self, model_path=None, runtime_path=None, run=None):
        self.manifest = json.loads((BASE / 'model-manifest.json').read_text(encoding='utf-8'))
        self.model = Path(model_path or os.environ.get('MELO_EMBEDDING_MODEL', str(BASE / 'models' / self.manifest['embedding']['file'])))
        default_runtime = BASE / 'bin' / self.manifest['runtime']['linuxX64']['binaryRelativePath']
        self.runtime = Path(runtime_path or os.environ.get('MELO_LLAMA_SERVER', str(default_runtime)))
        self.run = run or self._run
        self._lock = threading.Lock()
        self._cache = {}
        self._checked_model = False
        self._state = {'state': 'initializing' if self.model.is_file() and self.runtime.exists() else 'unavailable',
                       'model': 'EmbeddingGemma 2', 'advisoryOnly': True, 'generatesText': False}

    def status(self):
        return copy.deepcopy(self._state)

    def _verify_model(self):
        if self._checked_model:
            return
        expected = self.manifest['embedding']
        if self.model.stat().st_size != expected['bytes']:
            raise ValueError('Pinned model size differs')
        digest = hashlib.sha256()
        with self.model.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1048576), b''):
                digest.update(chunk)
        if digest.hexdigest() != expected['sha256']:
            raise ValueError('Pinned model digest differs')
        self._checked_model = True

    def _run(self, payload):
        environment = os.environ.copy()
        for key in ('HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'HERENOW_API_KEY', 'MELO_HERENOW_CREDENTIALS'):
            environment.pop(key, None)
        command = [sys.executable, '-m', 'melo_news.semantic_runner', '--model-path', str(self.model),
                   '--library-path', str(self.runtime), '--timeout', '90', '--memory-limit-mib', '320']
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   cwd=BASE.parent, env=environment, start_new_session=os.name != 'nt')
        try:
            body, _ = process.communicate(json.dumps(payload, ensure_ascii=False).encode('utf-8'), timeout=100)
        except subprocess.TimeoutExpired:
            kill_worker(process)
            process.communicate(timeout=5)
            raise TimeoutError('The optional classifier reached its deadline') from None
        if len(body) > 1024 * 1024:
            raise RuntimeError('The optional classifier did not complete')
        reply = json.loads(body)
        if process.returncode or not reply.get('ok'):
            raise InferenceFailure(reply, process.returncode)
        return reply

    def __call__(self, items, language, now):
        result = copy.deepcopy(items)
        with self._lock:
            if not self.model.is_file() or not self.runtime.exists():
                self._state['state'] = 'unavailable'
                return result
            try:
                self._verify_model()
                pending, keys = [], {}
                for index, item in enumerate(result[:64]):
                    key = hashlib.sha256((language + '\0' + item['title']).encode('utf-8')).hexdigest()
                    keys[str(index)] = key
                    if key not in self._cache:
                        pending.append({'id': str(index), 'title': item['title'], 'language': language})
                if pending:
                    advice = self.run({'items': pending, 'categories': sorted(TOPICS)})
                    if (not advice.get('ok') or advice.get('generatedText') is not False
                            or advice.get('advisoryOnly') is not True or advice.get('childTerminated') is not True
                            or advice.get('revision') != self.manifest['embedding']['revision']):
                        raise ValueError('Invalid advisory classifier response')
                    rows = advice.get('results', [])
                    if len(rows) != len(pending) or {row.get('id') for row in rows} != {row['id'] for row in pending}:
                        raise ValueError('Classifier IDs differ from the source inputs')
                    additions = {}
                    for row in rows:
                        score, margin = row.get('score'), row.get('margin')
                        if (row.get('category') not in TOPICS or isinstance(score, bool) or isinstance(margin, bool)
                                or not isinstance(score, (int, float)) or not isinstance(margin, (int, float))
                                or not math.isfinite(score) or not math.isfinite(margin) or not -1 <= score <= 1 or not 0 <= margin <= 2):
                            raise ValueError('Invalid advisory score')
                        additions[keys[row['id']]] = row
                    self._cache.update(additions)
                    self._state = {**self._state, 'state': 'ready', 'lastInferenceAt': now.astimezone(dt.timezone.utc).isoformat(),
                                   'classified': len(pending), 'metrics': advice.get('metrics', {}),
                                   'lastInferenceSeconds': advice.get('wallSeconds'), 'workerTerminated': True}
                    self._state.pop('errorType', None)
                    self._state.pop('errorCode', None)
                    self._state.pop('exitCode', None)
                for index, item in enumerate(result[:64]):
                    advice = self._cache.get(keys[str(index)], {})
                    # Good/offbeat labels always come from publishers. Even a
                    # confident advisory label cannot rewrite their categories.
                    if (item.get('category') not in ('positive', 'offbeat') and advice.get('score', 0) >= .72
                            and advice.get('margin', 0) >= .02 and not advice.get('lowConfidence', True)):
                        item['semanticCategories'] = [advice['category']]
                if len(self._cache) > 2048:
                    self._cache = dict(list(self._cache.items())[-1024:])
            except Exception as error:
                self._state = {**self._state, 'state': 'retained-publisher-categories', 'errorType': type(error).__name__}
                if isinstance(error, InferenceFailure):
                    self._state.update(error.diagnostics)
        return result
